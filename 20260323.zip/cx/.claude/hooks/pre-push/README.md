# Pre-push Hook

## 功能

在 Git 推送前运行验证：
1. 显示当前分支
2. 检查未提交的更改
3. 统计将要推送的提交

## 配置

需要配置 Git 本地 hook：
```bash
ln -s ../../.claude/hooks/pre-push/test.sh .git/hooks/pre-push
```

## 手动执行

```bash
bash .claude/hooks/pre-push/test.sh
```
