#!/bin/bash
# Pre-push Hook - 推送前验证
# 在推送前运行基本验证

echo "[PrePush] 运行推送前验证..."

# 1. 检查当前分支
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
echo "[PrePush] 当前分支: $CURRENT_BRANCH"

# 2. 检查是否有未提交的更改
if [ -n "$(git status --porcelain)" ]; then
    echo "[PrePush] 警告: 有未提交的更改"
    git status --short
fi

# 3. 统计将要推送的提交
COMMITS_TO_PUSH=$(git log @{u}..HEAD --oneline 2>/dev/null | wc -l)
if [ "$COMMITS_TO_PUSH" -gt 0 ]; then
    echo "[PrePush] 将推送 $COMMITS_TO_PUSH 个提交"
    git log @{u}..HEAD --oneline
fi

echo "[PrePush] 验证完成 ✅"
exit 0
