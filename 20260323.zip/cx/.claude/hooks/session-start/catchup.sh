#!/bin/bash
# Session Start Hook - 恢复上下文
# 调用 planning-with-files 的 session-catchup.py

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# 检查是否有 planning-with-files 插件
CATCHUP_SCRIPT="$PROJECT_ROOT/.claude/plugins/planning-with-files/scripts/session-catchup.py"

if [ -f "$CATCHUP_SCRIPT" ]; then
    python "$CATCHUP_SCRIPT" "$(pwd)" 2>/dev/null || echo "[SessionStart] session-catchup.py 执行失败"
else
    echo "[SessionStart] 未找到 session-catchup.py，跳过上下文恢复"
fi
