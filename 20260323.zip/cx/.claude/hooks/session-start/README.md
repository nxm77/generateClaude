# Session Start Hook

## 功能

会话开始时自动恢复上下文：
1. 调用 `planning-with-files` 的 `session-catchup.py`
2. 读取 `task_plan.md`, `findings.md`, `progress.md`
3. 显示未完成的任务

## 配置

已在 `settings.json` 中配置：
```json
"hooks": {
  "SessionStart": [...]
}
```

## 手动执行

```bash
bash .claude/hooks/session-start/catchup.sh
```
