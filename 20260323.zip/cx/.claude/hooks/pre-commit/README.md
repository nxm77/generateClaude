# Pre-commit Hook

## 功能

在 Git 提交前运行检查：
1. 检查是否有大文件（>1MB）
2. 验证 JSON 文件语法

## 配置

需要配置 Git 本地 hook：
```bash
ln -s ../../.claude/hooks/pre-commit/check.sh .git/hooks/pre-commit
```

## 手动执行

```bash
bash .claude/hooks/pre-commit/check.sh
```
