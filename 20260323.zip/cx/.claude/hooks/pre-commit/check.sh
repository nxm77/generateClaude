#!/bin/bash
# Pre-commit Hook - 代码检查
# 在提交前运行基本检查

echo "[PreCommit] 运行提交前检查..."

# 1. 检查是否有大文件
echo "[PreCommit] 检查大文件..."
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)
LARGE_FILES=""

for FILE in $STAGED_FILES; do
    if [ -f "$FILE" ]; then
        SIZE=$(stat -f%z "$FILE" 2>/dev/null || stat -c%s "$FILE" 2>/dev/null)
        if [ "$SIZE" -gt 1048576 ]; then  # 1MB
            LARGE_FILES="$LARGE_FILES $FILE"
        fi
    fi
done

if [ -n "$LARGE_FILES" ]; then
    echo "[PreCommit] 警告: 以下文件超过 1MB: $LARGE_FILES"
fi

# 2. 检查 JSON 文件语法
echo "[PreCommit] 检查 JSON 文件语法..."
for FILE in $STAGED_FILES; do
    if [[ "$FILE" == *.json ]]; then
        if ! python -m json.tool "$FILE" > /dev/null 2>&1; then
            echo "[PreCommit] 错误: $FILE 不是有效的 JSON"
            exit 1
        fi
    fi
done

echo "[PreCommit] 检查完成 ✅"
exit 0
