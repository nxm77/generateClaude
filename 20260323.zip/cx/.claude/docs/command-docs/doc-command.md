# /doc 命令说明

> **类别:** 文档生成
> **更新:** 2025-03-22

---

## 功能

生成项目文档。

---

## 用法

```
/doc [--requirements] [--files] [--diagram] [--ref=<模板文件路径>]
```

---

## 选项

| 参数 | 功能 |
|------|------|
| --requirements | 生成需求文档 |
| --files | 生成文件结构文档 |
| --diagram <类型> | 生成图表 |
| --ref <路径> | 参考模板文件 |

---

## 图表类型

| 类型 | 说明 |
|------|------|
| overview | 系统概览图 |
| architecture | 架构图 |
| flow | 流程图 |
| sequence | 时序图 |
| state | 状态机图 |

---

## 输出

生成 `docs/` 目录下的文档文件。

---

## 示例

```bash
# 生成需求文档
/doc --requirements

# 生成文件结构文档
/doc --files

# 生成系统概览图
/doc --diagram overview

# 参考模板生成 (保持文档风格一致)
/doc --requirements --ref=./templates/PRD-template.md
/doc --files --ref=./docs/files-template.md
/doc --diagram overview --ref=./docs/diagrams/overview-template.puml

# 输出:
# ✅ 文档已生成
# 📁 docs/requirements.md
# 📁 docs/files.md
# 📁 docs/diagrams/overview.puml
```

### --ref 参数说明

使用 `--ref` 参数时，新生成的文件会：
1. **继承结构** - 复用模板文件的章节/组件结构
2. **保持风格** - 复用模板的格式和样式
3. **填充内容** - 根据项目实际情况填充内容

```bash
# 示例：参考公司标准模板生成需求文档
/doc --requirements --ref=./templates/company-standard-prd.md

# 示例：参考已有架构图生成新架构图
/doc --diagram architecture --ref=./docs/diagrams/existing-arch.puml
```

---

## 注意事项

- PUML 图表需下载到本地查看
- 文档生成后需人工审核
- 大型项目生成时间较长
