# CX 插件功能库 - 文件说明

> **版本:** v1.0
> **日期:** 2026-03-23

---

## 目录结构概览

```
.claude/
├── CLAUDE.md                          # [P0] 项目主指导文档
├── rules/                             # [P0] 开发规则集
├── plugins/                           # [P0] 插件系统
│   └── planning-with-files/           # [P0] 规划系统
├── skills/                            # [P1] 技能集合
└── docs/                              # [P2] 文档和知识库
```

---

## 1. 核心配置文件

### 1.1 CLAUDE.md

**路径:** `.claude/CLAUDE.md`

**作用:** 项目主指导文档，Claude Code 的入口配置文件

**关键内容:**
- 快速开始命令
- 工作流选择
- 技术栈说明
- SECS/GEM 协议要点（半导体项目专用）
- 编码规范
- 技能引用

**修改时机:**
- 新项目首次初始化（使用 /init）
- 项目架构变更时
- 添加新命令时

**关键配置片段:**
```markdown
## 快速开始
| 命令 | 功能 | 时机 |
|------|------|------|
| `/init` | 初始化项目 CLAUDE.md | 新项目首次使用 |
...
```

---

## 2. 开发规则 (rules/)

### 2.1 agents.md

**作用:** 说明可用的 Agent 及使用时机

**关键内容:**
| Agent | 用途 | 何时使用 |
|-------|------|----------|
| planner | 实施规划 | 复杂功能、重构 |
| architect | 系统设计 | 架构决策 |
| tdd-guide | TDD | 新功能、Bug修复 |
| code-reviewer | 代码审查 | 写完代码后 |
| security-reviewer | 安全分析 | 提交前 |

---

### 2.2 coding-style.md

**作用:** 编码风格指南

**核心原则:**
- **不可变性**: 始终创建新对象，永不修改现有对象
- **小文件**: 高内聚低耦合，200-400 行典型，800 最大
- **显式错误处理**: 每层都要处理错误
- **边界验证**: 验证所有用户输入

---

### 2.3 development-workflow.md

**作用:** 完整的开发工作流程

**工作流:**
```
0. Research & Reuse (研究复用)
   ├─ GitHub 代码搜索优先
   ├─ 库文档其次
   └─ Exa 仅当前两者不足时
↓
1. Plan First (计划优先)
   ├─ 使用 planner agent
   ├─ 生成规划文档
   └─ 识别依赖和风险
↓
2. TDD Approach (测试驱动)
   ├─ 使用 tdd-guide agent
   ├─ RED (写测试)
   ├─ GREEN (实现)
   └─ IMPROVE (重构)
↓
3. Code Review (代码审查)
   ├─ 使用 code-reviewer agent
   ├─ 处理 CRITICAL 和 HIGH 问题
   └─ 修复 MEDIUM 问题
↓
4. Commit & Push (提交推送)
```

---

### 2.4 git-workflow.md

**作用:** Git 工作流程规范

**Commit 格式:**
```
<type>: <description>

<optional body>
```

类型: feat, fix, refactor, docs, test, chore, perf, ci

---

### 2.5 hooks.md

**作用:** Hooks 系统说明

**Hook 类型:**
- **PreToolUse**: 工具执行前（验证、参数修改）
- **PostToolUse**: 工具执行后（自动格式化、检查）
- **Stop**: 会话结束（最终验证）

---

### 2.6 patterns.md

**作用:** 常用设计模式

**关键模式:**
- Repository Pattern（仓储模式）
- API Response Format（API 响应格式）

---

### 2.7 performance.md

**作用:** 性能优化指南

**模型选择策略:**
| 模型 | 用途 | 成本 |
|------|------|------|
| Haiku 4.5 | 轻量级代理、配对编程 | 3x 便宜 |
| Sonnet 4.6 | 主开发工作 | 最佳编码模型 |
| Opus 4.5 | 复杂架构决策 | 最深推理 |

---

### 2.8 security.md

**作用:** 安全指南

**提交前检查:**
- [ ] 无硬编码密钥
- [ ] 所有用户输入已验证
- [ ] SQL 注入防护
- [ ] XSS 防护
- [ ] CSRF 启用
- [ ] 认证/授权验证

---

### 2.9 testing.md

**作用:** 测试规范

**要求:**
- 最低测试覆盖率: 80%
- TDD 工作流: RED → GREEN → IMPROVE
- 测试类型: 单元、集成、E2E

---

## 3. 规划系统 (plugins/planning-with-files/)

### 3.1 目录结构

```
planning-with-files/.cursor/
├── hooks.json              # Hooks 配置文件
├── hooks/                  # Hooks 脚本
│   ├── user-prompt-submit.sh
│   ├── pre-tool-use.sh
│   ├── post-tool-use.sh
│   └── stop.sh
└── skills/
    └── planning-with-files/
        ├── SKILL.md        # 规划技能主文件
        ├── examples.md     # 使用示例
        ├── reference.md    # 参考文档
        └── templates/      # 规划模板
            ├── task_plan.md
            ├── findings.md
            └── progress.md
```

---

### 3.2 hooks.json

**作用:** Hooks 配置文件

**关键配置:**
```json
{
  "hooks": {
    "SessionStart": "session-start.sh",
    "PreToolUse": "pre-tool-use.sh",
    "PostToolUse": "post-tool-use.sh",
    "Stop": "stop.sh"
  }
}
```

---

### 3.3 SKILL.md

**作用:** 规划技能主文件

**工作流程:**
1. **头脑风暴** - 探索意图、识别约束、提出方案
2. **结构化计划** - 创建三文件系统
3. **执行** - TDD 开发
4. **审查** - 代码审查

---

### 3.4 templates/

#### task_plan.md

**作用:** 任务计划模板

**结构:**
```markdown
# 任务名称

## 背景
[为什么做这件事]

## 目标
- [ ] 具体目标 1
- [ ] 具体目标 2

## 方案
[选定的方案及理由]

## 实施步骤
1. [ ] 步骤 1
2. [ ] 步骤 2

## 风险
| 风险 | 缓解措施 |
|------|---------|
```

---

#### findings.md

**作用:** 调研发现模板

**结构:**
```markdown
# 调研发现

## 技术栈分析
[相关技术分析]

## 代码结构
[现有代码结构]

## 关键发现
- 发现 1
- 发现 2
```

---

#### progress.md

**作用:** 进度跟踪模板

**结构:**
```markdown
# 进度跟踪

## 已完成
- [x] 任务 1 - 2025-03-23

## 进行中
- [ ] 任务 2

## 阻塞
- 无

## 下一步
1. 继续任务 2
2. 开始任务 3
```

---

## 4. 技术栈 Skills (skills/)

### 4.1 通用 Skills

#### cpp/SKILL.md

**适用:** C++ 项目

**关键内容:**
- C++17/20 特性
- 智能指针使用
- RAII 模式
- 测试框架（Google Test）
- 常见反模式

---

#### vbnet/SKILL.md

**适用:** VB.NET 项目

**关键内容:**
- Option Strict On
- 匈牙利命名约定
- 避免 On Error Resume Next
- .NET 最佳实践

---

#### java/SKILL.md

**适用:** Java 项目

**关键内容:**
- Spring Boot 最佳实践
- RESTful 设计
- JUnit 使用
- 依赖注入

---

#### vue/SKILL.md

**适用:** Vue 2/3 项目

**关键内容:**
- Vue 2 vs Vue 3 差异
- Composition API
- 组件设计模式
- Vitest 测试

---

### 4.2 业务专用 Skills

#### mes/

**适用:** MES 系统（C++ SiView）

**文件:**
- `SKILL.md` - 主技能文件
- `coding-standards.md` - 编码规范
- `patterns.md` - 常用模式
- `debugging.md` - 调试指南

**关键内容:**
- SiView 特点
- 智能指针管理
- 大型代码库处理策略

---

#### eap/

**适用:** EAP 系统（VB.NET）

**文件:**
- `SKILL.md` - 主技能文件
- `coding-standards.md` - 编码规范
- `patterns.md` - 常用模式
- `debugging.md` - 调试指南
- `secs-gem-reference.md` - SECS/GEM 协议参考

**关键内容:**
- SECS/GEM 协议
- 设备状态机
- 超时设置
- 事件处理

---

#### cx-planning/

**适用:** CX 项目融合规划

**作用:** 融合 Superpowers + Planning-with-files

**工作流程:**
1. 头脑风暴 (Superpowers)
2. 结构化计划 (Superpowers + Files)
3. 执行 (TDD)
4. 审查

---

## 5. 文档 (docs/)

### 5.1 目录结构

```
docs/
├── command-docs/           # 命令说明文档
│   ├── init-command.md
│   ├── update-claude-command.md
│   ├── create-skill-command.md
│   ├── learn-command.md
│   ├── review-command.md
│   └── diagram-command.md
├── knowledge/              # 技术知识库
│   └── mes-eap-technical-knowledge.md
├── references/             # 参考文档
│   ├── cpp-core-guidelines.md
│   ├── spring-boot-reference.md
│   ├── dotnet-coding-standards.md
│   ├── vue2-reference.md
│   ├── vue3-reference.md
│   └── python-reference.md
└── design/                 # 设计文档
    └── cx-claude-code-configuration-design.md
```

---

### 5.2 关键文档

#### mes-eap-technical-knowledge.md

**作用:** MES/EAP 技术知识库

**关键内容:**
- SECS/GEM 协议说明
- 常用消息类型（S1F13/S1F14, S6F11/S6F12 等）
- 通信超时配置
- 设备状态机

---

#### cx-claude-code-configuration-design.md

**作用:** 系统设计文档

**关键内容:**
- 设计决策
- 配置说明
- 架构图
- 实施指南

---

## 6. 索引文件 (indexes/)

### 6.1 作用

大型项目代码库索引，用于快速定位文件。

### 6.2 索引文件

| 文件 | 用途 |
|------|------|
| `mes-core.md` | MES 核心模块文件索引 |
| `eap-projects.md` | EAP 项目索引 |
| `web-modules.md` | Web 模块索引 |

**使用方式:**
```bash
# 先查看索引
cat .claude/indexes/mes-core.md

# 使用 Glob 精确匹配
Glob("src/core/**/*.cpp")
```

---

## 7. 会话文件（使用时创建）

### 7.1 task_plan.md

**作用:** 任务计划文件

**创建时机:** 开始新任务时

**模板:** 见 `planning-with-files/templates/task_plan.md`

---

### 7.2 findings.md

**作用:** 调研发现记录

**创建时机:** 探索代码库时

**模板:** 见 `planning-with-files/templates/findings.md`

---

### 7.3 progress.md

**作用:** 进度跟踪文件

**创建时机:** 开始任务时

**模板:** 见 `planning-with-files/templates/progress.md`

---

## 8. 文件优先级总结

| 优先级 | 文件/目录 | 必需性 |
|--------|-----------|--------|
| P0 | `.claude/CLAUDE.md` | ✅ 必需 |
| P0 | `.claude/rules/` | ✅ 必需 |
| P0 | `.claude/plugins/planning-with-files/.cursor/` | ✅ 必需 |
| P1 | `.claude/skills/cpp/` | 按需 |
| P1 | `.claude/skills/vbnet/` | 按需 |
| P1 | `.claude/skills/java/` | 按需 |
| P1 | `.claude/skills/vue/` | 按需 |
| P1 | `.claude/skills/mes/` | MES 项目 |
| P1 | `.claude/skills/eap/` | EAP 项目 |
| P2 | `.claude/docs/` | 可选 |
| P2 | `.claude/indexes/` | 大型项目 |

---

**文档状态:** ✅ 完成
**最后更新:** 2026-03-23
