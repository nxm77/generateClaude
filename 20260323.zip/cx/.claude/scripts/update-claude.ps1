# /update-claude - 更新项目配置
# 分析项目结构，更新代码索引和 CLAUDE.md 时间戳

$ErrorActionPreference = "Stop"

# 颜色函数
function Write-ColorOutput($ForegroundColor) {
    $fc = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $ForegroundColor
    if ($args) {
        Write-Output $args
    }
    $host.UI.RawUI.ForegroundColor = $fc
}

# 获取项目根目录
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir

Write-ColorOutput Cyan "=== CX 项目配置更新 ==="
Write-Output ""

# 1. 验证 CLAUDE.md 存在
$ClaudeMdPath = Join-Path $ProjectRoot "CLAUDE.md"
if (-not (Test-Path $ClaudeMdPath)) {
    Write-ColorOutput Red "✗ CLAUDE.md 不存在"
    Write-ColorOutput Yellow "请先运行 /init 命令初始化项目"
    exit 1
}
Write-ColorOutput Green "✓ CLAUDE.md 存在"

# 2. 创建索引目录
$IndexDir = Join-Path $ProjectRoot ".claude\indexes"
if (-not (Test-Path $IndexDir)) {
    New-Item -ItemType Directory -Path $IndexDir -Force | Out-Null
}
Write-ColorOutput Green "✓ 索引目录已创建: $IndexDir"
Write-Output ""

# 3. 分析项目结构
Write-ColorOutput Cyan "--- 分析项目结构 ---"

$HasCpp = $false
$HasVb = $false
$HasJava = $false
$HasVue = $false

# 当前日期
$CurrentDate = Get-Date -Format "yyyy-MM-dd"

# 检测 C++ 文件
$CppFiles = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.cpp","*.h","*.hpp" -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -notmatch "(\\build\\|\\.git\\|node_modules\\|\\.claude\\)"
    } | Measure-Object | Select-Object -ExpandProperty Count
if ($CppFiles -gt 0) {
    $HasCpp = $true
    Write-ColorOutput Green "✓ C++ 文件: $CppFiles 个"
}

# 检测 VB.NET 文件
$VbFiles = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.vb" -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -notmatch "(\\bin\\|\\obj\\|\\.git\\|\\.claude\\)"
    } | Measure-Object | Select-Object -ExpandProperty Count
if ($VbFiles -gt 0) {
    $HasVb = $true
    Write-ColorOutput Green "✓ VB.NET 文件: $VbFiles 个"
}

# 检测 JAVA 文件
$JavaFiles = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.java" -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -notmatch "(\\target\\|\\.git\\|\\.claude\\)"
    } | Measure-Object | Select-Object -ExpandProperty Count
if ($JavaFiles -gt 0) {
    $HasJava = $true
    Write-ColorOutput Green "✓ JAVA 文件: $JavaFiles 个"
}

# 检测 VUE 文件
$VueFiles = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.vue" -ErrorAction SilentlyContinue |
    Where-Object {
        $_.FullName -notmatch "(node_modules\\|\\.git\\|\\.claude\\)"
    } | Measure-Object | Select-Object -ExpandProperty Count
if ($VueFiles -gt 0) {
    $HasVue = $true
    Write-ColorOutput Green "✓ VUE 文件: $VueFiles 个"
}

# 4. 生成索引文件
Write-Output ""
Write-ColorOutput Cyan "--- 生成索引文件 ---"

# C++ 索引
if ($HasCpp) {
    $MesIndexPath = Join-Path $IndexDir "mes-core.md"
    $CppFileList = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.cpp","*.h","*.hpp" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch "(\\build\\|\\.git\\|node_modules\\|\\.claude\\)" } |
        Select-Object -First 100 |
        ForEach-Object { $_.FullName.Replace($ProjectRoot + "\", "").Replace("\", "/") }

    @"
# MES 核心文件索引

> **系统:** SiView MES (C++)
> **更新:** $CurrentDate
> **文件数:** $CppFiles

---

## 生成时间
$CurrentDate

## 文件列表

$($CppFileList | ForEach-Object { "- \`$($_)\`" }) -join "`n"
"@ | Out-File -FilePath $MesIndexPath -Encoding UTF8
    Write-ColorOutput Green "✓ 已生成 mes-core.md ($CppFiles 文件)"
} else {
    Write-ColorOutput Yellow "○ 跳过 mes-core.md (无 C++ 文件)"
}

# VB.NET 索引
if ($HasVb) {
    $EapIndexPath = Join-Path $IndexDir "eap-projects.md"
    $VbFileList = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.vb" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch "(\\bin\\|\\obj\\|\\.git\\|\\.claude\\)" } |
        Select-Object -First 100 |
        ForEach-Object { $_.FullName.Replace($ProjectRoot + "\", "").Replace("\", "/") }

    @"
# EAP 项目索引

> **系统:** Equipment Automation Program (VB.NET)
> **更新:** $CurrentDate
> **文件数:** $VbFiles

---

## 生成时间
$CurrentDate

## 文件列表

$($VbFileList | ForEach-Object { "- \`$($_)\`" }) -join "`n"
"@ | Out-File -FilePath $EapIndexPath -Encoding UTF8
    Write-ColorOutput Green "✓ 已生成 eap-projects.md ($VbFiles 文件)"
} else {
    Write-ColorOutput Yellow "○ 跳过 eap-projects.md (无 VB.NET 文件)"
}

# Web 索引
if ($HasJava -or $HasVue) {
    $WebIndexPath = Join-Path $IndexDir "web-modules.md"
    $Content = @"
# Web 模块索引

> **架构:** B/S (JAVA + VUE)
> **更新:** $CurrentDate

---

## 生成时间
$CurrentDate

"@

    if ($HasJava) {
        $JavaFileList = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.java" -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -notmatch "(\\target\\|\\.git\\|\\.claude\\)" } |
            Select-Object -First 50 |
            ForEach-Object { $_.FullName.Replace($ProjectRoot + "\", "").Replace("\", "/") }
        $Content += "### JAVA 文件`n`n"
        $Content += ($JavaFileList | ForEach-Object { "- \`$($_)\`" }) -join "`n"
        $Content += "`n`n"
    }
    if ($HasVue) {
        $VueFileList = Get-ChildItem -Path $ProjectRoot -Recurse -Include "*.vue" -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -notmatch "(node_modules\\|\\.git\\|\\.claude\\)" } |
            Select-Object -First 50 |
            ForEach-Object { $_.FullName.Replace($ProjectRoot + "\", "").Replace("\", "/") }
        $Content += "### VUE 文件`n`n"
        $Content += ($VueFileList | ForEach-Object { "- \`$($_)\`" }) -join "`n"
    }

    $Content | Out-File -FilePath $WebIndexPath -Encoding UTF8
    $TotalWeb = $JavaFiles + $VueFiles
    Write-ColorOutput Green "✓ 已生成 web-modules.md ($TotalWeb 文件)"
} else {
    Write-ColorOutput Yellow "○ 跳过 web-modules.md (无 JAVA/VUE 文件)"
}

# 5. 更新 CLAUDE.md 时间戳
Write-Output ""
Write-ColorOutput Cyan "--- 更新 CLAUDE.md ---"

$ClaudeContent = Get-Content $ClaudeMdPath -Raw -Encoding UTF8
$ClaudeContent = $ClaudeContent -replace '\*\*更新:\*\* \d{4}-\d{2}-\d{2}', "**更新:** $CurrentDate"
$ClaudeContent | Out-File -FilePath $ClaudeMdPath -Encoding UTF8 -NoNewline
Write-ColorOutput Green "✓ CLAUDE.md 时间戳已更新"

# 6. 显示结果
Write-Output ""
Write-ColorOutput Cyan "=== 更新完成 ==="
Write-Output ""
Write-ColorOutput Green "✓ CLAUDE.md 已更新"
Write-Output ""
Write-Output "当前项目配置:"
if ($HasCpp) { Write-Output "  ✓ C++    ($CppFiles 文件)" } else { Write-Output "  ○ C++    (未检测到)" }
if ($HasVb) { Write-Output "  ✓ VB.NET ($VbFiles 文件)" } else { Write-Output "  ○ VB.NET (未检测到)" }
if ($HasJava) { Write-Output "  ✓ JAVA   ($JavaFiles 文件)" } else { Write-Output "  ○ JAVA   (未检测到)" }
if ($HasVue) { Write-Output "  ✓ VUE    ($VueFiles 文件)" } else { Write-Output "  ○ VUE    (未检测到)" }
Write-Output ""
Write-Output "索引文件位置: $IndexDir"
