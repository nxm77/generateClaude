#!/bin/bash
# /update-claude - 更新项目配置
# 分析项目结构，更新代码索引和 CLAUDE.md 时间戳

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 获取项目根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo -e "${BLUE}=== CX 项目配置更新 ===${NC}"
echo ""

# 1. 验证 CLAUDE.md 存在
if [ ! -f "$PROJECT_ROOT/CLAUDE.md" ]; then
    echo -e "${RED}✗ CLAUDE.md 不存在${NC}"
    echo -e "${YELLOW}请先运行 /init 命令初始化项目${NC}"
    exit 1
fi
echo -e "${GREEN}✓ CLAUDE.md 存在${NC}"

# 2. 创建索引目录
INDEX_DIR="$PROJECT_ROOT/.claude/indexes"
mkdir -p "$INDEX_DIR"
echo -e "${GREEN}✓ 索引目录已创建: $INDEX_DIR${NC}"
echo ""

# 3. 分析项目结构
echo -e "${BLUE}--- 分析项目结构 ---${NC}"

HAS_CPP=false
HAS_VB=false
HAS_JAVA=false
HAS_VUE=false

# 检测 C++ 文件
CPP_FILES=$(find "$PROJECT_ROOT" -type f \( -name "*.cpp" -o -name "*.h" -o -name "*.hpp" \) \
    ! -path "*/build/*" ! -path "*/.git/*" ! -path "*/node_modules/*" \
    ! -path "*/.claude/*" 2>/dev/null | wc -l)
if [ "$CPP_FILES" -gt 0 ]; then
    HAS_CPP=true
    echo -e "${GREEN}✓ C++ 文件: $CPP_FILES 个${NC}"
fi

# 检测 VB.NET 文件
VB_FILES=$(find "$PROJECT_ROOT" -type f -name "*.vb" \
    ! -path "*/bin/*" ! -path "*/obj/*" ! -path "*/.git/*" \
    ! -path "*/.claude/*" 2>/dev/null | wc -l)
if [ "$VB_FILES" -gt 0 ]; then
    HAS_VB=true
    echo -e "${GREEN}✓ VB.NET 文件: $VB_FILES 个${NC}"
fi

# 检测 JAVA 文件
JAVA_FILES=$(find "$PROJECT_ROOT" -type f -name "*.java" \
    ! -path "*/target/*" ! -path "*/.git/*" \
    ! -path "*/.claude/*" 2>/dev/null | wc -l)
if [ "$JAVA_FILES" -gt 0 ]; then
    HAS_JAVA=true
    echo -e "${GREEN}✓ JAVA 文件: $JAVA_FILES 个${NC}"
fi

# 检测 VUE 文件
VUE_FILES=$(find "$PROJECT_ROOT" -type f -name "*.vue" \
    ! -path "*/node_modules/*" ! -path "*/.git/*" \
    ! -path "*/.claude/*" 2>/dev/null | wc -l)
if [ "$VUE_FILES" -gt 0 ]; then
    HAS_VUE=true
    echo -e "${GREEN}✓ VUE 文件: $VUE_FILES 个${NC}"
fi

# 4. 生成索引文件
echo ""
echo -e "${BLUE}--- 生成索引文件 ---${NC}"

# 当前日期
CURRENT_DATE=$(date +%Y-%m-%d)

# C++ 索引
if [ "$HAS_CPP" = true ]; then
    cat > "$INDEX_DIR/mes-core.md" << EOF
# MES 核心文件索引

> **系统:** SiView MES (C++)
> **更新:** $CURRENT_DATE
> **文件数:** $CPP_FILES

---

## 生成时间
$CURRENT_DATE

## 文件列表

EOF
    find "$PROJECT_ROOT" -type f \( -name "*.cpp" -o -name "*.h" -o -name "*.hpp" \) \
        ! -path "*/build/*" ! -path "*/.git/*" ! -path "*/node_modules/*" \
        ! -path "*/.claude/*" 2>/dev/null | head -100 | sed 's|^'"$PROJECT_ROOT"'/||' | \
        awk '{print "- \`" $1 "\`"}' >> "$INDEX_DIR/mes-core.md"
    echo -e "${GREEN}✓ 已生成 mes-core.md ($CPP_FILES 文件)${NC}"
else
    echo -e "${YELLOW}○ 跳过 mes-core.md (无 C++ 文件)${NC}"
fi

# VB.NET 索引
if [ "$HAS_VB" = true ]; then
    cat > "$INDEX_DIR/eap-projects.md" << EOF
# EAP 项目索引

> **系统:** Equipment Automation Program (VB.NET)
> **更新:** $CURRENT_DATE
> **文件数:** $VB_FILES

---

## 生成时间
$CURRENT_DATE

## 文件列表

EOF
    find "$PROJECT_ROOT" -type f -name "*.vb" \
        ! -path "*/bin/*" ! -path "*/obj/*" ! -path "*/.git/*" \
        ! -path "*/.claude/*" 2>/dev/null | head -100 | sed 's|^'"$PROJECT_ROOT"'/||' | \
        awk '{print "- \`" $1 "\`"}' >> "$INDEX_DIR/eap-projects.md"
    echo -e "${GREEN}✓ 已生成 eap-projects.md ($VB_FILES 文件)${NC}"
else
    echo -e "${YELLOW}○ 跳过 eap-projects.md (无 VB.NET 文件)${NC}"
fi

# Web 索引
if [ "$HAS_JAVA" = true ] || [ "$HAS_VUE" = true ]; then
    cat > "$INDEX_DIR/web-modules.md" << EOF
# Web 模块索引

> **架构:** B/S (JAVA + VUE)
> **更新:** $CURRENT_DATE

---

## 生成时间
$CURRENT_DATE

EOF
    if [ "$HAS_JAVA" = true ]; then
        echo "### JAVA 文件" >> "$INDEX_DIR/web-modules.md"
        find "$PROJECT_ROOT" -type f -name "*.java" \
            ! -path "*/target/*" ! -path "*/.git/*" \
            ! -path "*/.claude/*" 2>/dev/null | head -50 | sed 's|^'"$PROJECT_ROOT"'/||' | \
            awk '{print "- \`" $1 "\`"}' >> "$INDEX_DIR/web-modules.md"
        echo "" >> "$INDEX_DIR/web-modules.md"
    fi
    if [ "$HAS_VUE" = true ]; then
        echo "### VUE 文件" >> "$INDEX_DIR/web-modules.md"
        find "$PROJECT_ROOT" -type f -name "*.vue" \
            ! -path "*/node_modules/*" ! -path "*/.git/*" \
            ! -path "*/.claude/*" 2>/dev/null | head -50 | sed 's|^'"$PROJECT_ROOT"'/||' | \
            awk '{print "- \`" $1 "\`"}' >> "$INDEX_DIR/web-modules.md"
    fi
    TOTAL_WEB=$((JAVA_FILES + VUE_FILES))
    echo -e "${GREEN}✓ 已生成 web-modules.md ($TOTAL_WEB 文件)${NC}"
else
    echo -e "${YELLOW}○ 跳过 web-modules.md (无 JAVA/VUE 文件)${NC}"
fi

# 5. 更新 CLAUDE.md 时间戳
echo ""
echo -e "${BLUE}--- 更新 CLAUDE.md ---${NC}"

# 替换版本日期
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    sed -i '' "s/\*\*更新:\*\* [0-9]*/**更新:** $CURRENT_DATE/" "$PROJECT_ROOT/CLAUDE.md"
else
    # Linux
    sed -i "s/\*\*更新:\*\* [0-9]*/**更新:** $CURRENT_DATE/" "$PROJECT_ROOT/CLAUDE.md"
fi
echo -e "${GREEN}✓ CLAUDE.md 时间戳已更新${NC}"

# 6. 显示结果
echo ""
echo -e "${BLUE}=== 更新完成 ===${NC}"
echo ""
echo -e "${GREEN}✓ CLAUDE.md 已更新${NC}"
echo ""
echo "当前项目配置:"
[ "$HAS_CPP" = true ] && echo -e "  ${GREEN}✓${NC} C++    ($CPP_FILES 文件)" || echo "  ○ C++    (未检测到)"
[ "$HAS_VB" = true ] && echo -e "  ${GREEN}✓${NC} VB.NET ($VB_FILES 文件)" || echo "  ○ VB.NET (未检测到)"
[ "$HAS_JAVA" = true ] && echo -e "  ${GREEN}✓${NC} JAVA   ($JAVA_FILES 文件)" || echo "  ○ JAVA   (未检测到)"
[ "$HAS_VUE" = true ] && echo -e "  ${GREEN}✓${NC} VUE    ($VUE_FILES 文件)" || echo "  ○ VUE    (未检测到)"
echo ""
echo "索引文件位置: $INDEX_DIR"
