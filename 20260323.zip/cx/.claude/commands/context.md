---
description: "显示项目上下文和索引状态。支持操作: show, refresh, clear。"
---

# /context - 上下文管理

## 功能
显示项目上下文信息和索引状态。

## 用法
```
/context [action]
```

## 操作说明

| 操作 | 功能 |
|------|------|
| `show` | 显示当前上下文（默认） |
| `refresh` | 刷新代码索引 |
| `clear` | 清除规划文件 |

## 执行步骤

### show - 显示上下文

```
==================== 项目上下文 ====================

项目根目录: /path/to/project

--- 代码索引 ---
  [mes-core] 150 文件
  [eap-projects] 80 文件
  [web-modules] 200 文件

--- 记忆文件 ---
  MEMORY.md: 50 行
  lessons.md: 10 条经验

--- 规划文件 ---
  task_plan.md: 已更新 (2025-03-23 10:30:00)
  findings.md: 不存在
  progress.md: 已更新 (2025-03-23 11:00:00)

--- 检测到的技术栈 ---
  C++: ✓
  VB.NET: ✓
  JAVA: ✓
  VUE: ✗

==================================================
```

### refresh - 刷新索引
调用 `/update-claude` 命令刷新代码索引。

### clear - 清除规划文件
确认后删除：
- `task_plan.md`
- `findings.md`
- `progress.md`

## 使用示例

```bash
/context         # 显示上下文
/context refresh # 刷新索引
/context clear   # 清除规划文件
```
