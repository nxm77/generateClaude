---
description: "显示项目当前状态，包括配置、规划文件、索引、代码统计。"
---

# /status - 项目状态

## 功能
显示项目当前状态摘要。

## 执行步骤

```
==================== CX 项目状态 ====================

--- 项目信息 ---
  路径: /path/to/project
  Git: 分支=main, 提交=abc1234

--- 配置文件 ---
  CLAUDE.md:   ✓
  settings.json: ✓
  commands/:   ✓

--- 规划文件 ---
  task_plan.md: ✓ (120 行)
  findings.md:  ✗
  progress.md:  ✓ (45 行)

--- 代码索引 ---
  mes-core.md: 150 文件
  eap-projects.md: 80 文件
  web-modules.md: 200 文件

--- 代码统计 ---
  C++:    1500 文件
  VB.NET: 800 文件
  JAVA:   200 文件
  VUE:    100 文件

--- 可用命令 ---
  /init
  /update-claude
  /create-skill
  /learn
  /doc
  /diagram
  /context
  /status

==================================================
```

## 使用示例

```bash
/status    # 显示完整状态
```
