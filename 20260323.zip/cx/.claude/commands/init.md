---
description: "初始化项目 CLAUDE.md 配置文件。交互式选择项目类型（MES/EAP/Web/混合），创建 CLAUDE.md 和 MEMORY.md。"
---

# /init - 项目初始化

## 功能
在新项目中初始化 CLAUDE.md 配置文件和 MEMORY.md 记忆文件。

## 执行步骤

1. **检查现有 CLAUDE.md**
   - 如果已存在，询问用户是否覆盖
   - 备份原文件为 `CLAUDE.md.backup.YYYYMMDDHHmmss`

2. **询问项目类型**
   ```
   请选择项目类型:
     1) MES (C++ SiView)
     2) EAP (VB.NET)
     3) Web (JAVA + VUE)
     4) 混合项目
     5) 其他
   ```

3. **创建目录结构**
   - `.claude/memory/` 目录

4. **生成 CLAUDE.md**，包含：
   - 项目名称和类型
   - 快速开始命令表
   - 工作流选择说明
   - 技术栈信息
   - 编码规范
   - 项目结构
   - 常用命令说明

5. **生成 MEMORY.md**，包含：
   - 项目概述（创建日期、类型）
   - 重要经验（预留）
   - 常见问题（预留）

## 模板内容

### MES 项目
- 技术栈: C++, SiView API
- 规范: 单文件不超过 1000 行，函数不超过 100 行

### EAP 项目
- 技术栈: VB.NET, SECS/GEM
- 规范: 遵循匈牙利命名约定，Option Strict On

### Web 项目
- 技术栈: JAVA, Spring Boot, VUE
- 规范: RESTful API 设计，前端组件化

### 混合项目
- 技术栈: C++, VB.NET, JAVA, VUE
- 规范: 按模块分别遵循对应规范

## 完成后提示

```
✓ CLAUDE.md 已创建
✓ MEMORY.md 已创建
✓ 项目初始化完成

下一步: 使用 /update-claude 更新项目配置
```
