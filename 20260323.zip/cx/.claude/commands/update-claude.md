---
description: "分析项目结构，更新代码索引和 CLAUDE.md 时间戳。检测 C++/VB.NET/JAVA/VUE 文件并生成索引。"
---

# /update-claude - 更新项目配置

## 功能
根据当前项目状态更新 CLAUDE.md 和代码索引文件。

## 执行方式

### Windows (PowerShell)
```powershell
.\.claude\scripts\update-claude.ps1
```

### Linux/Mac (Bash)
```bash
bash .claude/scripts/update-claude.sh
```

或（如果已设置执行权限）：
```bash
.claude/scripts/update-claude.sh
```

---

## 执行步骤

脚本会自动执行以下步骤：

### 1. 验证 CLAUDE.md 存在
- 如果不存在，提示用户先运行 `/init`

### 2. 创建索引目录
- `.claude/indexes/` 目录

### 3. 分析项目结构
扫描以下类型文件：

| 类型 | 扩展名 | 排除目录 |
|------|--------|---------|
| C++ | `.cpp`, `.h`, `.hpp` | `build/`, `.git/`, `node_modules/` |
| VB.NET | `.vb` | `bin/`, `obj/`, `.git/` |
| JAVA | `.java` | `target/`, `.git/` |
| VUE | `.vue` | `node_modules/`, `.git/` |

### 4. 生成索引文件

| 索引文件 | 内容 | 最大文件数 |
|---------|------|-----------|
| `mes-core.md` | C++ 文件列表 | 100 |
| `eap-projects.md` | VB.NET 文件列表 | 100 |
| `web-modules.md` | JAVA/VUE 文件列表 | 100 (各50) |

### 5. 更新 CLAUDE.md 时间戳
- 将 `**更新:** YYYY-MM-DD` 替换为当前日期

---

## 输出示例

```
=== CX 项目配置更新 ===

✓ CLAUDE.md 存在
✓ 索引目录已创建: D:\cx\.claude\indexes

--- 分析项目结构 ---
✓ C++ 文件: 45 个
✓ VB.NET 文件: 120 个
✓ JAVA 文件: 0 个
✓ VUE 文件: 0 个

--- 生成索引文件 ---
✓ 已生成 mes-core.md (45 文件)
✓ 已生成 eap-projects.md (120 文件)
○ 跳过 web-modules.md (无 JAVA/VUE 文件)

--- 更新 CLAUDE.md ---
✓ CLAUDE.md 时间戳已更新

=== 更新完成 ===

✓ CLAUDE.md 已更新

当前项目配置:
  ✓ C++    (45 文件)
  ✓ VB.NET (120 文件)
  ○ JAVA   (未检测到)
  ○ VUE    (未检测到)

索引文件位置: D:\cx\.claude\indexes
```

---

## 索引文件格式

生成的索引文件使用 Markdown 列表格式：

```markdown
# MES 核心文件索引

> **系统:** SiView MES (C++)
> **更新:** 2025-03-23
> **文件数:** 45

---

## 生成时间
2025-03-23

## 文件列表

- `src/core/executor/Executor.cpp`
- `src/core/executor/Executor.h`
- `src/communication/DeviceCommunicator.cpp`
...
```

---

## 首次使用

如果 `CLAUDE.md` 不存在，请先运行 `/init` 命令初始化项目配置。
