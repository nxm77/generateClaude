---
description: "生成图表，支持 PlantUML 和 Mermaid 两种格式。类型: flow, sequence, state, class, component。"
---

# /diagram - 图表生成 (PlantUML + Mermaid)

## 功能
生成图表模板，支持 **PlantUML** 和 **Mermaid** 两种格式。可参考已有 PUML 文件保持风格一致。

## 用法
```
/diagram [type] [名称] [--format=plantuml|mermaid] [--ref=<文件路径>]
```

### 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `type` | 图表类型 | flow, sequence, state, class, component |
| `名称` | 图表名称/描述 | "设备登录流程" |
| `--format` | 输出格式 | plantuml (默认) 或 mermaid |
| `--ref` | 参考示例文件 | `--ref=./docs/diagrams/existing.puml` |

## 类型说明

| 类型 | 图表 | 用途 |
|------|------|------|
| `flow` | 活动图/流程图 | 设备通信流程、业务流程 |
| `sequence` | 时序图 | 设备登录时序、API 交互 |
| `state` | 状态图 | 设备状态机 |
| `class` | 类图 | 数据模型 |
| `component` | 组件图 | 模块关系 |
| `suggest` | 推荐 | 显示推荐图表类型 |

## 格式选择

| 格式 | 优点 | 适用场景 |
|------|------|---------|
| **PlantUML** | 功能强大，支持更多图表类型 | 复杂状态机、详细组件图 |
| **Mermaid** | 原生支持 Markdown，VS Code/GitHub 直接渲染 | 快速文档、简单图表 |

**默认格式**: PlantUML

---

## PlantUML 模板

### 活动图模板 (flow)
```plantuml
@startuml [name]

skinparam backgroundColor #FEFEFE
skinparam activity {
  BackgroundColor #E3F2FD
  BorderColor #2196F3
  FontColor #000000
}
skinparam decision {
  BackgroundColor #FFF3E0
  BorderColor #FF9800
}
skinparam note {
  BackgroundColor #E8F5E9
  BorderColor #4CAF50
}

start
:[起始步骤];

if (条件判断?) then (是)
  :分支处理 A;
else (否)
  :分支处理 B;
endif

:后续处理;

note right
  注释说明
  可多行
end note

stop

@enduml
```

### 时序图模板 (sequence)
```plantuml
@startuml [name]

skinparam backgroundColor #FEFEFE
skinparam sequence {
  ArrowColor #2196F3
  LifeLineBorderColor #9E9E9E
  ParticipantBackgroundColor #E3F2FD
  ParticipantBorderColor #2196F3
}

actor User
participant Server
participant Device

User ->> Server: 发送请求
Server ->> Device: 转发命令
Device -->> Server: 返回响应
Server -->> User: 返回结果

@enduml
```

### 状态图模板 (state)
```plantuml
@startuml [name]

skinparam state {
  BackgroundColor #E3F2FD
  BorderColor #2196F3
  FontColor #000000
}

[*] --> DISABLED: 初始化
DISABLED --> NOT_CONNECTED: 使能
NOT_CONNECTED --> COMMUNICATING: 建立通信
COMMUNICATING --> ONLINE: S1F17 在线数据
ONLINE --> COMMUNICATING: ENABLE_CONTROL
ONLINE --> NOT_CONNECTED: 断开

@enduml
```

---

## Mermaid 模板

### 流程图模板 (flow)
```mermaid
flowchart TD
    A([开始]) --> B[起始步骤]
    B --> C{条件判断?}
    C -->|是| D[分支处理 A]
    C -->|否| E[分支处理 B]
    D --> F[后续处理]
    E --> F
    F --> G([结束])

    style A fill:#E8F5E9
    style G fill:#FFEBEE
    style C fill:#FFF3E0
```

### 时序图模板 (sequence)
```mermaid
sequenceDiagram
    actor User as 用户
    participant Server as 服务器
    participant Device as 设备

    User->>Server: 发送请求
    Server->>Device: 转发命令 (SECS/GEM)
    Device-->>Server: 返回响应
    Server-->>User: 返回结果
```

### 状态图模板 (state)
```mermaid
stateDiagram-v2
    [*] --> DISABLED: 初始化
    DISABLED --> NOT_CONNECTED: 使能
    NOT_CONNECTED --> COMMUNICATING: 建立通信
    COMMUNICATING --> ONLINE: 在线确认
    ONLINE --> COMMUNICATING: ENABLE_CONTROL
    ONLINE --> NOT_CONNECTED: 断开
```

### 类图模板 (class)
```mermaid
classDiagram
    class BaseModel {
        +String id
        +DateTime createdAt
    }
    class Device {
        +String name
        +DeviceState state
        +connect()
        +sendCommand()
    }
    class Recipe {
        +String name
        +List steps
        +validate()
    }

    Device --> BaseModel
    Recipe --> BaseModel
```

### 组件图模板 (component)
```mermaid
flowchart LR
    MES[MES系统] --> EAP[EAP系统]
    EAP --> Device1[设备1]
    EAP --> Device2[设备2]

    style MES fill:#E3F2FD
    style EAP fill:#FFF3E0
    style Device1 fill:#E8F5E9
    style Device2 fill:#E8F5E9
```

---

## 查看方式

### PlantUML
| 方式 | 说明 |
|------|------|
| VS Code 插件 | 安装 PlantUML 插件，预览 .puml 文件 |
| 本地渲染 | `java -jar plantuml.jar diagram.puml` |
| 局域网服务器 | 搭建 PlantUML Server |

### Mermaid
| 方式 | 说明 |
|------|------|
| VS Code | 安装 Markdown Preview Mermaid 插件 |
| GitHub/GitLab | 直接在 Markdown 中渲染 |
| 在线编辑器 | [Mermaid Live Editor](https://mermaid.live) |

---

## 推荐图表

### MES/EAP 项目
| 场景 | 推荐格式 | 命令 |
|------|---------|------|
| 设备握手流程 | PlantUML | `/diagram flow` |
| 设备登录时序 | Mermaid | `/diagram sequence --format=mermaid` |
| 设备状态机 | PlantUML | `/diagram state` |
| 系统组件关系 | Mermaid | `/diagram component --format=mermaid` |

### Web 项目
| 场景 | 推荐格式 | 命令 |
|------|---------|------|
| 数据模型 | Mermaid | `/diagram class --format=mermaid` |
| API 交互 | Mermaid | `/diagram sequence --format=mermaid` |
| 模块架构 | PlantUML | `/diagram component` |

---

## 使用示例

```bash
# PlantUML (默认)
/diagram flow                     # 流程图
/diagram sequence                 # 时序图
/diagram state                    # 状态图

# 带名称
/diagram flow "设备登录流程"

# Mermaid 格式
/diagram flow --format=mermaid
/diagram sequence --format=mermaid

# 参考已有示例 (保持风格一致)
/diagram flow "新流程" --ref=./docs/diagrams/existing-flow.puml
/diagram state "设备状态" --ref=./docs/diagrams/device-state.puml

# 显示推荐
/diagram suggest
```

### --ref 参数工作原理

使用 `--ref` 参数时，生成的新图表会：
1. **继承样式** - 复用参考文件的 skinparam 样式设置
2. **保持结构** - 参考参考文件的布局结构
3. **调整内容** - 根据新的描述替换业务逻辑

```bash
# 示例：参考现有状态机生成新状态机
/diagram state "清洗设备状态机" --ref=./docs/diagrams/etcher-state.puml
```

生成结果将保留 `etcher-state.puml` 的配色方案和布局结构，但内容替换为清洗设备的状态转换逻辑。
