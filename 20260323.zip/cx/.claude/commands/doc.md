---
description: "生成项目文档。支持类型: api, architecture, readme, all。"
---

# /doc - 文档生成

## 功能
生成项目文档到 `docs/` 目录。

## 用法
```
/doc [type] [--ref=<模板文件路径>]
```

### 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `type` | 文档类型 | api, architecture, readme, all |
| `--ref` | 参考模板文件 | `--ref=./docs/PRD-template.md` |

## 类型说明

| 类型 | 生成内容 |
|------|---------|
| `api` | API 文档 (docs/API.md) |
| `architecture` | 架构文档 (docs/ARCHITECTURE.md) |
| `readme` | 项目 README (README.md) |
| `all` | 生成全部文档 |

## 执行步骤

### API 文档
生成 `docs/API.md`，包含：
- 概述
- MES API
- EAP API
- Web API

### 架构文档
生成 `docs/ARCHITECTURE.md`，包含：
- 系统组成（MES/EAP/Web）
- 架构图（Mermaid 格式）
- 数据流说明

```mermaid
graph TB
    subgraph MES
        MES1[核心模块]
        MES2[调度模块]
    end
    subgraph EAP
        EAP1[设备通信]
        EAP2[数据采集]
    end
    subgraph Web
        WEB1[后端API]
        WEB2[前端UI]
    end
    MES1 --> EAP1
    EAP2 --> WEB1
    WEB1 --> WEB2
```

### README
生成 `README.md`，包含：
- 项目描述
- 快速开始
- 环境要求
- 构建说明
- 项目结构
- 文档链接

## 使用示例

```bash
/doc          # 显示用法
/doc api      # 生成 API 文档
/doc arch     # 生成架构文档
/doc readme   # 生成 README
/doc all      # 生成全部文档

# 参考模板生成 (保持文档风格一致)
/doc readme --ref=./docs/README-template.md
/doc architecture --ref=./docs/ARCH-template.md
```

### --ref 参数说明

使用 `--ref` 参数时，新文档会：
1. **继承结构** - 复用模板文件的章节结构
2. **保持格式** - 复用模板的 Markdown 格式风格
3. **填充内容** - 根据项目实际情况填充内容

```bash
# 示例：参考公司标准模板生成需求文档
/doc --requirements --ref=./templates/company-prd-template.md
```
