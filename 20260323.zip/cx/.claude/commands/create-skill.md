---
description: "分析代码并生成项目专用 Skill 文件。支持 --depth 参数控制分析深度（shallow/standard/deep）。"
---

# /create-skill - 生成项目 Skill

## 功能
分析项目代码并生成项目专用的 Skill 文件，记录技术栈、代码模式、重要文件等信息。

## 参数
- `--depth shallow` - 快速分析（~50 文件）
- `--depth standard` - 标准分析（~200 文件，默认）
- `--depth deep` - 深度分析（~500 文件）

## 执行步骤

1. **创建 skills 目录**
   - `.claude/skills/` 目录

2. **检测项目信息**
   - 项目名称（从 Git URL 或目录名）
   - 代码统计（C++/VB.NET/JAVA/VUE 文件数量）

3. **生成 Skill 文件**
   - 文件位置: `.claude/skills/project-{name}.md`

4. **Skill 文件结构**

   ```markdown
   # {项目名称} 项目专用 Skill

   > **自动生成:** {日期}
   > **分析深度:** {depth}

   ## 项目概述
   - 项目名称
   - 项目根目录
   - 分析时间

   ## 技术栈
   - C++: X 个文件
   - VB.NET: X 个文件
   - JAVA: X 个文件
   - VUE: X 个文件

   ## 代码模式
   ### 命名约定
   - C++: PascalCase, camelCase, UPPER_SNAKE_CASE
   - VB.NET: 匈牙利命名法
   - JAVA: 驼峰命名法
   - VUE: kebab-case

   ## 重要文件
   ### 配置文件
   [列出的配置文件]

   ## 更新历史
   - {日期}: 初始生成
   ```

5. **显示结果**

   ```
   ✓ Skill 已生成: .claude/skills/project-{name}.md

   请手动审查和补充 Skill 内容
   包含文件: CXX(XX) VB(XX) JAVA(XX) VUE(XX)
   ```

## 使用示例

```bash
/create-skill              # 标准分析
/create-skill --depth shallow  # 快速分析
/create-skill --depth deep     # 深度分析
```
