---
description: "记录编码经验到 memory/lessons.md。支持类型: error, pattern, performance, anti-pattern, convention, debug。"
---

# /learn - 记录编码经验

## 功能
记录开发过程中遇到的问题和解决方案到 `.claude/memory/lessons.md`。

## 用法
```
/learn <type> <content>
```

## 类型说明

| 类型 | 标签 | 用途 |
|------|------|------|
| `error` | 🔴 错误 | 记录错误和解决方案 |
| `pattern` | ✅ 模式 | 记录代码模式 |
| `performance` | ⚡ 性能 | 记录性能优化 |
| `anti-pattern` | ⚠️ 反模式 | 记录反模式 |
| `convention` | 📋 规范 | 记录编码规范 |
| `debug` | 🔍 调试 | 记录调试经验 |

## 执行步骤

1. **创建 memory 目录**
   - `.claude/memory/` 目录

2. **验证参数**
   - 类型必须是支持的类型之一
   - 内容不能为空

3. **创建/更新 lessons.md**

   ```markdown
   ## 🔴 错误 - 2025-03-23

   **类型:** error
   **时间:** 2025-03-23 14:30:00

   SECS通信超时问题 - 需要调整T1超时时间
   ```

4. **同步到 MEMORY.md**
   - 在 MEMORY.md 的"重要经验"部分添加简略记录

5. **显示结果**

   ```
   ✓ 经验已记录到: .claude/memory/lessons.md

   记录内容:
     类型: error
     内容: SECS通信超时问题...

   当前已记录 X 条经验
   ```

## 使用示例

```bash
/learn error SECS通信超时 - T1超时从5秒改为10秒解决
/learn pattern 单例模式在EAP中的应用
/learn performance 使用StringBuilder代替字符串拼接
/learn convention VB.NET变量使用strValue/nCount/bFlag命名
/learn debug 设备断线重连问题的调试方法
```
