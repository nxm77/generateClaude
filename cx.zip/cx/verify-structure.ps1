# 验证 CX 工具结构完整性

Write-Host "验证 CX 工具结构..." -ForegroundColor Cyan

$errors = @()

# 检查主脚本
if (-not (Test-Path "generate-docs.ps1")) {
    $errors += "缺少主脚本: generate-docs.ps1"
}

# 检查 skills 目录
$requiredSkills = @(
    "skills/deep-analyzer/analyze-project-info.md",
    "skills/deep-analyzer/analyze-architecture.md",
    "skills/deep-analyzer/analyze-apis.md",
    "skills/deep-analyzer/analyze-data-models.md",
    "skills/deep-analyzer/analyze-business-flows.md",
    "skills/deep-analyzer/analyze-dependencies.md",
    "skills/deep-analyzer/analyze-security.md",
    "skills/deep-analyzer/analyze-file-tree.md",
    "skills/gen-claude-md.md",
    "skills/gen-requirements.md",
    "skills/gen-file-spec.md",
    "skills/gen-system-overview.md",
    "skills/gen-module-diagrams.md",
    "skills/gen-flow-diagrams.md"
)

foreach ($skill in $requiredSkills) {
    if (-not (Test-Path $skill)) {
        $errors += "缺少 skill: $skill"
    }
}

# 检查参考文档
if (-not (Test-Path "ref/requirements.md")) {
    Write-Host "[WARNING] 缺少参考文档: ref/requirements.md" -ForegroundColor Yellow
}
if (-not (Test-Path "ref/file-specification.md")) {
    Write-Host "[WARNING] 缺少参考文档: ref/file-specification.md" -ForegroundColor Yellow
}

# 输出结果
if ($errors.Count -eq 0) {
    Write-Host "`n✓ 结构验证通过！" -ForegroundColor Green
    Write-Host "  - 主脚本: 1 个" -ForegroundColor Green
    Write-Host "  - 深度分析 skills: 8 个" -ForegroundColor Green
    Write-Host "  - 文档生成 skills: 6 个" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n✗ 发现 $($errors.Count) 个问题：" -ForegroundColor Red
    foreach ($error in $errors) {
        Write-Host "  - $error" -ForegroundColor Red
    }
    exit 1
}
