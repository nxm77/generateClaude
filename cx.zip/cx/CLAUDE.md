# cx - 自动化项目文档生成工具

PowerShell 脚本 + Claude Code skill，用于自动分析项目代码并生成结构化技术文档。

## 运行方式

```powershell
# 基础模式：扫描文件结构，生成文件功能列表
.\generate-docs-smart.ps1

# 深度分析模式：调用 Claude CLI 进行代码深度分析
.\generate-docs-smart.ps1 -Deep

# 指定项目路径
.\generate-docs-smart.ps1 -Path "C:\path\to\project"
```

依赖：Claude Code CLI（`claude` 命令），深度分析模式需要。

## 架构

- `generate-docs-smart.ps1` — 主脚本，负责项目扫描、语言/框架检测、文档生成。深度模式下读取 skill 模板内容作为 prompt，通过 `claude -p` 执行分析。
- `project-deep-analyzer.md` — Claude Code skill 定义，描述深度分析的流程和输出格式（API 端点、数据模型、业务流程、架构信息），输出 `.analysis-report.json`。

## 约定

- 中文注释和输出
- PowerShell 脚本风格
- skill 模板路径查找顺序：`.claude\skills\` → `$env:USERPROFILE\.claude\skills\`
