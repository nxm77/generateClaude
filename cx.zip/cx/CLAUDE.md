# cx - 自动化项目文档生成工具

PowerShell 脚本 + Claude Code skill，用于自动分析项目代码并生成结构化技术文档。

## 运行方式

```cmd
# 生成所有文档（推荐使用 .bat 启动，无需管理员权限）
generate-docs.bat

# 指定项目路径
generate-docs.bat -Path "D:\path\to\project"

# 只生成 CLAUDE.md
generate-docs.bat -ClaudeMd

# 跳过深度分析，使用缓存（默认每次都做深度分析）
generate-docs.bat -UseCache
```

依赖：Claude Code CLI（`claude` 命令）。

## 架构

- `generate-docs.bat` — 启动器，设置 UTF-8 编码，自动检测 pwsh/powershell.exe，以 `-ExecutionPolicy Bypass` 调用 PowerShell 脚本。
- `generate-docs.ps1` — 主脚本，项目扫描、语言/框架检测、文档生成。通过临时文件将 skill 模板传递给 Claude CLI（`claude -p <prompt-file> --append-system-prompt <system-file>`），避免 Windows 命令行长度限制。核心函数：
  - `Invoke-Skill` — 统一的 skill 调用（合并了分析和生成逻辑）
  - `Invoke-SkillBatch` — 批量执行 skill 并追踪成功/失败
  - `Invoke-ClaudeWithTimeout` — 异步 stdout 读取 + 超时控制 + taskkill 进程树清理
- `skills/` — skill 模板目录，包含深度分析和文档生成的 prompt 定义。

## 约定

- 代码注释使用英文，控制台输出使用英文
- PowerShell 脚本风格
- skill 模板路径查找顺序：项目目录 `.claude\skills\` → cx 工具目录 `skills\`
