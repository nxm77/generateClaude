# cx - 自动化项目文档生成工具

PowerShell 脚本 + Claude Code skill，用于自动分析项目代码并生成结构化技术文档。

## 运行方式

```cmd
# 生成所有文档（推荐使用 .bat 启动，无需管理员权限）
generate-docs.bat

# 指定项目路径
generate-docs.bat -Path "D:\path\to\project"

# 只生成 CLAUDE.md
generate-docs.bat -ClaudeMd

# 强制重新分析
generate-docs.bat -ForceAnalysis
```

依赖：Claude Code CLI（`claude` 命令）。

## 架构

- `generate-docs.bat` — 启动器，设置 UTF-8 编码并以 `-ExecutionPolicy Bypass` 调用 PowerShell 脚本，兼容无管理员权限环境。
- `generate-docs.ps1` — main script, handles project scanning, language/framework detection, document generation. Reads skill template content and passes it to Claude CLI via `claude -p --append-system-prompt`.
- `skills/` — skill 模板目录，包含深度分析和文档生成的 prompt 定义。

## 约定

- 中文注释和输出
- PowerShell 脚本风格
- skill 模板路径查找顺序：项目目录 `.claude\skills\` → cx 工具目录 `skills\`
