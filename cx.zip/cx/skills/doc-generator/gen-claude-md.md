---
name: gen-claude-md
description: 生成 CLAUDE.md 项目说明文档
---

# 生成 CLAUDE.md

## 任务

根据所有分析结果，生成项目的 `CLAUDE.md` 文档，提供项目概述、技术栈、结构、依赖、配置等信息。

## 输入信息

- 所有 8 个分析 JSON 文件：
  - project-info.json
  - architecture.json
  - apis.json
  - data-models.json
  - business-flows.json
  - dependencies.json
  - security.json
  - file-tree.json

## 输出文件

- `.claude/CLAUDE.md`（同时复制到项目根目录）

## 文档结构

```markdown
# {project_name}

> 如需自定义文档生成逻辑，可在项目的 `.claude/skills/` 目录下
> 创建同名 skill 文件（如 `gen-requirements.md`）来替换默认模板

## 项目概述

{从 architecture.json 的 overview 提取}

项目类型：{从 project-info.json 的 project_type}

## 技术栈

### 编程语言
{从 project-info.json 的 languages}

### 框架
- 后端：{从 project-info.json 的 frameworks.backend}
- 前端：{从 project-info.json 的 frameworks.frontend}
- 其他：{从 project-info.json 的 frameworks.other}

### 数据库
{从 dependencies.json 的 external_packages 中提取数据库相关依赖}

## 项目结构

{从 architecture.json 的 modules 生成}

```
{project_name}/
├── {module1_path}     # {module1_description}
├── {module2_path}     # {module2_description}
└── ...
```

### 模块说明

#### {module1_name}
- 路径：`{module1_path}`
- 类型：{module1_type}
- 描述：{module1_description}
- 关键组件：
  - {component1}
  - {component2}
- 入口文件：{entry_files}
- 端口：{ports}

## 依赖清单

### 运行时依赖
{从 dependencies.json 的 external_packages.runtime 生成表格}

| 包名 | 版本 | 类别 |
|------|------|------|
| {name} | {version} | {category} |

### 开发依赖
{从 dependencies.json 的 external_packages.development 生成表格}

## API 端点

{从 apis.json 提取主要端点，按模块分组}

### {module_name}

| 方法 | 路径 | 描述 | 认证 |
|------|------|------|------|
| {method} | {path} | {description} | {auth_required} |

## 数据模型

{从 data-models.json 提取核心模型}

### {model_name}
- 描述：{description}
- 文件：`{file}`
- 字段：
  - `{field_name}` ({type}): {constraints}

## 配置说明

### 环境变量
{推断需要的环境变量，基于 security.json 和 architecture.json}

```bash
# 数据库配置
DB_HOST=localhost
DB_PORT=3306
DB_NAME=database_name
DB_USER=username
DB_PASSWORD=password

# 应用配置
PORT=5000
NODE_ENV=production

# 认证配置
JWT_SECRET=your_secret_key
```

### 端口配置
{从 architecture.json 的 modules[].ports 提取}

| 服务 | 端口 | 说明 |
|------|------|------|
| {module_name} | {port} | {description} |

## 安全注意事项

{从 security.json 的 issues 提取高严重性问题}

⚠️ **发现的安全问题**：
- {issue_description} ({file})
  - 建议：{recommendation}

✅ **已实施的安全措施**：
{从 security.json 的 best_practices 中提取 status=implemented 的项}

## 开发指南

### 安装依赖
{根据 project-info.json 的 languages 和 frameworks 生成}

```bash
# Node.js 项目
npm install

# Python 项目
pip install -r requirements.txt

# Java 项目
mvn install
```

### 运行项目
{根据 architecture.json 的 entry_files 推断}

```bash
# 开发模式
npm run dev

# 生产模式
npm start
```

### 运行测试
```bash
npm test
```

## 项目统计

- 代码文件：{从 project-info.json 的 statistics.code_files}
- 代码行数：{从 project-info.json 的 statistics.code_lines}
- 模块数量：{从 architecture.json 的 modules 数量}
- API 端点：{从 apis.json 的 endpoints 数量}
- 数据模型：{从 data-models.json 的 models 数量}

---

*本文档由 CX 工具自动生成于 {analysis_time}*
```

## 生成步骤

1. 读取所有 8 个 JSON 文件
2. 按照模板结构组织内容
3. 使用 Write 工具生成 `.claude/CLAUDE.md`
4. 使用 Write 工具将相同内容写入项目根目录 `CLAUDE.md`

## 注意事项

- 如果某个 JSON 文件不存在或解析失败，跳过对应部分
- 表格应对齐，使用 Markdown 表格格式
- 代码块使用正确的语言标识（bash、json、javascript 等）
- 文件路径使用反引号包裹
- 安全问题应突出显示（使用 ⚠️ 和 ✅ 符号）
