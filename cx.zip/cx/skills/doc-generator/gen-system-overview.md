---
name: gen-system-overview
description: 生成系统总览图（PlantUML）
---

# 生成系统总览图

## 任务

根据架构分析结果，生成系统总览图（C4 Container Diagram），使用 PlantUML 格式。

## 输入信息

- architecture.json（架构信息）
- dependencies.json（依赖信息）

## 输出文件

- `.claude/diagrams/system-overview.puml`

## 图表类型

使用原生 PlantUML 语法生成 C4 风格的系统总览图，不依赖任何宏或外部 include，兼容所有 PlantUML 版本。

## PlantUML 模板

```plantuml
@startuml
skinparam defaultTextAlignment center
skinparam shadowing false

skinparam rectangle {
    BorderColor #438DD5
    BackgroundColor #438DD5
    FontColor #FFFFFF
}

skinparam database {
    BorderColor #438DD5
    BackgroundColor #438DD5
    FontColor #FFFFFF
}

title 系统总览图 - {project_name}

actor "用户\n<size:10>[系统使用者]</size>" as user

{根据 architecture.json 的 modules 生成容器}

rectangle "{project_name}" as system {
    rectangle "{frontend_module_name}\n<size:10>[{frontend_technologies}]</size>\n\n<size:10>{frontend_description}</size>" as frontend
    rectangle "{backend_module_name}\n<size:10>[{backend_technologies}]</size>\n\n<size:10>{backend_description}</size>" as backend
    database "数据库\n<size:10>[{database_type}]</size>\n\n<size:10>存储应用数据</size>" as database
}

{根据 dependencies.json 的 external_packages 生成外部系统}
rectangle "外部 API\n\n<size:10>第三方服务</size>" as external_api #999999

{根据 architecture.json 的 dependencies 生成关系}
user --> frontend : "访问\n<size:10>[HTTPS]</size>"
frontend --> backend : "调用 API\n<size:10>[HTTP/JSON]</size>"
backend --> database : "读写数据\n<size:10>[SQL]</size>"
backend --> external_api : "调用\n<size:10>[HTTPS]</size>"

@enduml
```

## 生成步骤

1. **识别容器**：
   - 从 architecture.json 的 modules 提取
   - 前端模块 → `rectangle "名称\n<size:10>[技术栈]</size>\n\n<size:10>描述</size>" as frontend`
   - 后端模块 → `rectangle "名称\n<size:10>[技术栈]</size>\n\n<size:10>描述</size>" as backend`
   - 数据库 → `database "名称\n<size:10>[类型]</size>\n\n<size:10>描述</size>" as db`

2. **识别外部系统**：
   - 从 dependencies.json 的 external_packages 提取
   - 如果有外部 API 调用（如 Stripe、AWS、第三方服务）→ `rectangle "名称" as alias #999999`

3. **生成关系**：
   - 用户 → 前端：`user --> frontend : "访问\n<size:10>[HTTPS]</size>"`
   - 前端 → 后端：`frontend --> backend : "调用 API\n<size:10>[HTTP/JSON]</size>"`
   - 后端 → 数据库：`backend --> db : "读写数据\n<size:10>[SQL]</size>"`
   - 后端 → 外部系统：`backend --> external : "调用\n<size:10>[HTTPS]</size>"`

4. **推断技术栈**：
   - 从 architecture.json 的 modules[].key_components 提取
   - 从 project-info.json 的 frameworks 提取

5. **推断数据库类型**：
   - 从 dependencies.json 的 external_packages 中查找数据库驱动
   - mysql/mysql2 → "MySQL"
   - pg/postgres → "PostgreSQL"
   - mongodb → "MongoDB"
   - sqlite/better-sqlite3 → "SQLite"
   - redis/ioredis → "Redis"

## 架构适配

根据 project-info.json 的 project_type 调整图表结构：

- **web_app**（前后端分离）：使用模板中的标准结构（actor + frontend + backend + database）
- **monolith**（单体应用）：省略 frontend，只展示 backend 内部分层
- **microservices**：每个服务一个 rectangle，服务间用箭头连接
- **cli_tool**：省略 actor 和 frontend，展示 CLI 入口 → 核心模块 → 外部依赖
- **library**：展示公共 API 层 → 内部模块 → 依赖
- **blockchain_platform**：增加合约层和链上交互

如果项目没有数据库，省略 database 元素。如果没有外部 API 调用，省略 external 元素。

## 容器命名规则

- 前端：frontend、client、web、ui
- 后端：backend、api、server、service
- 数据库：database、db
- 缓存：cache、redis
- 消息队列：queue、mq

## 关系类型

- 用户交互：HTTPS、WebSocket
- API 调用：HTTP/JSON、REST、GraphQL
- 数据访问：SQL、NoSQL
- 消息传递：AMQP、Kafka

## 注意事项

- 使用原生 PlantUML 语法（无宏、无外部 include，兼容所有版本）
- 容器用 `rectangle` + skinparam 着色，数据库用 `database`，外部系统用 `#999999` 灰色
- 容器名称使用小写字母和下划线
- 描述应简洁明了
- 模块数量根据实际架构决定，优先完整呈现，过多时适当归类
- 确保 PlantUML 语法正确，可以被渲染
- 使用 UTF-8 编码保存文件
