---
name: gen-system-overview
description: 生成系统总览图（PlantUML 格式）
---

# 生成系统总览图

## 任务

生成一个 PlantUML 格式的系统总览图文件。

## 输出文件

`.claude/diagrams/system-overview.puml`

## 要求

1. 必须使用 Write 工具创建 `.puml` 文件
2. 文件必须以 `@startuml` 开头，`@enduml` 结尾
3. 使用以下配色方案：

```plantuml
@startuml
skinparam shadowing false
skinparam backgroundColor #FEFEFE

skinparam actor {
    BorderColor #2C3E50
    BackgroundColor #ECF0F1
    FontColor #2C3E50
}

skinparam rectangle {
    BorderColor #3498DB
    BackgroundColor #EBF5FB
    FontColor #2C3E50
}

skinparam database {
    BorderColor #E74C3C
    BackgroundColor #FADBD8
    FontColor #2C3E50
}

skinparam arrow {
    Color #7F8C8D
}

title 系统总览图 - cx

actor "用户" as user

rectangle "cx 工具" {
    rectangle "启动层\n[Batch/PS]" as launcher
    rectangle "核心脚本\n[PowerShell]" as core
    rectangle "Skill 模板\n[Markdown]" as skills
}

rectangle "Claude CLI" as claude #D5E8D4
rectangle "输出目录\n[.claude/]" as output #D5E8D4

user --> launcher : "执行"
launcher --> core : "调用"
core --> skills : "读取"
core --> claude : "AI 分析"
claude --> output : "写入结果"

@enduml
```

## 执行步骤

1. Read `architecture.json` 获取架构信息
2. 使用 Write 工具创建 `system-overview.puml`
3. 确保 PlantUML 语法正确

**不要输出任何说明文字，只生成 .puml 文件。**
