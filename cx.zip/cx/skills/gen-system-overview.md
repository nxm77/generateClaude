---
name: gen-system-overview
description: 生成系统总览图（PlantUML）
---

# 生成系统总览图

## 任务

根据架构分析结果，生成系统总览图（C4 Container Diagram），使用 PlantUML 格式。

## 输入信息

- architecture.json（架构信息）
- dependencies.json（依赖信息）

## 输出文件

- `.claude/diagrams/system-overview.puml`

## 图表类型

使用 C4 Container Diagram 展示系统的容器（应用、服务、数据库）及其关系。

## PlantUML 模板

```plantuml
@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

title 系统总览图 - {project_name}

Person(user, "用户", "系统使用者")

{根据 architecture.json 的 modules 生成容器}

System_Boundary(system, "{project_name}") {
    Container(frontend, "{frontend_module_name}", "{frontend_technologies}", "{frontend_description}")
    Container(backend, "{backend_module_name}", "{backend_technologies}", "{backend_description}")
    ContainerDb(database, "数据库", "{database_type}", "存储应用数据")
}

{根据 dependencies.json 的 external_packages 生成外部系统}
System_Ext(external_api, "外部 API", "第三方服务")

{根据 architecture.json 的 dependencies 生成关系}
Rel(user, frontend, "访问", "HTTPS")
Rel(frontend, backend, "调用 API", "HTTP/JSON")
Rel(backend, database, "读写数据", "SQL")
Rel(backend, external_api, "调用", "HTTPS")

@enduml
```

## 生成步骤

1. **识别容器**：
   - 从 architecture.json 的 modules 提取
   - 前端模块 → Container(frontend, ...)
   - 后端模块 → Container(backend, ...)
   - 数据库 → ContainerDb(database, ...)

2. **识别外部系统**：
   - 从 dependencies.json 的 external_packages 提取
   - 如果有外部 API 调用（如 Stripe、AWS、第三方服务）→ System_Ext

3. **生成关系**：
   - 用户 → 前端：Rel(user, frontend, "访问", "HTTPS")
   - 前端 → 后端：Rel(frontend, backend, "调用 API", "HTTP/JSON")
   - 后端 → 数据库：Rel(backend, database, "读写数据", "SQL")
   - 后端 → 外部系统：Rel(backend, external_api, "调用", "HTTPS")

4. **推断技术栈**：
   - 从 architecture.json 的 modules[].key_components 提取
   - 从 project-info.json 的 frameworks 提取

5. **推断数据库类型**：
   - 从 dependencies.json 的 external_packages 中查找数据库驱动
   - mysql/mysql2 → "MySQL"
   - pg/postgres → "PostgreSQL"
   - mongodb → "MongoDB"

## 容器命名规则

- 前端：frontend、client、web、ui
- 后端：backend、api、server、service
- 数据库：database、db
- 缓存：cache、redis
- 消息队列：queue、mq

## 关系类型

- 用户交互：HTTPS、WebSocket
- API 调用：HTTP/JSON、REST、GraphQL
- 数据访问：SQL、NoSQL
- 消息传递：AMQP、Kafka

## 注意事项

- 使用 C4 PlantUML 标准语法
- 容器名称使用小写字母和下划线
- 描述应简洁明了
- 如果模块过多（>5 个），合并相似模块
- 确保 PlantUML 语法正确，可以被渲染
- 使用 UTF-8 编码保存文件
