---
name: gen-flow-diagrams
description: 生成业务流程时序图（PlantUML）
---

# 生成业务流程时序图

## 任务

根据业务流程分析结果，为每个主要业务流程生成时序图（Sequence Diagram），使用 PlantUML 格式。

## 输入信息

- business-flows.json（业务流程信息）

## 输出文件

- `.claude/diagrams/flow-{flow_name}.puml`（每个流程一个文件）

## 图表类型

使用 Sequence Diagram 展示业务流程中各参与者之间的交互顺序。

## PlantUML 模板

```plantuml
@startuml
title {flow_name}

{根据 business_flows[].participants 生成参与者}
actor "用户" as user
participant "前端" as frontend
participant "后端 API" as backend
participant "服务层" as service
participant "数据库" as database

{根据 business_flows[].steps 生成交互序列}
user -> frontend: 1. {step1_action}
note right: {step1_description}

frontend -> backend: 2. {step2_action}
note right: {step2_description}

backend -> service: 3. {step3_action}
note right: {step3_description}

service -> database: 4. {step4_action}
note right: {step4_description}

database --> service: 返回结果
service --> backend: 返回数据
backend --> frontend: 返回响应
frontend --> user: 显示结果

@enduml
```

## 生成步骤

1. **识别业务流程**：
   - 从 business-flows.json 的 business_flows 提取
   - 为每个流程生成一个 .puml 文件

2. **生成参与者**：
   - 从 business_flows[].participants 提取
   - 映射到 PlantUML 参与者类型：
     - Client → actor "用户" as user
     - Frontend/UI → participant "前端" as frontend
     - Controller/API → participant "后端 API" as backend
     - Service → participant "服务层" as service
     - Model/DAO → participant "数据访问层" as dao
     - Database → database "数据库" as database
     - External API → participant "外部服务" as external

3. **生成交互序列**：
   - 遍历 business_flows[].steps
   - 每个步骤生成一条消息：
     - `from -> to: step. action`
     - `note right: description`

4. **推断消息方向**：
   - 请求：`A -> B`（实线箭头）
   - 响应：`B --> A`（虚线箭头）
   - 同步调用：`A -> B`
   - 异步调用：`A ->> B`

5. **添加返回路径**：
   - 在流程结束时，添加返回消息
   - 从最内层向外层返回

## 参与者映射规则

| 组件名称 | PlantUML 类型 | 显示名称 |
|---------|--------------|---------|
| Client | actor | 用户 |
| Frontend/UI | participant | 前端 |
| AuthController | participant | 认证控制器 |
| UserService | participant | 用户服务 |
| UserModel | participant | 用户模型 |
| Database | database | 数据库 |
| CryptoService | participant | 加密服务 |
| External API | participant | 外部服务 |

## 示例：用户注册流程

```plantuml
@startuml
title 用户注册流程

actor "用户" as user
participant "前端" as frontend
participant "认证控制器" as auth_controller
participant "用户服务" as user_service
participant "加密服务" as crypto_service
participant "用户模型" as user_model
database "数据库" as database

user -> frontend: 1. 提交注册表单
note right: 输入用户名、邮箱、密码

frontend -> auth_controller: 2. POST /api/auth/register
note right: 发送注册请求

auth_controller -> user_service: 3. 检查用户是否存在
note right: 验证用户名和邮箱

user_service -> user_model: 4. 查询用户
user_model -> database: SELECT * FROM users
database --> user_model: 返回查询结果
user_model --> user_service: 用户不存在

user_service -> crypto_service: 5. 加密密码
note right: 使用 bcrypt 加密

crypto_service --> user_service: 返回加密后的密码

user_service -> user_model: 6. 创建用户记录
user_model -> database: INSERT INTO users
database --> user_model: 插入成功
user_model --> user_service: 返回用户对象

user_service --> auth_controller: 返回用户信息
auth_controller --> frontend: 返回注册成功响应
frontend --> user: 显示注册成功

@enduml
```

## 注意事项

- 每个业务流程生成一个独立的 .puml 文件
- 文件名使用流程名称的拼音或英文（如 `flow-user-register.puml`）
- 步骤编号应连续（1、2、3...）
- 描述应简洁明了
- 如果步骤过多（>10 步），合并相似步骤
- 确保 PlantUML 语法正确
- 使用 UTF-8 编码保存文件
- 如果 business-flows.json 为空或没有流程，跳过生成
