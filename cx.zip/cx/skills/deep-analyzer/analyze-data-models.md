---
name: analyze-data-models
description: 分析数据模型，生成 data-models.json
---

# 数据模型分析

## 任务

分析项目中的数据模型定义，提取实体、字段、类型、关系，生成 `data-models.json` 文件。

## 输入信息

- 项目路径
- project-info.json（项目基本信息）
- 输出文件路径

## 输出格式

```json
{
  "models": [
    {
      "name": "User",
      "description": "用户模型",
      "file": "src/models/User.js:10",
      "fields": [
        {
          "name": "id",
          "type": "integer",
          "constraints": ["primary_key", "auto_increment"]
        },
        {
          "name": "username",
          "type": "string",
          "constraints": ["unique", "not_null"],
          "max_length": 50
        },
        {
          "name": "email",
          "type": "string",
          "constraints": ["unique", "not_null"]
        },
        {
          "name": "created_at",
          "type": "datetime",
          "constraints": ["not_null"]
        }
      ],
      "relationships": [
        {
          "type": "has_many",
          "target": "Post",
          "description": "用户可以发布多篇文章"
        }
      ]
    },
    {
      "name": "Post",
      "description": "文章模型",
      "file": "src/models/Post.js:10",
      "fields": [
        {
          "name": "id",
          "type": "integer",
          "constraints": ["primary_key", "auto_increment"]
        },
        {
          "name": "title",
          "type": "string",
          "constraints": ["not_null"]
        },
        {
          "name": "content",
          "type": "text"
        },
        {
          "name": "user_id",
          "type": "integer",
          "constraints": ["foreign_key"]
        }
      ],
      "relationships": [
        {
          "type": "belongs_to",
          "target": "User",
          "foreign_key": "user_id"
        }
      ]
    }
  ]
}
```

## 分析步骤

1. **根据框架类型搜索模型文件**：

   **Sequelize (Node.js)**：
   - 搜索文件：`*model*.js`、`models/*.js`
   - 搜索模式：`sequelize.define()`、`DataTypes`

   **Mongoose (Node.js)**：
   - 搜索文件：`*model*.js`、`*schema*.js`
   - 搜索模式：`mongoose.Schema()`、`mongoose.model()`

   **Django ORM (Python)**：
   - 搜索文件：`models.py`
   - 搜索模式：`class ... (models.Model)`、`models.CharField`

   **SQLAlchemy (Python)**：
   - 搜索文件：`*model*.py`
   - 搜索模式：`class ... (Base)`、`Column()`

   **JPA/Hibernate (Java)**：
   - 搜索文件：`*Entity.java`、`*Model.java`
   - 搜索模式：`@Entity`、`@Table`、`@Column`

   **Entity Framework (C#)**：
   - 搜索文件：`*Model.cs`、`*Entity.cs`
   - 搜索模式：`public class`、`[Table]`、`[Column]`

   **Go (GORM)**：
   - 搜索文件：`*model*.go`、`models/*.go`
   - 搜索模式：`gorm.Model`、`gorm:"column:"`

   **Prisma (TypeScript/JavaScript)**：
   - 搜索文件：`schema.prisma`
   - 搜索模式：`model ... {`

   **Drizzle (TypeScript)**：
   - 搜索文件：`*schema*.ts`、`*table*.ts`
   - 搜索模式：`pgTable(`、`mysqlTable(`、`sqliteTable(`

   **TypeORM (TypeScript)**：
   - 搜索文件：`*entity*.ts`、`*Entity.ts`
   - 搜索模式：`@Entity()`、`@Column()`

   **Rust (Diesel/SeaORM)**：
   - 搜索文件：`schema.rs`、`*model*.rs`、`*entity*.rs`
   - 搜索模式：`#[derive(Queryable)]`、`table!`、`DeriveEntityModel`

2. **提取字段信息**：
   - 字段名：从代码中提取
   - 类型：映射到通用类型（integer、string、text、datetime、boolean、decimal、json）
   - 约束：primary_key、foreign_key、unique、not_null、auto_increment

3. **识别关系**：
   - `has_many`：一对多（User has many Posts）
   - `belongs_to`：多对一（Post belongs to User）
   - `has_one`：一对一
   - `many_to_many`：多对多（通过中间表）

4. **推断描述**：
   - 从模型名称推断（User → "用户模型"）
   - 从注释中提取（如果有）

## 注意事项

- 模型数量根据实际项目决定，优先完整记录，过多时保留核心模型并注明已省略
- 字段类型统一映射到通用类型，不使用框架特定类型
- 关系可以从外键字段推断，也可以从关联定义中提取
- 如果无法确定关系类型，可以省略 relationships 字段
- 文件位置格式：`相对路径:行号`
