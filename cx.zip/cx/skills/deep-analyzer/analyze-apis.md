---
name: analyze-apis
description: 分析 API 端点，生成 apis.json
---

# API 端点分析

## 任务

分析项目中的 API 端点定义，提取路由、HTTP 方法、请求/响应结构，生成 `apis.json` 文件。

## 输入信息

- 项目路径
- project-info.json（项目基本信息）
- architecture.json（架构信息）
- 输出文件路径

## 输出格式

```json
{
  "endpoints": [
    {
      "path": "/api/users",
      "method": "GET",
      "description": "获取用户列表",
      "module": "backend",
      "file": "src/routes/users.js:15",
      "auth_required": true,
      "request": {
        "query": {
          "page": "number",
          "limit": "number"
        }
      },
      "response": {
        "200": {
          "users": "array",
          "total": "number"
        }
      }
    },
    {
      "path": "/api/users/:id",
      "method": "PUT",
      "description": "更新用户信息",
      "module": "backend",
      "file": "src/routes/users.js:45",
      "auth_required": true,
      "request": {
        "body": {
          "name": "string",
          "email": "string"
        }
      },
      "response": {
        "200": {
          "user": "object"
        },
        "404": {
          "error": "string"
        }
      }
    }
  ],
  "authentication": {
    "type": "jwt|session|api_key|none",
    "description": "认证方式说明"
  }
}
```

## 分析步骤

1. **根据框架类型搜索 API 定义文件**：

   **Express (Node.js)**：
   - 搜索文件：`*route*.js`、`*router*.js`、`*api*.js`
   - 搜索模式：`app.get()`、`router.post()`、`app.use('/api')`

   **Django (Python)**：
   - 搜索文件：`urls.py`、`views.py`
   - 搜索模式：`path()`、`url()`、`@api_view`

   **Flask (Python)**：
   - 搜索文件：`*route*.py`、`*api*.py`
   - 搜索模式：`@app.route()`、`@bp.route()`

   **FastAPI (Python)**：
   - 搜索文件：`*route*.py`、`*api*.py`
   - 搜索模式：`@app.get()`、`@router.post()`

   **Spring Boot (Java)**：
   - 搜索文件：`*Controller.java`
   - 搜索模式：`@GetMapping`、`@PostMapping`、`@RequestMapping`

2. **采样策略**（根据 project-info.json 的 analysis_strategy）：
   - `full`（<10 万行）：分析所有路由文件
   - `moderate`（10-50 万行）：每个模块分析主要路由文件（根据文件名优先级）
   - `sampling`（>50 万行）：每个模块采样 1-2 个路由文件

3. **提取端点信息**：
   - 路径：如 `/api/users`、`/api/users/:id`
   - HTTP 方法：GET、POST、PUT、DELETE、PATCH
   - 描述：从注释或函数名推断
   - 文件位置：`文件路径:行号`

4. **推断请求/响应结构**：
   - 查看函数参数（req.body、req.query、req.params）
   - 查看响应代码（res.json()、return JsonResponse()）
   - 如果代码复杂，只记录主要字段，不需要完整结构

5. **识别认证方式**：
   - 搜索关键字：`jwt`、`passport`、`session`、`authenticate`、`@login_required`
   - 检查中间件：`authMiddleware`、`requireAuth`
   - 推断认证类型：JWT、Session、API Key、None

## 注意事项

- 如果端点数量过多（>50 个），只记录主要端点（CRUD 操作、核心业务接口）
- 请求/响应结构可以简化，只记录主要字段和类型
- 如果无法确定认证方式，设置为 "unknown"
- 文件位置格式：`相对路径:行号`（如 `src/routes/users.js:15`）
