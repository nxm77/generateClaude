---
name: analyze-business-flows
description: 分析业务流程，生成 business-flows.json
---

# 业务流程分析

## 任务

分析项目中的业务流程，从 API 端点和代码调用链推断业务逻辑，生成 `business-flows.json` 文件。

## 输入信息

- 项目路径
- apis.json（API 端点信息）
- data-models.json（数据模型信息）
- 输出文件路径

## 输出格式

```json
{
  "business_flows": [
    {
      "name": "用户注册流程",
      "trigger": "POST /api/auth/register",
      "description": "新用户注册并创建账户",
      "steps": [
        {
          "step": 1,
          "action": "接收注册请求",
          "component": "AuthController",
          "description": "验证用户名、邮箱、密码格式"
        },
        {
          "step": 2,
          "action": "检查用户是否存在",
          "component": "UserService",
          "description": "查询数据库，检查用户名和邮箱是否已被使用"
        },
        {
          "step": 3,
          "action": "加密密码",
          "component": "CryptoService",
          "description": "使用 bcrypt 加密用户密码"
        },
        {
          "step": 4,
          "action": "创建用户记录",
          "component": "UserModel",
          "description": "在数据库中插入新用户记录"
        },
        {
          "step": 5,
          "action": "生成 JWT Token",
          "component": "AuthService",
          "description": "生成访问令牌和刷新令牌"
        },
        {
          "step": 6,
          "action": "返回注册结果",
          "component": "AuthController",
          "description": "返回用户信息和 Token"
        }
      ],
      "participants": ["Client", "AuthController", "UserService", "CryptoService", "UserModel", "Database"]
    },
    {
      "name": "用户登录流程",
      "trigger": "POST /api/auth/login",
      "description": "用户使用用户名和密码登录",
      "steps": [
        {
          "step": 1,
          "action": "接收登录请求",
          "component": "AuthController",
          "description": "验证用户名和密码是否为空"
        },
        {
          "step": 2,
          "action": "查询用户",
          "component": "UserService",
          "description": "根据用户名查询用户记录"
        },
        {
          "step": 3,
          "action": "验证密码",
          "component": "CryptoService",
          "description": "比对加密后的密码"
        },
        {
          "step": 4,
          "action": "生成 JWT Token",
          "component": "AuthService",
          "description": "生成访问令牌"
        },
        {
          "step": 5,
          "action": "返回登录结果",
          "component": "AuthController",
          "description": "返回用户信息和 Token"
        }
      ],
      "participants": ["Client", "AuthController", "UserService", "CryptoService", "AuthService", "Database"]
    }
  ]
}
```

## 分析步骤

1. **从 API 端点推断业务流程**：
   - 识别核心业务端点（注册、登录、创建订单、支付等）
   - 每个端点对应一个业务流程
   - 优先分析 POST、PUT、DELETE 方法（涉及状态变更）

2. **分析代码调用链**：
   - 从路由处理函数开始
   - 跟踪函数调用（Controller → Service → Model）
   - 识别关键操作（数据库查询、外部 API 调用、数据验证）

3. **生成流程步骤**：
   - 每个步骤包含：序号、动作、组件、描述
   - 按执行顺序排列
   - 描述应简洁明了（一句话）

4. **识别参与者**：
   - Client（客户端）
   - Controller（控制器）
   - Service（服务层）
   - Model（数据模型）
   - Database（数据库）
   - External API（外部服务）

5. **推断流程名称和描述**：
   - 从端点路径推断（如 `/api/auth/register` → "用户注册流程"）
   - 从函数名推断（如 `createOrder` → "创建订单流程"）

## 采样策略

- `full`（<10 万行）：分析所有核心业务流程（5-10 个）
- `moderate`（10-50 万行）：分析主要业务流程（3-5 个）
- `sampling`（>50 万行）：分析最核心的业务流程（2-3 个）

## 注意事项

- 流程步骤数量根据实际复杂度决定，优先完整呈现
- 如果无法确定具体实现，可以根据端点名称和常见模式推断
- participants 列表应包含所有参与的组件
- 优先分析用户相关流程（注册、登录、权限）和核心业务流程（订单、支付、交易）
