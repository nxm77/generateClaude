---
name: analyze-dependencies
description: 分析依赖关系，生成 dependencies.json
---

# 依赖关系分析

## 任务

分析项目的外部依赖包和内部模块依赖，生成 `dependencies.json` 文件。

## 输入信息

- 项目路径
- project-info.json（项目基本信息）
- 输出文件路径

## 输出格式

```json
{
  "external_packages": {
    "runtime": [
      {
        "name": "express",
        "version": "^4.18.0",
        "category": "web_framework"
      },
      {
        "name": "sequelize",
        "version": "^6.32.0",
        "category": "orm"
      },
      {
        "name": "jsonwebtoken",
        "version": "^9.0.0",
        "category": "authentication"
      }
    ],
    "development": [
      {
        "name": "jest",
        "version": "^29.0.0",
        "category": "testing"
      },
      {
        "name": "eslint",
        "version": "^8.0.0",
        "category": "linting"
      }
    ]
  },
  "internal_dependencies": [
    {
      "from": "frontend/src/components/UserList.tsx",
      "to": "frontend/src/api/users.ts",
      "type": "import"
    },
    {
      "from": "backend/src/routes/users.js",
      "to": "backend/src/services/UserService.js",
      "type": "require"
    }
  ]
}
```

## 分析步骤

1. **解析外部依赖包**：

   **Node.js (package.json)**：
   ```json
   {
     "dependencies": { ... },
     "devDependencies": { ... }
   }
   ```

   **Python (requirements.txt)**：
   ```
   Django==4.2.0
   djangorestframework==3.14.0
   ```

   **Python (setup.py)**：
   ```python
   install_requires=[...]
   ```

   **Java (pom.xml)**：
   ```xml
   <dependencies>
     <dependency>...</dependency>
   </dependencies>
   ```

   **Go (go.mod)**：
   ```
   require (
     github.com/gin-gonic/gin v1.9.0
   )
   ```

   **Python (pyproject.toml)**：
   ```toml
   [project]
   dependencies = [...]
   [project.optional-dependencies]
   dev = [...]
   ```

   **Python (Pipfile)**：
   ```toml
   [packages]
   django = "*"
   [dev-packages]
   pytest = "*"
   ```

   **Rust (Cargo.toml)**：
   ```toml
   [dependencies]
   serde = "1.0"
   [dev-dependencies]
   tokio-test = "0.4"
   ```

   **C# (*.csproj)**：
   ```xml
   <PackageReference Include="..." Version="..." />
   ```

2. **分类外部依赖**：
   - `web_framework`：Express、Django、Flask、Spring Boot
   - `orm`：Sequelize、Mongoose、SQLAlchemy、Hibernate
   - `authentication`：Passport、JWT、OAuth
   - `database`：MySQL、PostgreSQL、MongoDB 驱动
   - `testing`：Jest、Mocha、PyTest、JUnit
   - `linting`：ESLint、Pylint、Checkstyle
   - `build_tool`：Webpack、Vite、Babel
   - `utility`：Lodash、Moment、Axios
   - `blockchain`：Hardhat、Ethers.js、Web3.js
   - `other`：其他

3. **分析内部模块依赖**（可选，如果项目规模较小）：
   - 搜索 import/require 语句
   - 提取源文件和目标文件
   - 记录依赖类型（import、require、from...import）
   - 限制数量（最多 20 条，代表性的依赖关系）

## 采样策略

- `full`（<10 万行）：完整解析所有依赖文件，分析内部依赖
- `moderate`（10-50 万行）：解析主要依赖文件，简化内部依赖分析
- `sampling`（>50 万行）：只解析根目录的依赖文件，跳过内部依赖分析

## 注意事项

- 外部依赖包必须包含 name、version、category
- 如果无法确定 category，使用 "other"
- 内部依赖分析可以省略（如果项目过大）
- 只记录项目内部的依赖关系，不包括对外部包的引用
- 版本号保持原格式（如 ^4.18.0、>=1.0.0）
