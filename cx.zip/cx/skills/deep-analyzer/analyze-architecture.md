---
name: analyze-architecture
description: 分析项目架构，生成 architecture.json
---

# 项目架构分析

## 任务

分析项目的目录结构、模块划分、架构层次和依赖关系，生成 `architecture.json` 文件。

## 输入信息

- 项目路径
- project-info.json（项目基本信息）
- 输出文件路径

## 输出格式

```json
{
  "overview": "项目整体架构描述（2-3 句话）",
  "layers": [
    {
      "name": "前端层",
      "description": "用户界面和交互逻辑",
      "technologies": ["React", "TypeScript"]
    },
    {
      "name": "API 层",
      "description": "RESTful API 服务",
      "technologies": ["Express", "Node.js"]
    },
    {
      "name": "数据层",
      "description": "数据持久化和访问",
      "technologies": ["MySQL", "Sequelize"]
    }
  ],
  "modules": [
    {
      "name": "frontend",
      "path": "frontend/",
      "type": "frontend|backend|shared|config",
      "description": "前端应用模块",
      "key_components": [
        "src/App.tsx - 主应用组件",
        "src/components/ - UI 组件库",
        "src/api/ - API 客户端"
      ],
      "entry_files": ["src/index.tsx"],
      "ports": [3000]
    },
    {
      "name": "backend",
      "path": "backend/",
      "type": "backend",
      "description": "后端 API 服务",
      "key_components": [
        "src/app.js - Express 应用入口",
        "src/routes/ - API 路由定义",
        "src/models/ - 数据模型"
      ],
      "entry_files": ["src/server.js"],
      "ports": [5000]
    }
  ],
  "dependencies": [
    {
      "from": "frontend",
      "to": "backend",
      "type": "http_api",
      "description": "前端通过 HTTP 调用后端 API"
    },
    {
      "from": "backend",
      "to": "database",
      "type": "database",
      "description": "后端连接 MySQL 数据库"
    }
  ]
}
```

## 分析步骤

1. **扫描目录结构**：
   - 使用 Glob 工具查找所有子目录
   - 识别常见的模块命名模式：frontend/、backend/、api/、client/、server/、contracts/、shared/、common/
   - 排除 node_modules、.git、dist、build 等目录

2. **识别模块类型**：
   - 包含 package.json + React/Vue → frontend
   - 包含 Express/Django/Spring Boot 代码 → backend
   - 包含 .sol 文件 → blockchain contracts
   - 包含工具函数、类型定义 → shared/common

3. **提取关键组件**：
   - 查找入口文件：index.js、main.py、server.js、app.js、__main__.py
   - 查找关键目录：routes/、controllers/、models/、components/、services/
   - 每个模块列出 3-5 个最重要的文件或目录

4. **识别端口配置**：
   - 搜索 PORT、port、listen 等关键字
   - 检查 .env、config.js、application.properties 等配置文件
   - 提取端口号（如 3000、5000、8080）

5. **推断架构层次**：
   - 根据 project-info.json 的 has_frontend/has_backend/has_database 字段
   - 生成对应的架构层（前端层、API 层、业务逻辑层、数据层）

6. **分析依赖关系**：
   - 前端 → 后端：检查 API 调用（axios、fetch）
   - 后端 → 数据库：检查数据库连接配置
   - 模块间：检查 import/require 语句

## 注意事项

- 如果项目规模较大，优先分析主要模块，其余模块简要记录
- overview 应简洁明了，描述项目的整体架构模式（如"前后端分离的 Web 应用"、"CLI 工具"、"微服务架构"）
- key_components 每个模块根据实际情况列出关键文件
- 端口号如果找不到，可以省略该字段
- 对于非前后端分离的项目（CLI 工具、库、微服务等），按实际模块划分，不强制套用前后端模式
