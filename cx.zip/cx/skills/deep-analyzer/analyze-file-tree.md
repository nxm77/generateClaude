---
name: analyze-file-tree
description: 分析文件树结构，生成 file-tree.json
---

# 文件树分析

## 任务

生成项目的目录树结构，按模块组织文件列表，生成 `file-tree.json` 文件。

## 输入信息

- 项目路径
- architecture.json（架构信息）
- 输出文件路径

## 输出格式

```json
{
  "tree": [
    {
      "path": "frontend/",
      "type": "directory",
      "children": [
        {
          "path": "frontend/src/",
          "type": "directory",
          "children": [
            {
              "path": "frontend/src/App.tsx",
              "type": "file",
              "size": 2048,
              "lines": 85
            },
            {
              "path": "frontend/src/components/",
              "type": "directory",
              "file_count": 15
            }
          ]
        },
        {
          "path": "frontend/package.json",
          "type": "file",
          "size": 1024,
          "lines": 45
        }
      ]
    },
    {
      "path": "backend/",
      "type": "directory",
      "children": [
        {
          "path": "backend/src/",
          "type": "directory",
          "children": [
            {
              "path": "backend/src/app.js",
              "type": "file",
              "size": 3072,
              "lines": 120
            }
          ]
        }
      ]
    }
  ],
  "statistics": {
    "total_files": 150,
    "total_directories": 30,
    "code_files": 120,
    "code_lines": 25000,
    "largest_file": {
      "path": "backend/src/services/OrderService.js",
      "lines": 850
    }
  }
}
```

## 分析步骤

1. **扫描目录结构**：
   - 使用 Glob 工具递归扫描项目目录
   - 排除：node_modules、.git、dist、build、target、venv、__pycache__
   - 最大深度：5 层（避免过深的嵌套）

2. **构建树形结构**：
   - 按模块组织（根据 architecture.json 的 modules）
   - 每个节点包含：path、type（file/directory）
   - 文件节点包含：size（字节）、lines（行数）
   - 目录节点可以包含：file_count（子文件数量）

3. **简化大型目录**：
   - 如果目录包含超过 20 个文件，只记录 file_count，不展开 children
   - 如果目录深度超过 5 层，截断并标记

4. **统计信息**：
   - total_files：总文件数
   - total_directories：总目录数
   - code_files：代码文件数（排除配置、文档）
   - code_lines：总代码行数
   - largest_file：最大的代码文件

## 采样策略

- `full`（<10 万行）：完整扫描所有目录和文件
- `moderate`（10-50 万行）：扫描主要模块，大型目录只记录 file_count
- `sampling`（>50 万行）：只扫描顶层目录和主要模块，深度限制为 3 层

## 注意事项

- 文件大小单位：字节
- 行数统计：只统计非空行
- 路径使用相对路径（相对于项目根目录）
- 路径分隔符统一使用 `/`（即使在 Windows 上）
- 如果文件过多，tree 结构可以简化，只保留主要目录和关键文件
- largest_file 应该是代码文件，不包括生成的文件、日志文件等
