---
name: analyze-project-info
description: 分析项目基本信息，生成 project-info.json
---

# 项目基本信息分析

## 任务

根据提供的项目信息，生成 `project-info.json` 文件，包含项目的元数据、语言、框架、类型等基本信息。

## 输入信息

脚本会提供以下信息：
- 项目路径
- 项目名称
- 检测到的语言
- 检测到的框架（后端/前端/其他）
- 项目规模（文件数、代码行数）
- 分析策略（full/moderate/sampling）
- 输出文件路径

## 输出格式

生成一个 JSON 文件，包含以下字段：

```json
{
  "meta": {
    "project_name": "项目名称",
    "analysis_time": "2026-03-18T01:30:00Z",
    "version": "2.0",
    "analysis_strategy": "full|moderate|sampling"
  },
  "languages": [
    "JavaScript/TypeScript",
    "Python"
  ],
  "frameworks": {
    "backend": ["Express", "Django"],
    "frontend": ["React", "Vue"],
    "other": ["Hardhat"]
  },
  "project_type": "web_app|blockchain_platform|cli_tool|library|microservices|monolith",
  "has_frontend": true,
  "has_backend": true,
  "has_database": true,
  "has_api": true,
  "statistics": {
    "code_files": 150,
    "code_lines": 25000,
    "total_files": 500
  }
}
```

## 分析步骤

1. **确认项目类型**：
   - 检查是否有前端框架（React/Vue/Angular）→ has_frontend
   - 检查是否有后端框架（Express/Django/Spring Boot）→ has_backend
   - 检查是否有数据库配置文件或 ORM 模型 → has_database
   - 检查是否有 API 路由定义 → has_api

2. **推断项目类型**：
   - 有前端 + 后端 + 数据库 → `web_app`
   - 有 Solidity 文件 + Hardhat/Truffle → `blockchain_platform`
   - 只有后端，多个独立服务 → `microservices`
   - 只有后端，单一服务 → `monolith`
   - 有 CLI 入口文件（bin/、cli.js、__main__.py）→ `cli_tool`
   - 有 package.json 的 "main" 字段但无服务器代码 → `library`

3. **生成 JSON 文件**：
   - 使用 Write 工具将 JSON 写入指定的输出文件路径
   - 确保 JSON 格式正确，使用 UTF-8 编码

## 注意事项

- 如果无法确定某个字段，使用合理的默认值
- `analysis_time` 使用 ISO 8601 格式
- `analysis_strategy` 直接使用脚本提供的值
- 确保生成的 JSON 文件可以被 PowerShell 的 `ConvertFrom-Json` 正确解析
