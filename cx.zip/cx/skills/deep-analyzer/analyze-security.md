---
name: analyze-security
description: 分析安全问题，生成 security.json
---

# 安全分析

## 任务

扫描项目中的潜在安全问题，包括硬编码密钥、SQL 注入风险、不安全配置等，生成 `security.json` 文件。

## 输入信息

- 项目路径
- project-info.json（项目基本信息）
- 输出文件路径

## 输出格式

```json
{
  "issues": [
    {
      "severity": "high|medium|low",
      "category": "hardcoded_secret|sql_injection|xss|insecure_config|weak_crypto",
      "description": "发现硬编码的数据库密码",
      "file": "config/database.js:10",
      "code_snippet": "password: 'admin123'",
      "recommendation": "使用环境变量存储敏感信息"
    },
    {
      "severity": "medium",
      "category": "sql_injection",
      "description": "使用字符串拼接构建 SQL 查询",
      "file": "src/services/UserService.js:45",
      "code_snippet": "SELECT * FROM users WHERE id = ' + userId",
      "recommendation": "使用参数化查询或 ORM"
    }
  ],
  "best_practices": [
    {
      "category": "authentication",
      "status": "implemented|missing",
      "description": "使用 JWT 进行身份验证"
    },
    {
      "category": "encryption",
      "status": "implemented|missing",
      "description": "密码使用 bcrypt 加密"
    },
    {
      "category": "https",
      "status": "unknown",
      "description": "HTTPS 配置状态未知"
    }
  ]
}
```

## 分析步骤

1. **搜索硬编码密钥**：
   - 搜索关键字：`password`、`secret`、`api_key`、`token`、`private_key`
   - 排除：注释、测试文件、示例文件
   - 检查赋值语句：`password = "..."`、`SECRET_KEY = "..."`
   - 严重程度：high

2. **检测 SQL 注入风险**：
   - 搜索字符串拼接的 SQL 查询
   - 模式：`"SELECT * FROM ... WHERE ... " + variable`
   - 模式：`f"SELECT * FROM {table} WHERE ..."`（Python）
   - 严重程度：high

3. **检测 XSS 风险**：
   - 搜索不安全的 HTML 渲染
   - 模式：`innerHTML =`、`dangerouslySetInnerHTML`
   - 严重程度：medium

4. **检测不安全配置**：
   - CORS 配置过于宽松：`Access-Control-Allow-Origin: *`
   - 调试模式开启：`DEBUG = True`、`NODE_ENV = development`
   - 严重程度：medium

5. **检测弱加密**：
   - 使用 MD5、SHA1 加密密码
   - 模式：`md5(password)`、`hashlib.md5()`
   - 严重程度：high

6. **检查最佳实践**：
   - 身份验证：是否使用 JWT、Session、OAuth
   - 密码加密：是否使用 bcrypt、argon2
   - HTTPS：是否配置 SSL/TLS
   - CSRF 保护：是否有 CSRF Token
   - 输入验证：是否有数据验证中间件

## 采样策略

- `full`（<10 万行）：扫描所有代码文件
- `moderate`（10-50 万行）：扫描主要模块（src/、app/、routes/、models/）
- `sampling`（>50 万行）：扫描配置文件和关键模块

## 注意事项

- 避免误报：排除测试文件、示例代码、注释
- 如果没有发现问题，issues 数组可以为空
- best_practices 应包含常见的安全实践检查
- 文件位置格式：`相对路径:行号`
- code_snippet 应简短（不超过 80 字符）
- 严重程度分类：
  - `high`：直接导致安全漏洞（硬编码密钥、SQL 注入）
  - `medium`：可能导致安全问题（XSS、不安全配置）
  - `low`：最佳实践建议（日志记录、错误处理）
