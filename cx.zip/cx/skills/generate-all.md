---
name: generate-all
description: 一键执行项目深度分析和文档生成的完整流程（8 分析 + 6 生成）
---

# 项目文档全量生成

## 任务

对当前目录的项目代码执行完整的深度分析和文档生成流程。先依次运行 8 个深度分析 skill 生成 JSON 文件，再运行 6 个文档生成 skill 生成各类文档。

## 前置准备

1. 确认当前工作目录为待分析的项目根目录
2. 确保 `.claude/analysis/` 目录存在（不存在则创建）
3. 确保 `.claude/docs/` 目录存在（不存在则创建）
4. 确保 `.claude/diagrams/` 目录存在（不存在则创建）

## Skill 路径查找

每个步骤需要 Read 对应的 skill 文件。查找顺序：
1. 项目目录 `.claude/skills/` — 优先使用项目级覆盖
2. cx 工具目录 `skills/` — 默认 skill

---

## Phase 1: Deep Analysis（8 个分析）

每个分析步骤执行两遍：
- **第一遍**：Read skill 文件，按模板指令分析项目，生成基础 JSON
- **第二遍**：全面扫描项目代码，查缺补漏，将遗漏的信息补充到 JSON 中

所有 JSON 输出到 `.claude/analysis/` 目录。

### 1.1 Project Info

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-project-info.md`，按其指令分析项目，生成 `.claude/analysis/project-info.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的语言、框架、项目类型判断或统计数据，将补充信息更新到 `project-info.json`。

### 1.2 Architecture

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-architecture.md`，按其指令分析项目，生成 `.claude/analysis/architecture.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的模块、架构层次、模块间依赖关系或入口文件，将补充信息更新到 `architecture.json`。

### 1.3 APIs

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-apis.md`，按其指令分析项目，生成 `.claude/analysis/apis.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的 API 端点、请求参数、响应格式或中间件，将补充信息更新到 `apis.json`。

### 1.4 Data Models

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-data-models.md`，按其指令分析项目，生成 `.claude/analysis/data-models.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的数据模型、字段定义、模型间关系或数据库配置，将补充信息更新到 `data-models.json`。

### 1.5 Business Flows

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-business-flows.md`，按其指令分析项目，生成 `.claude/analysis/business-flows.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的业务流程、流程步骤、参与者或异常处理路径，将补充信息更新到 `business-flows.json`。

### 1.6 Dependencies

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-dependencies.md`，按其指令分析项目，生成 `.claude/analysis/dependencies.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的依赖包、版本信息、内部模块依赖或分类错误，将补充信息更新到 `dependencies.json`。

### 1.7 Security

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-security.md`，按其指令分析项目，生成 `.claude/analysis/security.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的安全问题、最佳实践状态或认证/授权机制，将补充信息更新到 `security.json`。

### 1.8 File Tree

**第一遍**：Read skill 文件 `skills/deep-analyzer/analyze-file-tree.md`，按其指令分析项目，生成 `.claude/analysis/file-tree.json`。

**第二遍**：全面扫描项目代码，检查是否有遗漏的文件或目录、统计数据是否准确，将补充信息更新到 `file-tree.json`。

**注意**：分析时排除 `.claude/` 目录，这些不是项目文件。

---

## Phase 2: Doc Generation（6 个生成）

基于 `.claude/analysis/*.json` 生成各类文档。

### 2.1 CLAUDE.md

Read skill 文件 `skills/doc-generator/gen-claude-md.md`，按其指令读取所有分析 JSON，生成 `.claude/CLAUDE.md`，同时复制到项目根目录 `CLAUDE.md`。

### 2.2 Requirements Doc

**第一遍**：Read skill 文件 `skills/doc-generator/gen-requirements.md`，按其指令读取分析 JSON，生成 `.claude/docs/requirements.md`。

**第二遍**：全面扫描项目代码，检查需求文档是否有遗漏或需要补充的功能需求、非功能需求、数据需求，将补充内容更新到 `requirements.md`。

### 2.3 File Specification

**第一遍**：Read skill 文件 `skills/doc-generator/gen-file-spec.md`，按其指令读取分析 JSON，生成 `.claude/docs/file-specification.md`。

**第二遍**：全面扫描项目代码，检查文件说明是否有遗漏或需要补充的文件描述，将补充内容更新到 `file-specification.md`。

### 2.4 System Overview Diagram

**第一遍**：Read skill 文件 `skills/doc-generator/gen-system-overview.md`，按其指令读取分析 JSON，生成 `.claude/diagrams/system-overview.puml`。

**第二遍**：全面扫描项目代码，检查系统概览图是否准确反映了项目架构，将补充内容更新到 `system-overview.puml`。

### 2.5 Module Diagrams

**第一遍**：Read skill 文件 `skills/doc-generator/gen-module-diagrams.md`，按其指令读取分析 JSON，生成 `.claude/diagrams/module-*.puml`。

**第二遍**：全面扫描项目代码，检查模块图是否有遗漏的模块或依赖关系，将补充内容更新到对应的 `module-*.puml`。

### 2.6 Flow Diagrams

**第一遍**：Read skill 文件 `skills/doc-generator/gen-flow-diagrams.md`，按其指令读取分析 JSON，生成 `.claude/diagrams/flow-*.puml`。

**第二遍**：全面扫描项目代码，检查流程图是否有遗漏的业务流程或交互步骤，将补充内容更新到对应的 `flow-*.puml`。

---

## 执行要求

1. **严格按顺序执行**：Phase 1 的 8 个步骤必须按 1.1→1.8 顺序执行，因为后续分析可能依赖前面的 JSON 结果
2. **每步两遍**：第一遍按 skill 模板生成，第二遍全面扫描补充，确保分析完整
3. **容错处理**：如果某个 skill 文件不存在或某步执行失败，记录错误并继续下一步
4. **Phase 2 依赖 Phase 1**：文档生成必须在所有分析完成后才开始
5. **UTF-8 编码**：所有输出文件使用 UTF-8 编码
