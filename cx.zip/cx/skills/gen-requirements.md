---
name: gen-requirements
description: 生成需求说明书文档
---

# 生成需求说明书

## 任务

根据分析结果，逆向推导项目的需求说明书，生成 `requirements.md` 文档。

## 输入信息

- apis.json（API 端点信息）
- business-flows.json（业务流程信息）
- architecture.json（架构信息）
- data-models.json（数据模型信息）

## 输出文件

- `.claude/docs/requirements.md`

## 参考格式

参考 `D:/cx/ref/requirements.md` 的格式。

## 文档结构

```markdown
# {project_name} 需求说明书

## 1. 项目背景

{从 architecture.json 的 overview 推断项目背景和目标}

## 2. 项目目标

{根据项目类型和功能推断目标}

- 目标 1：{从主要功能推断}
- 目标 2：{从技术栈推断}
- 目标 3：{从业务流程推断}

## 3. 功能需求

{从 apis.json 和 business-flows.json 逆向推导功能需求，按模块分组}

### 3.1 {模块名称}

#### 3.1.1 {功能名称}
- **需求描述**：{从 API 端点和业务流程推断}
- **优先级**：高/中/低
- **涉及端点**：
  - `{method} {path}` - {description}
- **业务流程**：
  1. {step1}
  2. {step2}
  3. {step3}

### 3.2 {另一个模块}

...

## 4. 非功能需求

### 4.1 性能需求
- 响应时间：API 响应时间应在 200ms 以内
- 并发用户：支持至少 1000 并发用户

### 4.2 安全需求
{从 security.json 的 best_practices 推断}
- 身份验证：{authentication.type}
- 数据加密：{encryption status}
- 访问控制：{authorization mechanism}

### 4.3 可用性需求
- 系统可用性：99.9%
- 故障恢复时间：< 1 小时

### 4.4 兼容性需求
- 浏览器兼容：Chrome、Firefox、Safari、Edge
- 移动端兼容：iOS、Android

## 5. 数据需求

{从 data-models.json 生成}

### 5.1 数据实体

#### {model_name}
- **描述**：{description}
- **属性**：
  - {field_name} ({type}): {description}
- **关系**：
  - {relationship_description}

### 5.2 数据量估算
- 预计用户数：{推断}
- 预计数据增长：{推断}

## 6. 接口需求

{从 apis.json 生成详细的 API 规范}

### 6.1 {API 分组}

#### {endpoint_name}
- **路径**：`{method} {path}`
- **描述**：{description}
- **认证**：{auth_required}
- **请求参数**：
  ```json
  {request_example}
  ```
- **响应示例**：
  ```json
  {response_example}
  ```

## 7. 技术约束

- 编程语言：{从 project-info.json}
- 框架：{从 project-info.json}
- 数据库：{从 dependencies.json}
- 部署环境：{推断}

## 8. 项目范围

### 8.1 包含的功能
{列出主要功能模块}

### 8.2 不包含的功能
{推断可能的扩展功能}

---

*本文档由 CX 工具根据代码分析自动生成*
```

## 生成步骤

1. **推断项目背景**：
   - 根据 project_type 推断（web_app → "开发一个 Web 应用"）
   - 根据主要功能推断业务场景

2. **提取功能需求**：
   - 从 apis.json 的 endpoints 提取功能点
   - 按模块分组（根据 module 字段）
   - 每个功能包含：描述、优先级、涉及端点、业务流程

3. **推断优先级**：
   - 认证相关（登录、注册）→ 高
   - CRUD 操作 → 中
   - 辅助功能 → 低

4. **生成非功能需求**：
   - 性能需求：根据项目规模推断
   - 安全需求：从 security.json 提取
   - 可用性需求：使用通用标准

5. **生成数据需求**：
   - 从 data-models.json 提取实体
   - 描述实体的属性和关系

6. **生成接口需求**：
   - 从 apis.json 提取详细的 API 规范
   - 包含请求和响应示例

## 注意事项

- 需求描述应使用业务语言，不要过于技术化
- 优先级根据功能重要性合理推断
- 如果信息不足，使用合理的假设
- 接口需求应详细，包含完整的请求/响应示例
- 使用 Markdown 格式，确保层次清晰
