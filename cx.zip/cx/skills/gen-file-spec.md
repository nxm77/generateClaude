---
name: gen-file-spec
description: 生成文件功能列表文档
---

# 生成文件功能列表

## 任务

根据分析结果，生成项目的文件功能列表文档，详细说明每个文件的功能。

## 输入信息

- file-tree.json（文件树信息）
- architecture.json（架构信息）
- apis.json（API 端点信息）
- data-models.json（数据模型信息）

## 输出文件

- `.claude/docs/file-specification.md`

## 参考格式

参考 `D:/cx/ref/file-specification.md` 的格式。

## 文档结构

```markdown
# {project_name} 文件功能列表

## 项目概述

| 项目名称 | 技术栈 | 模块数量 | 文件数量 |
|---------|--------|---------|---------|
| {project_name} | {languages} | {module_count} | {file_count} |

## 子项目/模块列表

| 模块名称 | 路径 | 类型 | 技术栈 | 端口 |
|---------|------|------|--------|------|
| {module_name} | {module_path} | {module_type} | {technologies} | {ports} |

## 文件功能说明

{按模块组织，列出每个文件的功能}

### {module_name}

#### 核心文件

| 文件路径 | 功能说明 | 行数 |
|---------|---------|------|
| {file_path} | {function_description} | {lines} |

#### 配置文件

| 文件路径 | 功能说明 | 行数 |
|---------|---------|------|
| {file_path} | {function_description} | {lines} |

#### 路由/控制器

| 文件路径 | 功能说明 | 相关端点 | 行数 |
|---------|---------|---------|------|
| {file_path} | {function_description} | {endpoints} | {lines} |

#### 数据模型

| 文件路径 | 模型名称 | 字段数量 | 行数 |
|---------|---------|---------|------|
| {file_path} | {model_name} | {field_count} | {lines} |

#### 服务/业务逻辑

| 文件路径 | 功能说明 | 行数 |
|---------|---------|------|
| {file_path} | {function_description} | {lines} |

#### 工具/辅助

| 文件路径 | 功能说明 | 行数 |
|---------|---------|------|
| {file_path} | {function_description} | {lines} |

## 端口配置

| 服务名称 | 端口 | 协议 | 说明 |
|---------|------|------|------|
| {service_name} | {port} | HTTP/HTTPS | {description} |

## 文件统计

| 类别 | 文件数 | 代码行数 | 占比 |
|------|--------|---------|------|
| 源代码 | {count} | {lines} | {percentage}% |
| 配置文件 | {count} | {lines} | {percentage}% |
| 测试文件 | {count} | {lines} | {percentage}% |
| 文档 | {count} | {lines} | {percentage}% |
| 其他 | {count} | {lines} | {percentage}% |
| **总计** | {total_count} | {total_lines} | 100% |

---

*本文档由 CX 工具根据代码分析自动生成*
```

## 生成步骤

1. **生成项目概述表格**：
   - 从 architecture.json 提取模块数量
   - 从 file-tree.json 提取文件数量
   - 从 project-info.json 提取技术栈

2. **生成模块列表表格**：
   - 从 architecture.json 的 modules 提取
   - 包含：名称、路径、类型、技术栈、端口

3. **按模块组织文件**：
   - 遍历 file-tree.json 的 tree
   - 按模块分组文件
   - 每个模块内按文件类型分类

4. **推断文件功能**：
   - **配置文件**（package.json、.env、config.js）：
     - "项目配置文件，定义依赖和脚本"
     - "环境变量配置"

   - **入口文件**（index.js、main.py、app.js）：
     - "应用入口文件，初始化服务器"

   - **路由文件**（*route*.js、*router*.js）：
     - 从 apis.json 匹配端点
     - "定义 {endpoints} 等 API 路由"

   - **模型文件**（*model*.js、models.py）：
     - 从 data-models.json 匹配模型
     - "定义 {model_name} 数据模型"

   - **服务文件**（*service*.js、*Service.java）：
     - "实现 {功能} 业务逻辑"

   - **工具文件**（utils/、helpers/）：
     - "提供工具函数和辅助方法"

5. **生成端口配置表格**：
   - 从 architecture.json 的 modules[].ports 提取

6. **生成文件统计表格**：
   - 从 file-tree.json 统计各类文件
   - 计算占比

## 文件分类规则

- **源代码**：.js、.ts、.py、.java、.go、.cs、.rs、.sol
- **配置文件**：package.json、.env、config.*、*.config.js、*.yml、*.yaml、*.toml
- **测试文件**：*.test.js、*.spec.js、test_*.py、*Test.java
- **文档**：*.md、*.txt、*.doc
- **其他**：其他所有文件

## 注意事项

- 如果文件过多（>100 个），只列出关键文件
- 功能说明应简洁明了（一句话）
- 相关端点列出主要的 2-3 个
- 表格应对齐，使用 Markdown 格式
- 行数从 file-tree.json 提取
- 如果无法推断功能，使用通用描述（如"业务逻辑实现"）
