---
name: gen-module-diagrams
description: 生成模块结构图（PlantUML）
---

# 生成模块结构图

## 任务

根据架构分析结果，为每个主要模块生成内部结构图（Component Diagram），使用 PlantUML 格式。

## 输入信息

- architecture.json（架构信息）
- dependencies.json（依赖信息）

## 输出文件

- `.claude/diagrams/module-{module_name}.puml`（每个模块一个文件）

## 图表类型

使用 Component Diagram 展示模块内部的组件及其依赖关系。

## PlantUML 模板

```plantuml
@startuml
title {module_name} 模块内部结构

package "{module_name}" {
    {根据 architecture.json 的 modules[].key_components 生成组件}

    [入口文件] as entry
    [路由层] as routes
    [控制器层] as controllers
    [服务层] as services
    [数据访问层] as models
    [工具层] as utils
}

{根据 dependencies.json 的 internal_dependencies 生成依赖关系}
entry --> routes
routes --> controllers
controllers --> services
services --> models
services --> utils

{如果有外部依赖}
database "数据库" as db
models --> db

@enduml
```

## 生成步骤

1. **识别模块**：
   - 从 architecture.json 的 modules 提取
   - 只为主要模块生成图表（frontend、backend）
   - 跳过配置模块、共享模块

2. **识别组件**：
   - 从 modules[].key_components 提取
   - 按组件类型分类：
     - 入口文件：index.js、main.py、app.js
     - 路由层：routes/、*route*.js
     - 控制器层：controllers/、*controller*.js
     - 服务层：services/、*service*.js
     - 数据访问层：models/、*model*.js
     - 工具层：utils/、helpers/

3. **推断依赖关系**：
   - 典型的分层架构：
     - 入口 → 路由
     - 路由 → 控制器
     - 控制器 → 服务
     - 服务 → 模型
     - 服务 → 工具
     - 模型 → 数据库

   - 如果有 internal_dependencies，使用实际的依赖关系

4. **生成多个文件**：
   - 遍历 architecture.json 的 modules
   - 为每个主要模块生成一个 .puml 文件
   - 文件名：`module-{module_name}.puml`

## 组件命名规则

- 使用中文描述组件功能
- 使用英文作为组件 ID（as 后面的部分）
- 示例：`[用户管理服务] as user_service`

## 依赖关系表示

- 单向依赖：`A --> B`
- 双向依赖：`A <--> B`
- 数据库连接：`models --> db`
- 外部 API：`services --> external_api`

## 前端模块特殊处理

前端模块的组件结构：
```plantuml
package "frontend" {
    [入口文件] as entry
    [路由配置] as router
    [页面组件] as pages
    [UI 组件] as components
    [状态管理] as store
    [API 客户端] as api
}

entry --> router
router --> pages
pages --> components
pages --> store
pages --> api
```

## 后端模块特殊处理

后端模块的组件结构：
```plantuml
package "backend" {
    [应用入口] as app
    [路由定义] as routes
    [控制器] as controllers
    [业务逻辑] as services
    [数据模型] as models
    [中间件] as middleware
}

app --> middleware
app --> routes
routes --> controllers
controllers --> services
services --> models
```

## 注意事项

- 每个模块生成一个独立的 .puml 文件
- 如果模块的 key_components 为空，使用通用的分层结构
- 组件数量控制在 5-8 个，避免过于复杂
- 确保 PlantUML 语法正确
- 使用 UTF-8 编码保存文件
- 如果只有 1-2 个模块，可以合并到一个文件中
