---
name: analyze-project
description: 深度分析指定项目，生成 .analysis-report.json 报告，供 generate-docs.ps1 使用
---

# 项目深度分析 Skill

## 使用方式

当用户运行 `generate-docs.bat` 失败时，可以手动调用此 skill：

```
/analyze-project D:\path\to\project
```

## 分析流程

1. 扫描项目目录结构
2. 分析所有源代码文件
3. 提取 API 端点（支持 Gin、Express、FastAPI 等框架）
4. 提取数据模型（支持 GORM、Sequelize、TypeORM 等 ORM）
5. 识别业务流程和服务层逻辑
6. 生成 `.analysis-report.json` 文件

## 输出格式

生成的 JSON 报告包含：

```json
{
  "project_info": {
    "name": "项目名称",
    "path": "项目路径",
    "languages": ["Go", "JavaScript"],
    "frameworks": ["Gin", "React"]
  },
  "files": [
    {
      "path": "相对路径",
      "type": "文件类型",
      "lines": 行数,
      "classes": ["类名"],
      "functions": ["函数名"],
      "description": "文件功能描述"
    }
  ],
  "apis": [
    {
      "method": "GET",
      "path": "/api/endpoint",
      "file": "文件路径:行号",
      "description": "功能描述",
      "params": [],
      "response": {}
    }
  ],
  "models": [
    {
      "name": "模型名",
      "table": "表名",
      "fields": [
        {
          "name": "字段名",
          "type": "类型",
          "description": "说明"
        }
      ]
    }
  ],
  "flows": [
    {
      "name": "流程名",
      "steps": ["步骤1", "步骤2"]
    }
  ],
  "statistics": {
    "total_files": 0,
    "total_endpoints": 0,
    "total_models": 0
  }
}
```

## 执行步骤

当用户调用此 skill 时：

1. 读取项目的 README.md、package.json、go.mod 等配置文件
2. 使用 Glob 扫描所有源代码文件
3. 使用 Read 读取关键文件内容
4. 分析代码结构，提取 API、模型、业务逻辑
5. 生成 JSON 报告并保存到项目根目录的 `.analysis-report.json`
6. 提示用户重新运行 `generate-docs.bat`，脚本会自动使用这个报告
