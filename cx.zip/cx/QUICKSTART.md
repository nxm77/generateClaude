# CX 快速开始指南

## 5 分钟上手

### 1. 验证环境

```powershell
# 检查 Claude CLI 是否安装
claude --version

# 如果未安装，访问：https://github.com/anthropics/claude-code
```

### 2. 运行第一个分析

```cmd
# 进入 CX 工具目录
cd D:\cx

# 分析一个项目（替换为你的项目路径）
generate-docs.bat -Path "D:\your-project"
```

### 3. 查看生成结果

```powershell
# 查看分析结果
ls D:\your-project\.claude\analysis\

# 查看生成的文档
cat D:\your-project\CLAUDE.md
cat D:\your-project\.claude\docs\requirements.md
cat D:\your-project\.claude\docs\file-specification.md

# 查看生成的图表
ls D:\your-project\.claude\diagrams\
```

## 常见使用场景

### 场景 1：新项目文档初始化

```cmd
# 为新项目生成完整文档
cd D:\new-project
D:\cx\generate-docs.bat

# 结果：生成 CLAUDE.md、需求说明书、文件列表、架构图
```

### 场景 2：只更新 CLAUDE.md

```cmd
# 项目结构变化后，只更新 CLAUDE.md
D:\cx\generate-docs.bat -Path "D:\project" -ClaudeMd
```

### 场景 3：生成架构图给团队

```cmd
# 只生成图表，用于技术分享
D:\cx\generate-docs.bat -Path "D:\project" -SystemOverview -ModuleDiagrams
```

### 场景 4：代码审查前生成文档

```cmd
# 强制重新分析，确保文档最新
D:\cx\generate-docs.bat -Path "D:\project" -ForceAnalysis
```

## 输出文件说明

| 文件 | 用途 | 适合人群 |
|------|------|---------|
| `CLAUDE.md` | 项目总览，给 AI 助手看 | 开发者、AI |
| `requirements.md` | 需求说明书 | 产品经理、开发者 |
| `file-specification.md` | 文件功能列表 | 开发者、新人 |
| `system-overview.puml` | 系统架构图 | 架构师、技术负责人 |
| `module-*.puml` | 模块结构图 | 开发者 |
| `flow-*.puml` | 业务流程图 | 产品经理、开发者 |

## 查看 PlantUML 图表

### 方法 1：在线查看
访问 https://www.plantuml.com/plantuml/uml/ 并粘贴 .puml 文件内容

### 方法 2：VS Code 插件
安装 "PlantUML" 插件，直接在 VS Code 中预览

### 方法 3：本地渲染
```powershell
# 安装 PlantUML（需要 Java）
# 下载 plantuml.jar

# 渲染图表
java -jar plantuml.jar D:\project\.claude\diagrams\*.puml
```

## 故障排除

### 问题 1：Claude CLI 未找到
```
[ERROR] Claude CLI 未安装或无法运行
```
**解决**：安装 Claude Code CLI

### 问题 2：分析时间过长
**解决**：项目过大，等待完成或使用 Ctrl+C 中断

### 问题 3：某个文档生成失败
**解决**：默认会继续生成其他文档，检查错误日志

### 问题 4：JSON 文件格式错误
**解决**：使用 `-ForceAnalysis` 重新分析

### 问题 5：PowerShell 脚本无法执行（无管理员权限）
**解决**：使用 `generate-docs.bat` 代替 `generate-docs.ps1`，bat 启动器会自动绕过 ExecutionPolicy

## 下一步

- 📖 阅读 [README.md](README.md) 了解完整功能
- 🔧 查看 [IMPLEMENTATION-SUMMARY.md](IMPLEMENTATION-SUMMARY.md) 了解技术细节
- 🎯 在实际项目中测试工具
- 💡 根据需要自定义 skills

## 技巧

### 技巧 1：定期更新文档
```cmd
# 每周运行一次，保持文档最新
D:\cx\generate-docs.bat -Path "D:\project"
```

### 技巧 2：CI/CD 集成
```yaml
# .github/workflows/docs.yml
- name: Generate docs
  run: |
    D:\cx\generate-docs.bat -Path ${{ github.workspace }}
```

### 技巧 3：自定义 Skill
```powershell
# 复制默认 skill 到项目目录
cp D:\cx\skills\gen-claude-md.md D:\project\.claude\skills\

# 编辑自定义逻辑
code D:\project\.claude\skills\gen-claude-md.md
```

---

**需要帮助？** 查看 [README.md](README.md) 或提交 Issue
