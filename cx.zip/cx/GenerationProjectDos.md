## Step 1: Deep Analysis (8 skills)
### 1.1 Project Info
Read the skill file .claude\skills\deep-analyzer\analyze-project-info.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to project-info.json.

### 1.2 Architecture
Read the skill file .claude\skills\deep-analyzer\analyze-architecture.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to architecture.json.

### 1.3 APIs
Read the skill file .claude\skills\deep-analyzer\analyze-apis.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to apis.json.

### 1.4 Data Models
Read the skill file .claude\skills\deep-analyzer\analyze-data-models.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to data-models.json.

### 1.5 Business Flows
Read the skill file .claude\skills\deep-analyzer\analyze-business-flows.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to business-flows.json.

### 1.6 Dependencies
Read the skill file .claude\skills\deep-analyzer\analyze-dependencies.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to dependencies.json.

### 1.7 Security
Read the skill file .claude\skills\deep-analyzer\analyze-security.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to security.json.

### 1.8 File Tree
Read the skill file .claude\skills\deep-analyzer\analyze-file-tree.md, then follow its instructions to analyze this project and generate the JSON file.
Analyze the code again in depth to see if there are any modifications or supplements to file-tree.json. \
Analyze code without analyzing files in the .claude directory and the JSON files just generated in the root directory, these are not project files.

## Step 2: Document Generation (6 skills)
### 2.1 CLAUDE.md
Read the skill file .claude\skills\doc-generator\gen-claude-md.md, then follow its instructions using the analysis data (.claude\analysis\*.json) .

### 2.2 Requirements Doc
Read the skill file .claude\skills\doc-generator\gen-requirements.md, then follow its instructions (.claude\analysis\*.json) to analyze this project and generate the MD file.
Analyze the code again in depth to see if there are any modifications or supplements to .claude\docs\requirements.md.

### 2.3 File Specification
Read the skill file .claude\skills\doc-generator\gen-file-spec.md, then follow its instructions (.claude\analysis\*.json) to analyze this project and generate the PUML file.
Analyze the code again in depth to see if there are any modifications or supplements to .claude\docs\file-specification.md.

### 2.4 System Overview Diagram
Read the skill file .claude\skills\doc-generator\gen-system-overview.md, then follow its instructions (.claude\analysis\*.json) to analyze this project and generate the PUML file.
Analyze the code again in depth to see if there are any modifications or supplements to .claude\diagrams\system-overview.puml.

### 2.5 Module Diagrams
Read the skill file .claude\skills\doc-generator\gen-module-diagrams.md, then follow its instructions (.claude\analysis\*.json) to analyze this project and generate the PUML file.
Analyze the code again in depth to see if there are any modifications or supplements to .claude\diagrams\.claude\diagrams\module-*.puml.

### 2.6 Flow Diagrams
Read the skill file .claude\skills\doc-generator\gen-flow-diagrams.md, then follow its instructions (.claude\analysis\*.json) to analyze this project and generate the PUML file.
Analyze the code again in depth to see if there are any modifications or supplements to .claude\diagrams\flow-*.puml.