# 智能Claude项目文档生成脚本

param(
    [switch]$Deep,
    [string]$Path = $PWD.Path
)

# 全局变量
$script:PROJECT_DIR = $Path
$script:DEEP_ANALYSIS = $Deep
$script:PROJECT_NAME = ""
$script:PROJECT_TYPE = ""
$script:TECH_STACK = ""
$script:LANGUAGES = ""
$script:FRAMEWORKS = ""
$script:DATABASES = ""
$script:HAS_FRONTEND = $false
$script:HAS_BACKEND = $false
$script:HAS_DATABASE = $false
$script:HAS_API = $false
$script:HAS_TESTS = $false
$script:DIRECTORY_STRUCTURE = ""
$script:FILE_LIST = ""
$script:MAIN_FILES = ""
$script:ANALYSIS_REPORT = $null  # 新增: 存储深度分析结果

# 颜色输出函数
function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Type = "Info"
    )

    switch ($Type) {
        "Info" { Write-Host "[INFO] $Message" -ForegroundColor Blue }
        "Success" { Write-Host "[SUCCESS] $Message" -ForegroundColor Green }
        "Warning" { Write-Host "[WARNING] $Message" -ForegroundColor Yellow }
        "Error" { Write-Host "[ERROR] $Message" -ForegroundColor Red }
        "Stage" {
            Write-Host "`n========================================" -ForegroundColor Cyan
            Write-Host $Message -ForegroundColor Cyan
            Write-Host "========================================`n" -ForegroundColor Cyan
        }
        "Analysis" { Write-Host "[ANALYSIS] $Message" -ForegroundColor Magenta }
    }
}

# 检查目录是否存在
function Test-ProjectDirectory {
    if (-not (Test-Path $script:PROJECT_DIR)) {
        Write-ColorOutput "项目目录不存在: $script:PROJECT_DIR" "Error"
        exit 1
    }
    Write-ColorOutput "项目目录检查通过: $script:PROJECT_DIR" "Success"
}

# 阶段 0: 智能分析项目 (保持原有逻辑)
function Invoke-ProjectAnalysis {
    Write-ColorOutput "阶段 0: 智能分析项目" "Stage"

    Set-Location $script:PROJECT_DIR

    $script:PROJECT_NAME = Split-Path $script:PROJECT_DIR -Leaf
    Write-ColorOutput "项目名称: $script:PROJECT_NAME" "Analysis"

    Get-Languages
    Get-TechStack
    Get-ProjectType
    Get-DirectoryStructure
    Get-MainFiles
    Show-AnalysisReport

    Start-Sleep -Seconds 1
}

# [保留原有的分析函数 - Get-Languages, Get-TechStack 等]
# 为了简洁,这里省略,实际脚本中需要包含

# 分析编程语言
function Get-Languages {
    Write-ColorOutput "正在分析编程语言..." "Info"
    $langs = @()

    if ((Test-Path "package.json") -or (Get-ChildItem -Path . -Recurse -Depth 3 -Include "*.js","*.ts","*.jsx","*.tsx" -ErrorAction SilentlyContinue)) {
        $langs += "JavaScript/TypeScript"
    }
    if ((Test-Path "requirements.txt") -or (Test-Path "setup.py") -or (Get-ChildItem -Path . -Recurse -Depth 3 -Include "*.py" -ErrorAction SilentlyContinue)) {
        $langs += "Python"
    }
    if ((Test-Path "pom.xml") -or (Test-Path "build.gradle") -or (Get-ChildItem -Path . -Recurse -Depth 3 -Include "*.java" -ErrorAction SilentlyContinue)) {
        $langs += "Java"
    }
    if ((Test-Path "go.mod") -or (Get-ChildItem -Path . -Recurse -Depth 3 -Include "*.go" -ErrorAction SilentlyContinue)) {
        $langs += "Go"
    }
    if (Get-ChildItem -Path . -Recurse -Depth 3 -Include "*.c","*.cpp","*.h","*.hpp" -ErrorAction SilentlyContinue) {
        $langs += "C/C++"
    }

    $script:LANGUAGES = if ($langs.Count -eq 0) { "未检测到" } else { $langs -join ", " }
    Write-ColorOutput "检测到的语言: $script:LANGUAGES" "Analysis"
}

function Get-TechStack {
    Write-ColorOutput "正在分析技术栈..." "Info"
    $frameworks = @()
    $databases = @()

    if (Test-Path "package.json") {
        $packageJson = Get-Content "package.json" -Raw
        if ($packageJson -match "react") { $frameworks += "React"; $script:HAS_FRONTEND = $true }
        if ($packageJson -match "vue") { $frameworks += "Vue"; $script:HAS_FRONTEND = $true }
        if ($packageJson -match "express") { $frameworks += "Express"; $script:HAS_BACKEND = $true; $script:HAS_API = $true }
        if ($packageJson -match "mysql|mysql2") { $databases += "MySQL"; $script:HAS_DATABASE = $true }
        if ($packageJson -match "pg|postgres") { $databases += "PostgreSQL"; $script:HAS_DATABASE = $true }
    }

    $script:FRAMEWORKS = if ($frameworks.Count -eq 0) { "未检测到" } else { $frameworks -join ", " }
    $script:DATABASES = if ($databases.Count -eq 0) { "未检测到" } else { $databases -join ", " }
}

function Get-ProjectType {
    if ($script:HAS_FRONTEND -and $script:HAS_BACKEND) {
        $script:PROJECT_TYPE = "全栈 Web 应用"
    } elseif ($script:HAS_FRONTEND) {
        $script:PROJECT_TYPE = "前端应用"
    } elseif ($script:HAS_BACKEND) {
        $script:PROJECT_TYPE = "后端服务"
    } else {
        $script:PROJECT_TYPE = "通用软件项目"
    }
}

function Get-DirectoryStructure {
    $excludeDirs = @("node_modules", "__pycache__", ".git", "dist", "build", "target", "venv")
    $dirs = Get-ChildItem -Path $script:PROJECT_DIR -Directory -Recurse -Depth 3 -ErrorAction SilentlyContinue |
            Where-Object { $dirName = $_.Name; -not ($excludeDirs | Where-Object { $dirName -eq $_ }) } |
            Select-Object -First 50 -ExpandProperty FullName
    $script:DIRECTORY_STRUCTURE = $dirs -join "`n"
}

function Get-MainFiles {
    $files = @()
    @("package.json", "requirements.txt", "pom.xml", "README.md", "index.js", "main.py") | ForEach-Object {
        if (Test-Path $_) { $files += $_ }
    }
    $script:MAIN_FILES = $files -join "`n"
}

function Show-AnalysisReport {
    Write-ColorOutput "项目分析报告" "Stage"
    Write-Host "项目名称: $script:PROJECT_NAME"
    Write-Host "项目类型: $script:PROJECT_TYPE"
    Write-Host "编程语言: $script:LANGUAGES"
    Write-Host "框架: $script:FRAMEWORKS"
}

# ============================================
# 改进 1: 深度分析 - 直接读取 .md 文件
# ============================================
function Invoke-DeepAnalysis-Improved {
    if (-not $script:DEEP_ANALYSIS) {
        Write-ColorOutput "跳过深度分析 (使用 -Deep 参数启用)" "Info"
        return $null
    }

    Write-ColorOutput "阶段 0.5: 深度代码分析 (分步骤模式)" "Stage"

    # 1. 检查分步骤 skill 目录
    $deepAnalyzerDir = ".claude\skills\deep-analyzer"
    if (-not (Test-Path $deepAnalyzerDir)) {
        Write-ColorOutput "未找到深度分析 skill 目录: $deepAnalyzerDir" "Warning"
        Write-ColorOutput "将使用基础分析模式" "Warning"
        return $null
    }

    # 2. 定义分析步骤
    $analysisSteps = @(
        @{Name="project-info"; File="analyze-project-info.md"; Output="project-info.json"; Description="项目基本信息"},
        @{Name="architecture"; File="analyze-architecture.md"; Output="architecture.json"; Description="架构分析"},
        @{Name="apis"; File="analyze-apis.md"; Output="apis.json"; Description="API 端点"},
        @{Name="data-models"; File="analyze-data-models.md"; Output="data-models.json"; Description="数据模型"},
        @{Name="business-flows"; File="analyze-business-flows.md"; Output="business-flows.json"; Description="业务流程"}
    )

    # 3. 检查 claude 命令
    try {
        $claudeVersion = claude --version 2>&1
        Write-ColorOutput "Claude CLI 版本: $claudeVersion" "Info"
    } catch {
        Write-ColorOutput "未找到 claude 命令，无法执行深度分析" "Error"
        Write-ColorOutput "将使用基础分析模式" "Warning"
        return $null
    }

    # 4. 逐步执行分析
    $analysisResults = @{}
    $successCount = 0

    foreach ($step in $analysisSteps) {
        $skillFile = Join-Path $deepAnalyzerDir $step.File
        $outputFile = Join-Path $script:PROJECT_DIR $step.Output

        if (-not (Test-Path $skillFile)) {
            Write-ColorOutput "跳过 $($step.Description): skill 文件不存在" "Warning"
            continue
        }

        Write-ColorOutput "正在分析: $($step.Description)..." "Info"

        # 读取 skill 内容并移除 YAML front matter
        $lines = Get-Content $skillFile -Encoding UTF8
        $startIndex = 0
        if ($lines[0] -eq '---') {
            for ($i = 1; $i -lt $lines.Count; $i++) {
                if ($lines[$i] -eq '---') {
                    $startIndex = $i + 1
                    break
                }
            }
        }
        $skillContent = ($lines[$startIndex..($lines.Count-1)] -join "`n")

        # 构建 prompt
        $prompt = @"
$skillContent

---

# 分析任务

项目路径: $script:PROJECT_DIR
项目名称: $script:PROJECT_NAME
编程语言: $script:LANGUAGES
框架: $script:FRAMEWORKS
输出文件: $outputFile

请按照上述说明分析项目，生成 JSON 文件。
"@

        # 保存 prompt 到临时文件
        $tempPromptPath = Join-Path $env:TEMP "analysis-$($step.Name)-$(Get-Date -Format 'yyyyMMdd-HHmmss').txt"
        Set-Content -Path $tempPromptPath -Value $prompt -Encoding UTF8

        # 执行分析
        try {
            Push-Location $script:PROJECT_DIR
            $output = Get-Content $tempPromptPath -Raw | claude -p - 2>&1
            Pop-Location

            if (Test-Path $outputFile) {
                Write-ColorOutput "✓ $($step.Description) 完成" "Success"
                $analysisResults[$step.Name] = $outputFile
                $successCount++
            } else {
                Write-ColorOutput "✗ $($step.Description) 未生成输出文件" "Warning"
            }
        } catch {
            Pop-Location
            Write-ColorOutput "✗ $($step.Description) 执行失败: $_" "Error"
        }
    }

    Write-ColorOutput "深度分析完成: $successCount / $($analysisSteps.Count) 个步骤成功" "Info"

    # 5. 合并所有分析结果
    if ($successCount -gt 0) {
        $mergedReport = @{
            "meta" = @{
                "generated_at" = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
                "project_name" = $script:PROJECT_NAME
                "analysis_steps" = $successCount
            }
        }

        foreach ($key in $analysisResults.Keys) {
            $file = $analysisResults[$key]
            if (Test-Path $file) {
                try {
                    $content = Get-Content $file -Raw -Encoding UTF8 | ConvertFrom-Json
                    $mergedReport[$key] = $content
                } catch {
                    Write-ColorOutput "无法解析 $file" "Warning"
                }
            }
        }

        # 保存合并后的报告
        $finalReportPath = Join-Path $script:PROJECT_DIR ".analysis-report.json"
        $mergedReport | ConvertTo-Json -Depth 10 | Set-Content -Path $finalReportPath -Encoding UTF8
        Write-ColorOutput "合并报告已保存: $finalReportPath" "Success"

        return $mergedReport
    }

    return $null
}

# ============================================
# 改进 2: 增强的文件功能列表生成
# ============================================
function New-FileFunctionsDocument-Enhanced {
    param($analysisReport)

    Write-ColorOutput "正在生成增强版文件功能列表..." "Info"

    if ($analysisReport -and $analysisReport.files) {
        # 使用深度分析数据
        Write-ColorOutput "使用深度分析数据生成文件列表" "Success"
        New-FileFunctionsWithAnalysis $analysisReport
    } else {
        # 使用基础扫描
        Write-ColorOutput "使用基础扫描生成文件列表" "Info"
        New-FileFunctionsBasic
    }
}

function New-FileFunctionsWithAnalysis {
    param($report)

    $content = @"
# $script:PROJECT_NAME - 文件功能列表

> 本文档基于深度代码分析自动生成
> 生成时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

## 1. 项目结构概览

``````
$script:DIRECTORY_STRUCTURE
``````

## 2. 核心文件详细说明

"@

    # 按文件类型分组
    $filesByType = $report.files | Group-Object -Property type

    foreach ($typeGroup in $filesByType) {
        $content += @"

### 2.$($filesByType.IndexOf($typeGroup) + 1) $($typeGroup.Name) 文件

"@

        foreach ($file in $typeGroup.Group) {
            $content += @"

#### ``$($file.path)``
- **类型**: $($file.type)
- **行数**: $($file.lines)
"@

            if ($file.classes -and $file.classes.Count -gt 0) {
                $content += "`n- **包含类**: $($file.classes -join ', ')"
            }

            if ($file.functions -and $file.functions.Count -gt 0) {
                $funcList = $file.functions | Select-Object -First 10
                $content += "`n- **主要函数**: $($funcList -join ', ')"
                if ($file.functions.Count -gt 10) {
                    $content += " (共 $($file.functions.Count) 个)"
                }
            }

            if ($file.description) {
                $content += "`n- **功能**: $($file.description)"
            }

            if ($file.dependencies -and $file.dependencies.Count -gt 0) {
                $content += "`n- **依赖**: $($file.dependencies -join ', ')"
            }

            $content += "`n"
        }
    }

    # 添加 API 端点列表
    if ($report.apis -and $report.apis.Count -gt 0) {
        $content += @"

## 3. API 端点列表

"@

        foreach ($api in $report.apis) {
            $content += @"

### $($api.method) $($api.path)
- **文件**: ``$($api.file)``
- **功能**: $($api.description)
- **参数**: $($api.parameters -join ', ')
- **返回**: $($api.response)
- **认证**: $($api.auth)

"@
        }
    }

    # 添加数据模型列表
    if ($report.models -and $report.models.Count -gt 0) {
        $content += @"

## 4. 数据模型列表

"@

        foreach ($model in $report.models) {
            $content += @"

### $($model.name)
- **文件**: ``$($model.file)``
- **类型**: $($model.type)
- **字段**:
"@

            foreach ($field in $model.fields) {
                $content += "`n  - ``$($field.name)``: $($field.type) - $($field.description)"
            }

            if ($model.relationships -and $model.relationships.Count -gt 0) {
                $content += "`n- **关系**: $($model.relationships -join ', ')"
            }

            $content += "`n- **用途**: $($model.purpose)`n"
        }
    }

    $content += @"

---

*文档版本: v2.0 (深度分析版)*
*创建日期: $(Get-Date -Format 'yyyy-MM-dd')*
*分析文件数: $($report.statistics.code_files_analyzed)*
"@

    $filePath = Join-Path $script:PROJECT_DIR "file-functions.md"
    Set-Content -Path $filePath -Value $content -Encoding UTF8

    Write-ColorOutput "增强版文件功能列表生成成功" "Success"
}

function New-FileFunctionsBasic {
    # 基础扫描模式 - 扫描实际文件
    Write-ColorOutput "正在扫描源代码文件..." "Info"

    $sourceFiles = Get-ChildItem -Path $script:PROJECT_DIR -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object {
            $_.Extension -match '\.(ps1|js|ts|jsx|tsx|py|java|go|rs|php|rb|c|cpp|h|hpp)$' -and
            $_.FullName -notmatch '(node_modules|__pycache__|\.git|dist|build|target|venv|\.venv)'
        } |
        Select-Object -First 50

    $content = @"
# $script:PROJECT_NAME - 文件功能列表

> 本文档基于基础文件扫描生成
> 生成时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
> 提示: 使用 -Deep 参数可获得更详细的分析

## 1. 项目结构概览

``````
$script:DIRECTORY_STRUCTURE
``````

## 2. 源代码文件列表

"@

    $index = 1
    foreach ($file in $sourceFiles) {
        $relativePath = $file.FullName.Replace($script:PROJECT_DIR, "").TrimStart('\')
        $lineCount = (Get-Content $file.FullName -ErrorAction SilentlyContinue).Count

        $content += @"

### 2.$index ``$relativePath``
- **类型**: $($file.Extension) 文件
- **大小**: $([math]::Round($file.Length / 1KB, 2)) KB
- **行数**: $lineCount
- **最后修改**: $($file.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))

"@
        $index++
    }

    $content += @"

---

*文档版本: v2.0 (基础扫描版)*
*创建日期: $(Get-Date -Format 'yyyy-MM-dd')*
*扫描文件数: $($sourceFiles.Count)*
*提示: 使用 ``.\generate-docs-smart-v2.ps1 -Deep`` 获得详细分析*
"@

    $filePath = Join-Path $script:PROJECT_DIR "file-functions.md"
    Set-Content -Path $filePath -Value $content -Encoding UTF8

    Write-ColorOutput "基础版文件功能列表生成成功" "Success"
}

# [保留其他文档生成函数...]
# 为简洁省略,实际需要包含所有原有函数

# 主函数
function Main {
    Write-Host "`n╔════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║   智能文档生成脚本 v2.0 (改进版)      ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════╝`n" -ForegroundColor Cyan

    Test-ProjectDirectory
    Invoke-ProjectAnalysis

    # 执行深度分析 (改进版)
    $script:ANALYSIS_REPORT = Invoke-DeepAnalysis-Improved

    # 生成文档 (使用深度分析结果)
    New-FileFunctionsDocument-Enhanced $script:ANALYSIS_REPORT

    Write-ColorOutput "所有文档生成完成!" "Success"

    if ($script:ANALYSIS_REPORT) {
        Write-ColorOutput "已使用深度分析数据生成文档" "Success"
    } else {
        Write-ColorOutput "已使用基础模式生成文档" "Info"
        Write-ColorOutput "提示: 使用 -Deep 参数可获得更详细的分析" "Info"
    }
}

# 执行
Main
