# TechTradeChain 源代码文件说明

本文档详细说明 TechTradeChain 区块链平台各子项目的源代码文件结构和功能。

## 项目概述

TechTradeChain 是基于长安链 (ChainMaker) v2.3.7 开源代码修改的区块链平台，支持国密算法（SM2/SM3）。

| 子项目 | 说明 | 技术栈 |
|--------|------|--------|
| techtradechain-go | 区块链主程序 | Go, ChainMaker v2.3.7 |
| techtradechain-cryptogen | 证书生成工具 | Go |
| techtradechain-explorer | 浏览器后端 | Go, Gin, MySQL |
| techtradechain-explorer-web | 浏览器前端 | Vue 3, TypeScript |
| techtradechain-api | 业务API服务 | Go, Gin |
| techtradechain-admin-web | 运维管理平台 | Vue 3, TypeScript |
| docs | 项目文档 | Markdown |

---

## 1. techtradechain-go（区块链主程序）

区块链核心节点程序，基于ChainMaker v2.3.7修改，支持国密算法。

### 1.1 入口模块 (main/)

| 文件 | 功能 |
|------|------|
| main.go | 主程序入口，启动区块链节点 |
| component_registry.go | 组件注册，管理各模块依赖 |
| cmd/cli_start.go | 启动命令实现 |
| cmd/cli_config.go | 配置命令实现 |
| cmd/cli_rebuild.go | 重建命令实现 |
| cmd/cli_version.go | 版本命令实现 |
| cmd/init.go | 初始化命令 |

### 1.2 核心模块 (module/)

#### 1.2.1 blockchain - 区块链核心

管理所有子模块的生命周期，协调各组件工作。

| 文件 | 功能 |
|------|------|
| blockchain.go | 区块链核心实现 |
| blockchain_init.go | 初始化逻辑 |
| blockchain_start.go | 启动逻辑 |
| blockchain_stop.go | 停止逻辑 |
| blockchain_rebuild.go | 重建逻辑 |
| techtradechain_server.go | 服务器实现 |
| blockchain_config_subscriber.go | 配置订阅处理 |
| global.go | 全局变量定义 |
| v220_compat.go | v2.2.0版本兼容 |

#### 1.2.2 consensus - 共识模块

共识引擎提供者，支持多种共识算法。

| 文件 | 功能 |
|------|------|
| consensus_provider.go | 共识提供者，支持TBFT/MAXBFT/RAFT/SOLO/DPOS |
| consensus_verifier.go | 共识验证器 |

#### 1.2.3 core - 核心处理

核心处理逻辑，包含调度器、验证器、提议器。

**cache/ - 缓存模块**

| 文件 | 功能 |
|------|------|
| ledger_cache.go | 账本缓存 |
| proposal_cache.go | 提案缓存 |

**common/ - 公共模块**

| 文件 | 功能 |
|------|------|
| block_helper.go | 区块辅助函数 |
| committer.go | 提交器 |
| lock_helper.go | 锁辅助函数 |
| tx_helper.go | 交易辅助函数 |
| store_helper.go | 存储辅助函数 |
| metric.go | 指标收集 |

**common/scheduler/ - 调度器**

| 文件 | 功能 |
|------|------|
| scheduler.go | 调度器核心 |
| scheduler_factory.go | 调度器工厂 |
| scheduler_evidence.go | 存证调度器 |
| run_vm.go | 虚拟机执行 |
| gas.go | Gas计算 |
| conflicts_window.go | 冲突窗口管理 |
| sender_collection.go | 发送者集合 |

**maxbftmode/ - MaxBFT模式**

| 文件 | 功能 |
|------|------|
| core_maxbftmode_impl.go | MaxBFT模式核心实现 |
| proposer/block_generator.go | 区块生成器 |
| proposer/block_proposer_impl.go | 区块提议器实现 |
| verifier/block_verifier_impl.go | 区块验证器实现 |
| helper/maxbft_helper.go | MaxBFT辅助函数 |

**syncmode/ - 同步模式**

| 文件 | 功能 |
|------|------|
| core_syncmode_impl.go | 同步模式核心实现 |
| dpos_provider.go | DPoS提供者 |
| raft_provider.go | Raft提供者 |
| solo_provider.go | Solo提供者 |
| tbft_provider.go | TBFT提供者 |
| proposer/block_generator.go | 区块生成器 |
| verifier/block_verifier_impl.go | 区块验证器 |

#### 1.2.4 net - P2P网络

P2P网络服务，支持Libp2p和Liquid协议。

| 文件 | 功能 |
|------|------|
| net_factory.go | 网络工厂 |
| net_service.go | 网络服务 |
| net_service_factory.go | 网络服务工厂 |
| net_service_options.go | 网络服务选项 |
| net_msg_creator.go | 网络消息创建器 |
| net_logger.go | 网络日志 |

#### 1.2.5 rpcserver - RPC服务

gRPC/HTTP/WebSocket混合服务器。

| 文件 | 功能 |
|------|------|
| rpc_server.go | RPC服务器核心 |
| api_service.go | API服务 |
| archive_service.go | 归档服务 |
| subscribe_service.go | 订阅服务核心 |
| subscribe_service_block.go | 区块订阅服务 |
| subscribe_service_tx.go | 交易订阅服务 |
| subscribe_service_contract_event.go | 合约事件订阅 |
| middleware.go | 中间件 |
| utils.go | 工具函数 |
| gas.go | Gas处理 |
| tx_result_dispatcher.go | 交易结果分发器 |
| rateLimiter/global_rate_limiter.go | 全局限流器 |
| rateLimiter/rate_limiter.go | 限流器 |
| rateLimiter/sender_rate_limiter.go | 发送者限流器 |

#### 1.2.6 vm - 虚拟机

虚拟机提供者，支持多种运行时。

| 文件 | 功能 |
|------|------|
| (通过vm-native实现) | 支持Native/WASM/EVM/Docker等 |

#### 1.2.7 accesscontrol - 访问控制

访问控制，支持证书/公钥模式。

| 文件 | 功能 |
|------|------|
| interface_base.go | 基础接口定义 |
| interface_inner.go | 内部接口定义 |
| ac_factory.go | 访问控制工厂 |
| ac_server.go | 访问控制服务器 |
| ac_provider_registrar.go | 提供者注册器 |
| cert_ac.go | 证书访问控制 |
| cert_ac_subscriber.go | 证书订阅者 |
| cert_member.go | 证书成员 |
| public_pk_ac.go | 公钥访问控制 |
| permissioned_pk_ac.go | 许可公钥访问控制 |
| policies.go | 策略定义 |
| policy.go | 策略实现 |
| principal.go | 主体定义 |
| pk_member.go | 公钥成员 |
| organization.go | 组织管理 |
| constants.go | 常量定义 |
| utils.go | 工具函数 |

#### 1.2.8 txpool - 交易池

交易池管理。

| 文件 | 功能 |
|------|------|
| tx_pool_provider.go | 交易池提供者 |

#### 1.2.9 snapshot - 快照管理

| 文件 | 功能 |
|------|------|
| snapshot_impl.go | 快照实现 |
| snapshot_manager.go | 快照管理器 |
| snapshot_factory.go | 快照工厂 |
| snapshot_evidence.go | 存证快照 |
| snapshot_manager_evidence.go | 存证快照管理器 |

#### 1.2.10 sync - 区块链同步

| 文件 | 功能 |
|------|------|
| blockchain_sync_server.go | 同步服务器 |
| processor.go | 处理器 |
| routine.go | 例程 |
| scheduler.go | 调度器 |
| conf.go | 配置 |
| event.go | 事件 |
| state.go | 状态 |
| states.go | 状态集 |
| node_list.go | 节点列表 |

#### 1.2.11 txfilter - 交易过滤器

| 文件 | 功能 |
|------|------|
| tx_filter_factory.go | 交易过滤器工厂 |
| filtercommon/common.go | 公共过滤逻辑 |
| filterdefault/tx_filter.go | 默认过滤器 |
| map/tx_filter.go | Map过滤器 |
| birdnest/tx_filter.go | BirdNest过滤器 |
| shardingbirdsnest/tx_filter.go | 分片BirdNest过滤器 |

### 1.3 智能合约 (share/techtradechain/vm-native/v2/)

#### 1.3.1 业务合约

| 目录 | 文件 | 功能 |
|------|------|------|
| evidence/ | evidence_contract.go | 存证合约：Store/Query/Verify |
| ft/ | ft_contract.go | FT代币合约：Mint/Transfer/BalanceOf |
| nft/ | nft_contract.go | NFT代币合约：Mint/Transfer/OwnerOf |
| multipartysign/ | multipartysign_contract.go | 多方签署合约：CreateRequest/Sign/Query |
| settlement/ | settlement_contract.go | 结算合约：CreateRule/Calculate/Execute |
| multisign/ | multi_sign_contract.go | 多签合约 |

#### 1.3.2 系统合约

| 目录 | 文件 | 功能 |
|------|------|------|
| accountmgr/ | account_manager.go | 账户管理 |
| | gasManager.go | Gas管理 |
| | gas_payer.go | Gas支付 |
| certmgr/ | cert_manage_contract.go | 证书管理合约 |
| | cert_alias_manage_contract.go | 证书别名管理 |
| chainconfigmgr/ | chain_config_contract.go | 链配置合约 |
| | chain_config_consensus.go | 共识配置 |
| | chain_config_permission.go | 权限配置 |
| | chain_config_trust.go | 信任配置 |
| | chain_config_vm.go | 虚拟机配置 |
| pubkeymgr/ | pubkey_manage_contract.go | 公钥管理合约 |
| contractmgr/ | contract_manager.go | 合约管理 |
| blockcontract/ | block_contract.go | 区块合约 |
| government/ | government_contract.go | 治理合约 |
| dposmgr/ | dpos_stake_contract.go | DPoS质押合约 |
| | dpos_erc20_contract.go | DPoS ERC20合约 |
| crosstx/ | cross_transcation_contract.go | 跨链交易合约 |
| privatecompute/ | private_compute_contract.go | 隐私计算合约 |
| relay_cross/ | relay_cross.go | 中继跨链合约 |
| transactionmgr/ | transaction.go | 交易管理合约 |

#### 1.3.3 公共库

| 目录 | 文件 | 功能 |
|------|------|------|
| common/ | base_contract.go | 合约基类 |
| | interface.go | 接口定义 |
| | result.go | 结果处理 |
| | errors.go | 错误定义 |
| | gas.go | Gas计算 |
| | address_helper.go | 地址辅助 |

### 1.4 工具 (tools/)

#### 1.4.1 cmc - 命令行管理工具

| 文件 | 功能 |
|------|------|
| main.go | CMC入口 |
| client/contract.go | 合约操作 |
| client/contract_user.go | 用户合约 |
| client/contract_system.go | 系统合约 |
| client/contract_system_manage.go | 系统合约管理 |
| client/chain_conf.go | 链配置 |
| client/chain_conf_member.go | 成员管理 |
| client/chain_conf_trustroot.go | 信任根管理 |
| client/cert_manage.go | 证书管理 |
| client/block_chain.go | 区块链操作 |
| query/query.go | 查询功能 |
| query/query_block.go | 区块查询 |
| query/query_tx.go | 交易查询 |
| query/query_contract.go | 合约查询 |
| key/key.go | 密钥管理 |
| tee/tee_cmd.go | TEE命令 |
| paillier/paillier.go | 同态加密 |

#### 1.4.2 scanner - 扫描工具

| 文件 | 功能 |
|------|------|
| main.go | 扫描器入口 |
| core/scanner.go | 扫描器核心 |
| core/mail.go | 邮件通知 |
| core/http.go | HTTP通知 |
| config/config.go | 配置管理 |
| cmd/start.go | 启动命令 |

### 1.5 配置 (config/)

| 文件 | 功能 |
|------|------|
| bc.yml | 区块链配置模板 |
| chainmaker.yml | ChainMaker配置模板 |
| log.yml | 日志配置 |

### 1.6 脚本 (scripts/)

| 文件 | 功能 |
|------|------|
| prepare.sh | 准备配置脚本 |
| build_release.sh | 构建发布包 |
| cluster_quick_start.sh | 快速启动集群 |
| cluster_quick_stop.sh | 停止集群 |

---

## 2. techtradechain-cryptogen（证书生成工具）

国密证书生成工具，支持SM2/SM3算法和双证书TLS模式。

### 2.1 入口 (src/main.go)

| 文件 | 功能 |
|------|------|
| main.go | CLI入口，使用Cobra框架 |

### 2.2 命令 (src/command/)

| 文件 | 功能 |
|------|------|
| generate.go | 生成国密证书（CA、节点、用户证书） |
| extend.go | 扩展证书 |
| extend_pwk.go | 扩展PW密钥 |
| extend_pk.go | 扩展PK密钥 |
| generate_pwk.go | 生成PW密钥 |
| generate_pk.go | 生成PK密钥 |
| init.go | 初始化 |
| showconfig.go | 显示配置 |

### 2.3 配置 (src/config/)

| 文件 | 功能 |
|------|------|
| config.go | 配置加载（viper） |
| types.go | 配置类型定义 |
| pk_config.go | PK配置 |
| pwk_config.go | PWK配置 |
| tlsconfig.go | TLS配置 |
| hsm_key_config.go | HSM密钥配置 |

### 2.4 密码库 (src/share/)

| 目录 | 功能 |
|------|------|
| crypto/ | SM2/ECDSA/RSA/Dilithium算法实现 |
| crypto/hash/ | SM3/SHA256哈希算法 |
| crypto/x509/ | X.509证书处理 |
| crypto/pkcs11/ | PKCS11硬件令牌支持 |
| crypto/kms/ | 腾讯云KMS适配 |
| cert/ | 证书生成和管理 |

### 2.5 配置模板 (config/)

| 文件 | 功能 |
|------|------|
| crypto_config_template.yml | 国密配置模板（SM2/SM3/双证书） |

---

## 3. techtradechain-explorer（浏览器后端）

基于Gin框架的区块链浏览器后端，提供链数据查询和分析。

### 3.1 入口 (src/main.go)

| 文件 | 功能 |
|------|------|
| main.go | 应用入口，初始化配置、数据库、同步、HTTP服务 |

### 3.2 路由 (src/router/)

| 文件 | 功能 |
|------|------|
| router.go | HTTP路由配置，CORS中间件 |

### 3.3 服务 (src/service/)

| 文件 | 功能 |
|------|------|
| dispatcher.go | 请求分发核心，维护50+个API处理器 |
| block.go | 区块查询、列表、统计 |
| transaction.go | 交易查询、列表、数据分析 |
| contract.go | 智能合约管理、版本控制 |
| contract_standard.go | 标准合约处理（FT/NFT） |
| contract_event.go | 合约事件订阅和分析 |
| verify_contract.go | 合约源码验证 |
| user.go | 用户和账户管理 |
| account.go | 账户信息查询、余额统计 |
| transfer.go | 转账记录、跨链转账 |
| position.go | 持仓管理（FT/NFT） |
| gas.go | Gas使用统计 |
| ida.go | IDA资产管理 |
| cross_sub_chain.go | 主子链交互管理 |
| chain.go | 链基本信息、配置 |
| did.go | DID数字身份管理 |
| vc.go | 可验证凭证处理 |
| home_page.go | 首页数据统计 |
| chart.go | 图表数据生成 |
| common.go | 通用工具函数 |
| convert.go | 数据转换工具 |
| handler.go | Handler基础类 |

### 3.4 实体 (src/entity/)

| 文件 | 功能 |
|------|------|
| browser.go | 浏览器视图实体（概览、区块、交易等） |
| request.go | 请求参数定义（50+个API路由常量） |
| response.go | 响应结构定义 |
| convert.go | 数据转换工具 |

### 3.5 数据库 (src/db/)

| 文件 | 功能 |
|------|------|
| connection.go | 数据库连接（MySQL/PostgreSQL/ClickHouse） |
| table.go | 50+数据库表定义 |
| db_model.go | 数据模型定义 |
| ledger.go | 账本查询 |
| ledger_join_query.go | 联合查询优化 |

**dbhandle/ - 数据库处理器（80+文件）**

| 文件 | 功能 |
|------|------|
| db_block.go | 区块查询、插入、更新 |
| db_transaction.go | 交易管理 |
| db_contract.go | 合约管理 |
| db_contract_ft.go | FT合约 |
| db_contract_nft.go | NFT合约 |
| db_contract_event.go | 合约事件 |
| db_account.go | 账户管理 |
| db_user.go | 用户信息 |
| db_transfer.go | 转账记录 |
| db_position_ft.go | FT持仓 |
| db_position_nft.go | NFT持仓 |
| db_gas.go | Gas统计 |
| db_ida_asset.go | IDA资产 |
| db_cross_*.go | 跨链交互 |
| db_did.go | DID管理 |
| db_vc_*.go | 可验证凭证 |
| db_org.go | 组织信息 |
| db_node.go | 节点信息 |
| db_chain.go | 链信息 |

### 3.6 同步 (src/sync/)

| 文件 | 功能 |
|------|------|
| sync.go | 同步主程序，订阅区块链事件 |
| load_block.go | 加载区块数据 |
| load_other.go | 加载链配置、节点信息 |
| resolver_realtime.go | 实时事件解析 |
| resolver_delay.go | 延时数据处理 |
| resolver_task.go | 任务调度 |

**datacache/ - 数据缓存**

| 文件 | 功能 |
|------|------|
| transaction.go | 交易缓存 |
| contract.go | 合约缓存 |

**logic/ - 业务逻辑（50+文件）**

| 文件 | 功能 |
|------|------|
| block.go | 区块处理 |
| transaction.go | 交易处理 |
| account.go | 账户处理 |
| contract.go | 合约处理 |
| transfer.go | 转账处理 |
| position.go | 持仓处理 |
| cross_sub_chain.go | 跨链处理 |
| analysis_did.go | DID分析 |
| gas.go | Gas计算 |

**saveTasks/ - 数据持久化**

| 文件 | 功能 |
|------|------|
| tasks.go | 任务编排 |
| commonDB.go | 公共数据库操作 |
| realtimeSaveDB.go | 实时保存 |
| delayUpdateDB.go | 延时更新 |
| crossSaveDB.go | 跨链数据保存 |

### 3.7 监控 (src/monitor/)

| 文件 | 功能 |
|------|------|
| monitor.go | 监控主程序 |
| monitor_block_heights.go | 区块高度监控 |
| monitor_height_diff.go | 高度差异监控 |
| monitor_node.go | 节点监控 |
| monitor_tx.go | 交易监控 |
| msgchannel/send_alarm.go | 告警发送 |
| msgchannel/dingding.go | 钉钉告警 |
| msgchannel/wechat.go | 微信告警 |

### 3.8 其他模块

| 目录 | 功能 |
|------|------|
| config/ | 配置管理 |
| logger/ | 日志系统 |
| cache/ | Redis缓存 |
| utils/ | 工具函数 |
| chain/ | 链客户端 |
| code/ | 错误定义 |

---

## 4. techtradechain-explorer-web（浏览器前端）

基于Vue 3 + TypeScript的区块链浏览器前端。

### 4.1 入口 (src/main.ts)

| 文件 | 功能 |
|------|------|
| main.ts | Vue应用入口，配置Pinia、Router、Element Plus |
| App.vue | 根组件 |

### 4.2 视图 (src/views/)

| 文件 | 功能 |
|------|------|
| HomeView.vue | 首页/概览 |
| BlockList.vue | 区块列表 |
| BlockDetail.vue | 区块详情 |
| TxList.vue | 交易列表 |
| TxDetail.vue | 交易详情 |
| Evidence.vue | 存证验证表单 |
| EvidenceList.vue | 存证列表 |
| EvidenceDetail.vue | 存证详情 |
| NFTList.vue | NFT列表 |
| NFTDetail.vue | NFT详情 |
| FTList.vue | FT列表 |
| AboutView.vue | 关于页面 |

### 4.3 组件 (src/components/)

| 文件 | 功能 |
|------|------|
| TheWelcome.vue | 欢迎组件 |
| WelcomeItem.vue | 欢迎项组件 |
| HelloWorld.vue | 示例组件 |
| icons/* | 图标组件库 |

### 4.4 API (src/api/)

| 文件 | 功能 |
|------|------|
| request.ts | HTTP请求封装（Axios） |

**主要API方法：**
- getChainList() - 获取链列表
- getOverviewData() - 获取概览数据
- getBlockList() - 获取区块列表
- getBlockDetail() - 获取区块详情
- getTxList() - 获取交易列表
- getTxDetail() - 获取交易详情
- search() - 搜索功能

### 4.5 路由 (src/router/)

| 文件 | 功能 |
|------|------|
| index.ts | 路由定义 |

**路由配置：**
- / → HomeView（首页）
- /blocks → BlockList（区块列表）
- /block/:height → BlockDetail（区块详情）
- /transactions → TxList（交易列表）
- /tx/:txId → TxDetail（交易详情）
- /evidence → EvidenceList（存证列表）
- /evidence/verify → Evidence（验证表单）
- /nft → NFTList（NFT列表）
- /ft → FTList（FT列表）

### 4.6 状态 (src/stores/)

| 文件 | 功能 |
|------|------|
| counter.ts | Pinia状态管理示例 |

---

## 5. techtradechain-api（业务API服务）

基于Gin框架的RESTful API服务，直接与ChainMaker SDK交互。

### 5.1 入口 (main.go)

| 文件 | 功能 |
|------|------|
| main.go | 应用入口，初始化配置和路由 |

### 5.2 配置 (src/config/)

| 文件 | 功能 |
|------|------|
| config.go | 配置结构（Server、Chain、Node配置） |

### 5.3 路由 (src/router/)

| 文件 | 功能 |
|------|------|
| router.go | 路由定义，配置API端点 |

**API端点：**

| 路径 | 方法 | 功能 |
|------|------|------|
| /api/v1/account/create | POST | 创建账户 |
| /api/v1/account/:address | GET | 查询账户 |
| /api/v1/asset/nft/mint | POST | 铸造NFT |
| /api/v1/asset/nft/transfer | POST | 转移NFT |
| /api/v1/asset/nft/:tokenId | GET | 查询NFT |
| /api/v1/asset/ft/mint | POST | 铸造FT |
| /api/v1/asset/ft/transfer | POST | 转移FT |
| /api/v1/asset/ft/balance/:address | GET | 余额查询 |
| /api/v1/evidence/store | POST | 存储存证 |
| /api/v1/evidence/:hash | GET | 查询存证 |
| /api/v1/evidence/verify | POST | 验证存证 |
| /api/v1/multisign/create | POST | 创建多签 |
| /api/v1/multisign/sign | POST | 签署 |
| /api/v1/multisign/:requestId | GET | 查询多签 |
| /api/v1/settlement/create | POST | 创建规则 |
| /api/v1/settlement/calculate | POST | 计算结算 |
| /api/v1/settlement/execute | POST | 执行结算 |
| /api/v1/settlement/:ruleId | GET | 查询规则 |

### 5.4 服务 (src/service/)

| 目录/文件 | 功能 |
|----------|------|
| account/account.go | 账户管理（创建、查询） |
| evidence/evidence.go | 存证服务（存储、查询、验证） |
| asset/asset.go | 资产服务（NFT、FT） |
| multisign/multisign.go | 多方签署服务 |
| settlement/settlement.go | 结算规则服务 |

### 5.5 中间件 (src/middleware/)

| 文件 | 功能 |
|------|------|
| middleware.go | 中间件（CORS、Recovery） |

### 5.6 链交互 (src/chain/)

| 文件 | 功能 |
|------|------|
| chain.go | 区块链SDK客户端初始化和合约调用 |

**主要方法：**
- InvokeContract() - 调用合约（交易）
- QueryContract() - 查询合约（只读）
- StoreEvidence() - 存储存证
- QueryEvidence() - 查询存证
- MintNFT() / TransferNFT() - NFT操作
- MintFT() / TransferFT() - FT操作
- CreateMultiSign() / SignMultiSign() - 多签操作
- CreateSettlementRule() / ExecuteSettlement() - 结算操作

### 5.7 实体 (src/entity/)

| 文件 | 功能 |
|------|------|
| entity.go | 数据模型定义 |

---

## 6. techtradechain-admin-web（运维管理平台）

基于Vue 3 + TypeScript的运维管理平台前端。

### 6.1 入口 (src/main.ts)

| 文件 | 功能 |
|------|------|
| main.ts | Vue应用入口 |
| App.vue | 根组件，实现侧边栏布局 |

### 6.2 视图 (src/views/)

| 文件 | 功能 |
|------|------|
| Overview.vue | 系统概览仪表板 |
| Nodes.vue | 节点监控管理 |
| Chains.vue | 链管理（订阅和管理） |
| Accounts.vue | 账户管理 |
| Assets.vue | 资产管理（FT/NFT） |
| Settings.vue | 系统设置 |

### 6.3 组件 (src/components/)

| 状态 | 说明 |
|------|------|
| (预留) | 可复用组件库预留目录 |

### 6.4 API (src/api/)

| 文件 | 功能 |
|------|------|
| request.ts | HTTP请求封装 |

**主要API方法：**
- getChainList() - 获取已订阅链列表
- getOverviewData() - 获取链概览数据
- getNodeList() - 获取节点列表
- getOrgList() - 获取组织列表
- getAccountList() - 分页获取账户列表
- subscribeChain() - 订阅新的区块链
- modifySubscribe() - 修改链订阅配置
- deleteSubscribe() - 删除链订阅
- getFTContractList() - 获取FT合约列表
- getNFTContractList() - 获取NFT合约列表

### 6.5 路由 (src/router/)

| 文件 | 功能 |
|------|------|
| index.ts | 路由定义 |

**路由配置：**
- / → Overview（系统概览）
- /nodes → Nodes（节点监控）
- /chains → Chains（链管理）
- /accounts → Accounts（账户管理）
- /assets → Assets（资产管理）
- /settings → Settings（系统设置）

### 6.6 状态 (src/stores/)

| 状态 | 说明 |
|------|------|
| (预留) | Pinia状态管理预留目录 |

---

## 7. docs（项目文档）

| 文件 | 功能 |
|------|------|
| file-specification.md | 本文件说明文档 |

---

## 端口配置

| 服务 | 端口 | 说明 |
|------|------|------|
| 区块链节点 RPC | 12301 | techtradechain-go 节点 RPC 服务 |
| 业务 API | 8080 | techtradechain-api 服务 |
| 浏览器后端 | 7999 | techtradechain-explorer 服务 |
| 浏览器前端 | 5173 | techtradechain-explorer-web (开发模式) |
| 运维平台前端 | 9998 | techtradechain-admin-web (开发模式) |
| 浏览器后端代理 | 9999 | 前端代理后端接口 |

---

## 文件统计

| 子项目 | Go文件 | TS/Vue文件 | Rust文件 | 总文件数 | 代码行数(含注释) | 代码行数(不含注释) |
|--------|--------|------------|----------|---------|-----------------|------------------|
| techtradechain-go | 2,814 | - | - | 2,814 | 893,660 | 684,784 |
| techtradechain-cryptogen | 132 | - | - | 132 | 23,573 | 17,435 |
| techtradechain-explorer | 670 | - | - | 670 | 257,370 | 211,818 |
| techtradechain-explorer-web | - | 25 | - | 25 | 2,527 | 2,236 |
| techtradechain-api | 16 | - | - | 16 | 4,109 | 3,139 |
| techtradechain-admin-web | - | 15 | - | 15 | 3,867 | 3,346 |
| contracts | - | - | 22 | 22 | 6,318 | 4,550 |
| **总计** | **3,632** | **40** | **22** | **3,694** | **1,191,424** | **927,308** |

> 统计说明：排除 vendor、node_modules、build、dist、target 等目录
