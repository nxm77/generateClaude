# CX 项目文档生成工具设计规格

**版本**: 2.0
**日期**: 2026-03-18
**状态**: 待审查

---

## 1. 项目概述

### 1.1 目标

CX 是一个自动化项目文档生成工具，通过 PowerShell 脚本 + Claude Code Skills 的组合，自动分析指定软件项目目录，生成结构化的技术文档。

### 1.2 核心价值

- **内网部署友好** — 适用于使用内网部署的 Claude 模型（如企业私有化部署），脚本本身不依赖公网下载任何外部依赖
- **多语言支持** — 支持 C++、C#、VB.NET、Java、TypeScript、JavaScript、Python、Go
- **框架级识别** — 自动识别主流框架（ASP.NET、Spring Boot、Django、Express、Gin 等）
- **可定制化** — 用户可替换默认 skill 文件实现自定义文档生成逻辑
- **智能容错** — 分析文件拆分为多个小文件，单个失败不影响整体；文档生成支持选择性执行

### 1.3 生成的文档

1. **CLAUDE.md** — 项目说明文档（放在项目根目录）
2. **requirements.md** — 需求规格说明书（逆向推导）
3. **file-specification.md** — 文件功能列表
4. **system-overview.puml** — 系统总览图（PlantUML）
5. **module-*.puml** — 模块内部结构图（每个子项目一张）
6. **flow-*.puml** — 业务流程图（每个核心流程一张）

---

## 2. 整体架构

### 2.1 文件结构

```
cx/
├── generate-docs.ps1              # 主脚本（UTF-8 BOM 编码）
├── skills/                        # 默认 skill 模板
│   ├── deep-analyzer.md           # skill-0: 深度分析
│   ├── gen-claude-md.md           # skill-1: 生成 CLAUDE.md
│   ├── gen-requirements.md        # skill-2: 生成需求说明书
│   ├── gen-file-spec.md           # skill-3: 生成文件功能列表
│   ├── gen-system-overview.md     # skill-4: 生成系统总览图
│   ├── gen-module-diagrams.md     # skill-5: 生成模块内部图
│   └── gen-flow-diagrams.md       # skill-6: 生成业务流程图
└── ref/                           # 示例文档
    ├── requirements.md
    └── file-specification.md
```

### 2.2 目标项目产出物

```
<target-project>/
├── CLAUDE.md                      # 项目根目录
└── .claude/
    ├── analysis/                  # 深度分析数据（拆分为8个小文件）
    │   ├── project-info.json      # ~50 行：语言、框架、项目类型
    │   ├── architecture.json      # ~100 行：架构概述、层次、依赖
    │   ├── apis.json              # ~200 行：API 端点列表
    │   ├── data-models.json       # ~150 行：数据模型
    │   ├── business-flows.json    # ~150 行：业务流程
    │   ├── dependencies.json      # ~80 行：外部包、内部依赖
    │   ├── security.json          # ~50 行：安全问题
    │   └── file-tree.json         # ~200 行：文件树和统计
    ├── skills/                    # 用户可自定义 skill（优先级高于 cx/skills/）
    │   ├── gen-claude-md.md       # 可选：用户自定义版本
    │   └── ...
    ├── docs/
    │   ├── requirements.md
    │   └── file-specification.md
    └── diagrams/
        ├── system-overview.puml
        ├── module-<name>.puml
        └── flow-<name>.puml
```

### 2.3 流水线

```
generate-docs.ps1 启动
  │
  ├─ Phase 0: 项目扫描（PowerShell 本地完成）
  │   ├─ 语言检测（C++/C#/VB.NET/Java/TS/JS/Python/Go）
  │   ├─ 框架检测（ASP.NET/Spring Boot/Qt/Django/Express 等）
  │   ├─ 项目规模评估（代码行数统计）
  │   └─ 项目结构扫描
  │
  ├─ Phase 1: 深度分析（claude -p + deep-analyzer.md）
  │   ├─ 智能检测：24小时内的分析结果自动复用
  │   ├─ 智能采样：根据项目规模选择分析策略
  │   │   • <10万行：全量分析
  │   │   • 10-50万行：关键文件分析
  │   │   • >50万行：模块级采样
  │   └─ 输出 8 个分析 JSON 文件到 .claude/analysis/
  │       （容错：单个文件失败不影响其他文件）
  │
  ├─ Phase 2: 文档生成（串行调用 6 个 skill，支持选择性生成）
  │   ├─ skill-1 → CLAUDE.md
  │   ├─ skill-2 → requirements.md
  │   ├─ skill-3 → file-specification.md
  │   ├─ skill-4 → system-overview.puml
  │   ├─ skill-5 → module-*.puml
  │   └─ skill-6 → flow-*.puml
  │       （容错：单个文档失败继续执行其他文档）
  │
  └─ Phase 3: 汇总报告
```

### 2.4 Skill 查找优先级

```
脚本查找 skill 顺序：
1. <target-project>/.claude/skills/gen-xxx.md  （用户自定义）
2. <cx-tool>/skills/gen-xxx.md                 （默认模板）
```

用户如需自定义某个文档的生成逻辑，只需在项目的 `.claude/skills/` 目录下创建同名 skill 文件即可覆盖默认行为。

---

## 3. 深度分析数据结构

为提高 Claude 输出稳定性，将分析结果拆分为 8 个独立的 JSON 文件，每个文件 50-200 行。

### 3.1 文件列表

| 文件名 | 大小 | 内容 |
|--------|------|------|
| project-info.json | ~50 行 | 语言、框架、项目类型、规模统计 |
| architecture.json | ~100 行 | 架构概述、层次结构、模块间依赖 |
| apis.json | ~200 行 | API 端点列表（路由、请求/响应、认证） |
| data-models.json | ~150 行 | 数据模型（表结构、字段、索引） |
| business-flows.json | ~150 行 | 业务流程（步骤、参与者、涉及模块） |
| dependencies.json | ~80 行 | 外部包、内部依赖关系 |
| security.json | ~50 行 | 安全问题（硬编码密钥、注入风险） |
| file-tree.json | ~200 行 | 文件树结构和统计信息 |

### 3.2 采样策略

根据项目规模选择分析深度：

| 项目规模 | 分析策略 | 说明 |
|---------|---------|------|
| <10万行 | 全量分析 | 分析所有源文件 |
| 10-50万行 | 关键文件分析 | 入口文件、路由定义、数据模型、配置文件 |
| >50万行 | 模块级采样 | 每个模块选取代表性文件 |

**采样优先级**：
1. 入口文件（main.*、app.*、index.*）
2. API 路由定义（*route*、*controller*、*handler*）
3. 数据模型（*model*、*entity*、*schema*）
4. 业务逻辑核心文件（根据调用频率推断）

### 3.3 Schema 示例

#### project-info.json

#### project-info.json
```json
{
  "meta": {
    "project_name": "TechTradeChain",
    "analyzed_at": "2026-03-18T10:30:00Z",
    "analyzer_version": "2.0",
    "project_path": "D:/projects/techtradechain",
    "analysis_strategy": "key_files"
  },
  "languages": ["Go", "TypeScript", "Rust"],
  "frameworks": {
    "backend": ["ChainMaker v2.3.7", "Gin"],
    "frontend": ["Vue 3", "TypeScript"],
    "other": ["CMake"]
  },
  "project_type": "blockchain_platform",
  "has_frontend": true,
  "has_backend": true,
  "has_database": true,
  "has_api": true,
  "statistics": {
    "total_files": 3694,
    "code_lines": 927308,
    "analyzed_files": 856,
    "by_language": {
      "Go": {"files": 3632, "lines": 916476},
      "TypeScript": {"files": 40, "lines": 5582}
    }
  }
}
```

#### architecture.json
```json
{
  "overview": "基于长安链的私有化区块链平台，采用微服务架构...",
  "layers": [
    {"name": "区块链层", "components": ["techtradechain-go"]},
    {"name": "API层", "components": ["techtradechain-api"]},
    {"name": "前端层", "components": ["techtradechain-explorer-web"]}
  ],
  "dependencies": [
    {"from": "techtradechain-api", "to": "techtradechain-go", "type": "RPC"}
  ],
  "modules": [
    {
      "name": "techtradechain-go",
      "path": "techtradechain-go/",
      "type": "blockchain_node",
      "language": "Go",
      "description": "区块链核心节点程序",
      "entry_points": ["main/main.go"],
      "key_components": [
        {"name": "blockchain", "path": "module/blockchain/", "purpose": "区块链核心管理"}
      ],
      "ports": [{"port": 12301, "protocol": "RPC", "purpose": "节点RPC服务"}]
    }
  ]
}
```

#### apis.json、dependencies.json、security.json 等
其他文件结构类似，详见各 skill 的具体实现。

---

## 4. PowerShell 脚本设计

### 4.1 命令行参数

```powershell
param(
    [string]$Path = $PWD.Path,        # 目标项目路径
    [switch]$ForceAnalysis,           # 强制重新分析（忽略已有分析结果）
    [switch]$ContinueOnError = $true, # 遇到错误继续执行（默认开启）
    [switch]$StopOnError,             # 遇到错误立即停止
    [switch]$Verbose,                 # 详细输出

    # 选择性生成参数（默认全部生成）
    [switch]$All = $true,             # 生成所有文档（默认）
    [switch]$ClaudeMd,                # 仅生成 CLAUDE.md
    [switch]$Requirements,            # 仅生成需求说明书
    [switch]$FileSpec,                # 仅生成文件功能列表
    [switch]$SystemOverview,          # 仅生成系统总览图
    [switch]$ModuleDiagrams,          # 仅生成模块内部图
    [switch]$FlowDiagrams             # 仅生成业务流程图
)

# 强制 UTF-8 输出（兼容 Win10 PowerShell）
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
```

### 4.2 使用示例

```powershell
# 生成所有文档（默认）
.\generate-docs.ps1

# 只生成 CLAUDE.md
.\generate-docs.ps1 -ClaudeMd

# 只生成需求说明书和文件功能列表
.\generate-docs.ps1 -Requirements -FileSpec

# 强制重新分析
.\generate-docs.ps1 -ForceAnalysis

# 指定项目路径
.\generate-docs.ps1 -Path "C:\projects\myapp"

# 遇到错误立即停止
.\generate-docs.ps1 -StopOnError
```

### 4.3 主流程

```powershell
function Main {
    Write-Progress-Message "CX 项目文档生成工具 v2.0" "Stage"

    # 环境检查
    Test-Environment

    # Phase 0: 项目扫描
    Write-Progress-Message "阶段 0/3: 项目扫描" "Stage"
    $projectInfo = Invoke-ProjectScan

    # Phase 1: 深度分析（智能检测）
    Write-Progress-Message "阶段 1/3: 深度分析" "Stage"
    Invoke-DeepAnalysis $projectInfo

    # Phase 2: 文档生成（选择性）
    Write-Progress-Message "阶段 2/3: 文档生成" "Stage"
    $docsToGenerate = Get-DocumentsToGenerate
    Invoke-DocumentGeneration $docsToGenerate

    # Phase 3: 汇总报告
    Write-Progress-Message "阶段 3/3: 汇总报告" "Stage"
    Show-Summary
}
```

### 4.4 智能分析检测

```powershell
function Invoke-DeepAnalysis {
    param($projectInfo)

    $analysisDir = Join-Path $script:OUTPUT_DIR "analysis"
    $projectInfoFile = Join-Path $analysisDir "project-info.json"

    # 检查是否已有分析结果
    if ((Test-Path $projectInfoFile) -and -not $ForceAnalysis) {
        $fileAge = (Get-Date) - (Get-Item $projectInfoFile).LastWriteTime

        if ($fileAge.TotalHours -lt 24) {
            # 24小时内，直接使用
            Write-Progress-Message "使用 $($fileAge.TotalHours.ToString('0.0')) 小时前的分析结果" "Success"
            return
        } else {
            # 超过24小时，询问用户
            Write-Progress-Message "发现 $($fileAge.TotalDays.ToString('0.0')) 天前的分析结果" "Warning"
            $response = Read-Host "是否重新分析？(Y/n)"

            if ($response -eq "n" -or $response -eq "N") {
                Write-Progress-Message "使用已有分析结果" "Info"
                return
            }
        }
    }

    # 执行深度分析
    Write-Progress-Message "开始深度分析（预计 3-10 分钟）..." "Progress"

    $analysisFiles = @(
        "project-info.json",
        "architecture.json",
        "apis.json",
        "data-models.json",
        "business-flows.json",
        "dependencies.json",
        "security.json",
        "file-tree.json"
    )

    $successCount = 0
    $failedFiles = @()

    foreach ($file in $analysisFiles) {
        Write-Progress-Message "正在分析: $file..." "Progress"
        try {
            Invoke-AnalysisStep $file $projectInfo
            $successCount++
            Write-Progress-Message "$file 分析完成" "Success"
        } catch {
            $failedFiles += $file
            Write-Progress-Message "$file 分析失败: $_" "Error"
            if ($StopOnError) {
                throw
            }
        }
    }

    if ($successCount -eq 0) {
        throw "深度分析完全失败，无法继续"
    }

    Write-Progress-Message "深度分析完成: $successCount/$($analysisFiles.Count) 成功" "Success"

    if ($failedFiles.Count -gt 0) {
        Write-Progress-Message "以下分析文件失败: $($failedFiles -join ', ')" "Warning"
    }
}
```

### 4.5 错误处理

```powershell
# 环境检查
function Test-Environment {
    # 检查 Claude CLI
    try {
        $claudeVersion = & claude --version 2>&1
        Write-Progress-Message "Claude CLI 版本: $claudeVersion" "Success"
    } catch {
        Write-Progress-Message "未找到 Claude CLI，请先安装" "Error"
        Write-Progress-Message "安装方法: https://github.com/anthropics/claude-code" "Info"
        exit 1
    }

    # 检查项目目录
    if (-not (Test-Path $script:PROJECT_DIR)) {
        Write-Progress-Message "项目目录不存在: $script:PROJECT_DIR" "Error"
        exit 1
    }

    # 检查是否为空目录
    $fileCount = (Get-ChildItem $script:PROJECT_DIR -Recurse -File | Measure-Object).Count
    if ($fileCount -eq 0) {
        Write-Progress-Message "项目目录为空，无法分析" "Error"
        exit 1
    }
}

# 文档生成容错
function Invoke-DocumentGeneration {
    param($docsToGenerate)

    $successCount = 0
    $failedDocs = @()
    $current = 0
    $total = $docsToGenerate.Count

    foreach ($doc in $docsToGenerate) {
        $current++
        Write-Progress-Message "[$current/$total] 正在生成 $($doc.Desc)..." "Progress"

        try {
            Invoke-SkillGeneration $doc.Name $doc.Output
            $successCount++
            Write-Progress-Message "[$current/$total] $($doc.Desc) 生成完成" "Success"
        } catch {
            $failedDocs += $doc.Desc
            Write-Progress-Message "[$current/$total] $($doc.Desc) 生成失败: $_" "Error"
            if ($StopOnError) {
                throw
            }
        }
    }

    Write-Progress-Message "文档生成完成: $successCount/$total 成功" "Info"

    if ($failedDocs.Count -gt 0) {
        Write-Progress-Message "以下文档生成失败:" "Warning"
        foreach ($doc in $failedDocs) {
            Write-Progress-Message "  - $doc" "Warning"
        }
    }
}
```

### 4.6 语言检测

支持的语言及检测特征：

| 语言 | 检测特征 |
|------|---------|
| C++ | `*.cpp`, `*.h`, `*.hpp`, `CMakeLists.txt` |
| C# | `*.cs`, `*.csproj` |
| VB.NET | `*.vb`, `*.vbproj` |
| Java | `*.java`, `pom.xml`, `build.gradle` |
| TypeScript/JavaScript | `*.ts`, `*.tsx`, `*.js`, `*.jsx`, `package.json` |
| Python | `*.py`, `requirements.txt`, `setup.py` |
| Go | `*.go`, `go.mod` |

### 4.3 框架检测

优先框架级识别，fallback 到语言级：

| 框架 | 检测方法 |
|------|---------|
| ASP.NET Core | 检查 `.csproj` 中是否包含 `Microsoft.AspNetCore` |
| Spring Boot | 检查 `pom.xml` 中是否包含 `spring-boot` |
| Django/Flask | 检查 `requirements.txt` 中是否包含对应包名 |
| Express/NestJS | 检查 `package.json` 的 `dependencies` |
| Gin | 检查 `go.mod` 中是否包含 `gin-gonic/gin` |
| Qt | 检查是否存在 `.pro` 文件或 CMakeLists.txt 中包含 Qt |

### 4.4 编码处理

- 脚本文件：UTF-8 with BOM（兼容 Win10 PowerShell 中文显示）
- 输出文档：UTF-8 with BOM
- 脚本内强制设置 `[Console]::OutputEncoding`

---

## 5. Skill 文件设计

### 5.1 skill-0: deep-analyzer.md

**职责**：深度分析项目代码，生成完整的 `.analysis-report.json`

**输入**：
- 项目路径
- 脚本检测到的语言/框架信息

**输出**：
- `.claude/.analysis-report.json`

**关键逻辑**：
- 根据语言/框架选择分析策略
- 扫描 API 端点（支持 Express/NestJS/Django/Flask/Spring Boot/Gin/ASP.NET）
- 提取数据模型（ORM/Entity/Model 类）
- 识别业务流程（通过函数调用链推断）
- 分析依赖关系（package.json/requirements.txt/go.mod/pom.xml/.csproj）
- 检测安全问题（硬编码密钥、SQL 注入风险）

---

### 5.2 skill-1: gen-claude-md.md

**职责**：生成项目根目录的 CLAUDE.md

**输入**：`.analysis-report.json`

**输出**：`.claude/CLAUDE.md`（同时复制到项目根目录）

**内容结构**：
```markdown
# 项目名称

> **离线环境注意事项**：
> 本项目文档由 cx 工具生成，适用于局域网离线环境。
> - 所有依赖需提前准备，脚本不会从互联网下载任何内容
> - Claude Code CLI 需提前安装配置
> - 如需自定义某个文档的生成逻辑，可在项目的 `.claude/skills/` 目录下
>   创建同名 skill 文件（如 `gen-requirements.md`）来替换默认模板

## 项目概述
[从 JSON 的 architecture.overview 提取]

## 技术栈
- 语言：[从 project_info.languages]
- 框架：[从 project_info.frameworks]

## 项目结构
[从 modules 生成目录树]

## 依赖清单
### 外部依赖
[从 dependencies.external_packages]

## 配置说明
[从 configuration]

## 安全注意事项
[从 security_concerns]

## 端口配置
[从 modules[].ports]
```

---

### 5.3 skill-2: gen-requirements.md

**职责**：生成需求说明书（参考 `ref/requirements.md` 格式）

**输入**：`.analysis-report.json`

**输出**：`.claude/docs/requirements.md`

**内容结构**：
```markdown
# [项目名] 需求规格说明书

## 1. 项目概述
### 1.1 项目背景
[从 architecture.overview 推断]

### 1.2 项目目标
[从 business_flows 推断核心目标]

## 2. 功能需求
[从 apis 和 business_flows 逆向推导]

### 2.1 [模块名]
| 功能 | 描述 | 优先级 |
[从 apis 分组生成]

## 3. 非功能需求
[从 security_concerns、configuration 推断]

## 4. 技术架构
[从 architecture 生成]

## 5. 数据结构
[从 data_models 生成]

## 6. 业务场景
[从 business_flows 生成]
```

---

### 5.4 skill-3: gen-file-spec.md

**职责**：生成文件功能列表（参考 `ref/file-specification.md` 格式）

**输入**：`.analysis-report.json`

**输出**：`.claude/docs/file-specification.md`

**内容结构**：
```markdown
# [项目名] 源代码文件说明

## 项目概述
[从 project_info 生成]

## 子项目列表
[从 modules 生成表格]

---

## 1. [模块名]

### 1.1 [子目录名]
| 文件 | 功能 |
[从 file_tree 和 modules[].key_components 生成]

---

## 端口配置
[从 modules[].ports]

## 文件统计
[从 statistics]
```

---

### 5.5 skill-4: gen-system-overview.md

**职责**：生成系统总览 PlantUML 图

**输入**：`.analysis-report.json`

**输出**：`.claude/diagrams/system-overview.puml`

**图类型**：C4 Context/Container 图

**生成逻辑**：
- 从 `architecture.layers` 生成层次结构
- 从 `architecture.dependencies` 生成依赖箭头
- 从 `modules` 生成容器组件

---

### 5.6 skill-5: gen-module-diagrams.md

**职责**：为每个子项目/模块生成内部结构图

**输入**：`.analysis-report.json`

**输出**：`.claude/diagrams/module-<name>.puml`（每个模块一个文件）

**图类型**：组件图（Component Diagram）

**生成逻辑**：
- 从 `modules[].key_components` 生成组件
- 从 `dependencies.internal_dependencies` 生成内部调用关系

---

### 5.7 skill-6: gen-flow-diagrams.md

**职责**：为每个核心业务流程生成序列图

**输入**：`.analysis-report.json`

**输出**：`.claude/diagrams/flow-<name>.puml`（每个流程一个文件）

**图类型**：序列图（Sequence Diagram）

**生成逻辑**：
- 从 `business_flows[].steps` 生成参与者和消息序列

---

## 6. 错误处理与用户体验

### 6.1 进度提示

每条消息带时间戳和彩色标识：

```
[10:30:15] [信息] 目标项目: D:/projects/demo
[10:30:16] ⏳ 正在检测编程语言...
[10:30:17] [完成] 检测到语言: Go, TypeScript
[10:30:18] [警告] 未检测到测试文件
```

文档生成显示进度：

```
[1/6] 正在生成 CLAUDE.md...
[1/6] CLAUDE.md 生成完成
[2/6] 正在生成 需求说明书...
```

### 6.2 错误处理策略

1. **环境检查**
   - 检查 Claude CLI 是否安装
   - 检查项目目录是否存在且非空
   - 检查 skill 文件是否完整

2. **Claude 调用错误处理**
   - 捕获 API 速率限制、认证失败、超时等常见错误
   - 验证生成的 JSON 格式是否正确
   - 提供友好的错误提示和解决建议

3. **文档生成容错**
   - 单个文档失败不中断整体流程
   - 继续生成其他文档
   - 最终汇总显示成功/失败情况

4. **常见错误提示**
   - `rate limit` → "API 速率限制，请稍后重试"
   - `authentication` → "认证失败，请检查 Claude CLI 配置"
   - `timeout` → "超时，项目可能过大，建议分批分析"

### 6.3 最终汇总报告

```
========================================
  文档生成完成！
========================================

生成的文档位置:
  - CLAUDE.md (项目根目录)
  - .claude/docs/requirements.md
  - .claude/docs/file-specification.md
  - .claude/diagrams/*.puml

提示:
  - 使用 PlantUML 工具或 IDE 插件查看 .puml 图
  - 如需自定义文档生成，可在 .claude/skills/ 放置同名 skill 文件
  - 如需重新分析，删除 .analysis-report.json 后重新运行
```

---

## 7. 使用方式

### 7.1 基本用法

```powershell
# 分析当前目录项目
.\generate-docs.ps1

# 指定项目路径
.\generate-docs.ps1 -Path "C:\projects\myapp"

# 跳过深度分析（使用已有 JSON）
.\generate-docs.ps1 -SkipAnalysis

# 详细输出
.\generate-docs.ps1 -Verbose
```

### 7.2 自定义文档生成

如需自定义某个文档的生成逻辑：

1. 在目标项目中创建 `.claude/skills/` 目录
2. 复制默认 skill 文件到该目录（如 `gen-requirements.md`）
3. 修改 skill 内容
4. 重新运行脚本，将自动使用自定义版本

---

## 8. 技术约束

### 8.1 离线环境

- 所有依赖需提前准备
- 脚本不会从互联网下载任何内容
- Claude Code CLI 需提前安装配置

### 8.2 性能考虑

- 深度分析阶段预计耗时 3-10 分钟（取决于项目规模）
- 大型项目（>10万行代码）可能需要更长时间
- 建议在分析大型项目时使用 `-Verbose` 参数查看详细进度

### 8.3 兼容性

- Windows 10/11 PowerShell 5.1+
- UTF-8 BOM 编码确保中文正常显示
- 支持的语言：C++、C#、VB.NET、Java、TypeScript、JavaScript、Python、Go

---

## 9. 未来扩展

### 9.1 可能的增强

- 支持更多语言（Rust、Ruby、PHP）
- 支持更多框架（Laravel、Rails、FastAPI）
- 增加代码质量指标（复杂度、重复率）
- 支持增量分析（只分析变更部分）
- 生成 HTML/PDF 格式文档

### 9.2 已知限制

- 复杂的动态逻辑可能无法完全捕获
- 业务流程推断依赖代码结构清晰度
- 大型项目（>50万行）可能遇到性能瓶颈

---

## 10. 参考资料

- [Doxygen 文档生成最佳实践](https://kindatechnical.com/software-documentation-best-practices/generating-documentation-from-code.html)
- [代码分析工具对比](https://www.augmentcode.com/guides/auto-document-your-code-tools-and-best-practices)
- [依赖关系分析](https://kit.cased.com/core-concepts/dependency-analysis/)
- [PlantUML 官方文档](https://plantuml.com/)

---

**设计完成日期**: 2026-03-18
**下一步**: 规格审查 → 用户确认 → 实施规划
