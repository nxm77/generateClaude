# CX CLI Quick Start

If you cannot run `.bat` or `.ps1` scripts, you can use Claude CLI directly to call skills one by one.

## Prerequisites

- Claude Code CLI installed (`claude` command available)
- Copy `D:\cx\skills\` to your project: `.claude\skills\`

```cmd
xcopy /E /I D:\cx\skills D:\your-project\.claude\skills
```

## Step 1: Deep Analysis (8 skills)

Open Claude CLI in your project directory:

```cmd
cd D:\your-project
claude
```

Run each analysis skill in order. Copy and paste the prompts below into the Claude CLI session.

### 1.1 Project Info

```
Project path: D:\your-project
Output file: .claude\analysis\project-info.json

Read the skill file .claude\skills\deep-analyzer\analyze-project-info.md, then follow its instructions to analyze this project and generate the JSON file.
```

### 1.2 Architecture

```
Project path: D:\your-project
Output file: .claude\analysis\architecture.json

Read the skill file .claude\skills\deep-analyzer\analyze-architecture.md, then follow its instructions.
```

### 1.3 APIs

```
Project path: D:\your-project
Output file: .claude\analysis\apis.json

Read the skill file .claude\skills\deep-analyzer\analyze-apis.md, then follow its instructions.
```

### 1.4 Data Models

```
Project path: D:\your-project
Output file: .claude\analysis\data-models.json

Read the skill file .claude\skills\deep-analyzer\analyze-data-models.md, then follow its instructions.
```

### 1.5 Business Flows

```
Project path: D:\your-project
Output file: .claude\analysis\business-flows.json

Read the skill file .claude\skills\deep-analyzer\analyze-business-flows.md, then follow its instructions.
```

### 1.6 Dependencies

```
Project path: D:\your-project
Output file: .claude\analysis\dependencies.json

Read the skill file .claude\skills\deep-analyzer\analyze-dependencies.md, then follow its instructions.
```

### 1.7 Security

```
Project path: D:\your-project
Output file: .claude\analysis\security.json

Read the skill file .claude\skills\deep-analyzer\analyze-security.md, then follow its instructions.
```

### 1.8 File Tree

```
Project path: D:\your-project
Output file: .claude\analysis\file-tree.json

Read the skill file .claude\skills\deep-analyzer\analyze-file-tree.md, then follow its instructions.
```

## Step 2: Document Generation (6 skills)

After all analysis JSON files are generated, run the document generation skills.

### 2.1 CLAUDE.md

```
Project path: D:\your-project
Analysis data: .claude\analysis\
Output: CLAUDE.md (project root) + .claude\CLAUDE.md

Read the skill file .claude\skills\gen-claude-md.md, then follow its instructions using the analysis data.
```

### 2.2 Requirements Doc

```
Project path: D:\your-project
Analysis data: .claude\analysis\
Output: .claude\docs\requirements.md

Read the skill file .claude\skills\gen-requirements.md, then follow its instructions.
```

### 2.3 File Specification

```
Project path: D:\your-project
Analysis data: .claude\analysis\
Output: .claude\docs\file-specification.md

Read the skill file .claude\skills\gen-file-spec.md, then follow its instructions.
```

### 2.4 System Overview Diagram

```
Project path: D:\your-project
Analysis data: .claude\analysis\
Output: .claude\diagrams\system-overview.puml

Read the skill file .claude\skills\gen-system-overview.md, then follow its instructions.
```

### 2.5 Module Diagrams

```
Project path: D:\your-project
Analysis data: .claude\analysis\
Output: .claude\diagrams\module-*.puml

Read the skill file .claude\skills\gen-module-diagrams.md, then follow its instructions.
```

### 2.6 Flow Diagrams

```
Project path: D:\your-project
Analysis data: .claude\analysis\
Output: .claude\diagrams\flow-*.puml

Read the skill file .claude\skills\gen-flow-diagrams.md, then follow its instructions.
```

## Tips

- You can run all prompts in a single `claude` session, no need to restart between steps
- If a step fails, just re-run that prompt
- You can skip steps you don't need (e.g. skip diagrams if you only want docs)
- Replace `D:\your-project` with your actual project path
