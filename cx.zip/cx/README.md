# CX - 自动化项目文档生成工具

PowerShell 脚本 + Claude Code Skills，用于自动分析项目代码并生成结构化技术文档。

## 功能特性

- **智能项目扫描**：自动检测编程语言、框架、项目规模
- **深度代码分析**：分析架构、API、数据模型、业务流程、依赖关系、安全问题
- **多文档生成**：生成 CLAUDE.md、需求说明书、文件功能列表、PlantUML 图表
- **智能缓存**：24 小时内自动复用分析结果
- **选择性生成**：支持只生成指定的文档
- **容错机制**：单个文档失败不影响其他文档生成

## 安装要求

- PowerShell 5.1+ (Windows) 或 PowerShell Core 7+ (跨平台)
- [Claude Code CLI](https://github.com/anthropics/claude-code)

> **无管理员权限？** 直接使用 `generate-docs.bat` 启动，无需修改 ExecutionPolicy。

## 使用方法

### 基础用法

```cmd
# 在项目目录下运行，生成所有文档（推荐使用 .bat 启动）
cd D:\your-project
D:\cx\generate-docs.bat

# 指定项目路径
D:\cx\generate-docs.bat -Path "D:\your-project"
```

### 选择性生成

```cmd
# 只生成 CLAUDE.md
D:\cx\generate-docs.bat -ClaudeMd

# 只生成需求说明书和文件功能列表
D:\cx\generate-docs.bat -Requirements -FileSpec

# 只生成图表
D:\cx\generate-docs.bat -SystemOverview -ModuleDiagrams -FlowDiagrams
```

### 高级选项

```cmd
# 强制重新分析（忽略 24 小时缓存）
D:\cx\generate-docs.bat -ForceAnalysis

# 遇到错误立即停止（默认继续执行）
D:\cx\generate-docs.bat -StopOnError

# 显示详细输出
D:\cx\generate-docs.bat -Verbose
```

## 输出结构

```
your-project/
├── CLAUDE.md                      # 项目说明文档（复制自 .claude/）
└── .claude/
    ├── analysis/                  # 分析结果（JSON 格式）
    │   ├── project-info.json
    │   ├── architecture.json
    │   ├── apis.json
    │   ├── data-models.json
    │   ├── business-flows.json
    │   ├── dependencies.json
    │   ├── security.json
    │   └── file-tree.json
    ├── docs/                      # 生成的文档
    │   ├── requirements.md        # 需求说明书
    │   └── file-specification.md  # 文件功能列表
    └── diagrams/                  # PlantUML 图表
        ├── system-overview.puml   # 系统总览图
        ├── module-*.puml          # 模块结构图
        └── flow-*.puml            # 业务流程图
```

## 支持的项目类型

- **Web 应用**：React、Vue、Angular + Express、Django、Spring Boot
- **区块链项目**：Solidity + Hardhat/Truffle
- **微服务**：多模块后端服务
- **CLI 工具**：命令行应用
- **库/框架**：可复用的代码库

## 支持的语言和框架

### 语言
- JavaScript/TypeScript
- Python
- Java
- Go
- C#
- C/C++
- Rust
- Solidity

### 框架
- **后端**：Express、NestJS、Django、Flask、FastAPI、Spring Boot、ASP.NET Core
- **前端**：React、Vue、Angular
- **区块链**：Hardhat、Truffle

## 自定义 Skill

如果需要自定义文档生成逻辑，可以在项目的 `.claude/skills/` 目录下创建同名 skill 文件：

```
your-project/.claude/skills/
├── gen-claude-md.md           # 覆盖默认的 CLAUDE.md 生成逻辑
├── gen-requirements.md        # 覆盖默认的需求说明书生成逻辑
└── ...
```

脚本会优先使用项目目录下的 skill，如果不存在则使用 cx 工具目录下的默认 skill。

## 分析策略

根据项目规模自动选择分析策略：

- **完整分析**（<10 万行）：分析所有文件
- **适度分析**（10-50 万行）：分析主要模块
- **采样分析**（>50 万行）：采样关键文件

## 故障排除

### Claude CLI 未安装
```
[ERROR] Claude CLI 未安装或无法运行
```
解决方法：访问 https://github.com/anthropics/claude-code 安装 Claude CLI

### 项目目录为空
```
[ERROR] 项目目录为空，无法分析
```
解决方法：确保项目目录包含代码文件

### 单个文档生成失败
默认情况下，单个文档失败不会影响其他文档生成。如果需要在失败时停止，使用 `-StopOnError` 参数。

## 示例

### 分析一个 React + Express 项目

```cmd
D:\cx> generate-docs.bat -Path "D:\my-web-app"

[01:30:00] [INFO] CX - 自动化项目文档生成工具 v2.0
[01:30:01] [SUCCESS] Claude CLI 已安装: claude 1.0.0
[01:30:01] [SUCCESS] 项目目录: D:\my-web-app
[01:30:01] [INFO] 项目文件数: 250
[01:30:02] [SUCCESS] 检测到的语言: JavaScript/TypeScript
[01:30:03] [SUCCESS] 检测到的框架: 后端(Express), 前端(React)
[01:30:04] [SUCCESS] 项目规模: 120 个代码文件, 15000 行代码, 分析策略: full
[01:30:05] [INFO] 正在分析: 项目基本信息...
[01:30:10] [SUCCESS] 项目基本信息 分析完成
...
[01:35:00] [SUCCESS] 深度分析完成: 成功 8, 失败 0
[01:35:01] [INFO] 将生成 6 个文档
[01:35:02] [SUCCESS] CLAUDE.md 生成完成
[01:35:10] [SUCCESS] 需求说明书 生成完成
...
[01:40:00] [SUCCESS] 生成完成
[01:40:00] [INFO] 总耗时: 10:00
```

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！
