# CX - Automated Project Documentation Generator
# Version: 2.0
# Description: PowerShell script + Claude Code Skills for analyzing project code and generating structured technical docs

param(
    [string]$Path = $PWD.Path,
    [switch]$ForceAnalysis,
    [switch]$ContinueOnError = $true,
    [switch]$StopOnError,
    [switch]$Verbose,
    [int]$Timeout = 600,
    [switch]$All = $true,
    [switch]$ClaudeMd,
    [switch]$Requirements,
    [switch]$FileSpec,
    [switch]$SystemOverview,
    [switch]$ModuleDiagrams,
    [switch]$FlowDiagrams
)

# UTF-8 encoding setup (compatible with GBK environments)
try {
    $null = chcp 65001 2>$null
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch {
    $OutputEncoding = [System.Text.Encoding]::Default
}

# Global variables
$script:PROJECT_DIR = $Path
$script:CX_TOOL_DIR = $PSScriptRoot
$script:PROJECT_NAME = ""
$script:LANGUAGES = @()
$script:FRAMEWORKS = @{}
$script:PROJECT_SCALE = @{}
$script:ANALYSIS_DIR = ""
$script:DOCS_DIR = ""
$script:DIAGRAMS_DIR = ""
$script:GENERATED_DOCS = @()
$script:FAILED_DOCS = @()
$script:START_TIME = Get-Date

# ============================================
# Utility functions
# ============================================

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Type = "Info"
    )

    $timestamp = Get-Date -Format "HH:mm:ss"

    switch ($Type) {
        "Info" { Write-Host "[$timestamp] [INFO] $Message" -ForegroundColor Blue }
        "Success" { Write-Host "[$timestamp] [SUCCESS] $Message" -ForegroundColor Green }
        "Warning" { Write-Host "[$timestamp] [WARNING] $Message" -ForegroundColor Yellow }
        "Error" { Write-Host "[$timestamp] [ERROR] $Message" -ForegroundColor Red }
        "Stage" {
            Write-Host "`n========================================" -ForegroundColor Cyan
            Write-Host "  $Message" -ForegroundColor Cyan
            Write-Host "========================================`n" -ForegroundColor Cyan
        }
        "Progress" { Write-Host "[$timestamp] $Message" -ForegroundColor Magenta }
    }
}

# Run claude CLI with timeout, returns output string or $null on timeout
function Invoke-ClaudeWithTimeout {
    param(
        [string]$Prompt,
        [string]$SystemPrompt,
        [int]$TimeoutSeconds = $script:Timeout
    )

    $tempIn = [System.IO.Path]::GetTempFileName()
    $tempOut = [System.IO.Path]::GetTempFileName()
    $tempErr = [System.IO.Path]::GetTempFileName()

    try {
        Set-Content -Path $tempIn -Value $Prompt -Encoding UTF8

        $args = @(
            "-p", "`"$tempIn`"",
            "--append-system-prompt", "`"$SystemPrompt`"",
            "--allowedTools", "Write", "Edit", "Read", "Bash", "Glob", "Grep"
        )

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "claude"
        $psi.Arguments = "-p `"$(($Prompt -replace '"','\"'))`" --append-system-prompt `"$(($SystemPrompt -replace '"','\"'))`" --allowedTools Write Edit Read Bash Glob Grep"
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true

        $process = [System.Diagnostics.Process]::Start($psi)

        if ($process.WaitForExit($TimeoutSeconds * 1000)) {
            $output = $process.StandardOutput.ReadToEnd()
            $script:LastExitCode = $process.ExitCode
            return $output
        } else {
            # Timeout: kill process tree
            try { $process.Kill($true) } catch { $process.Kill() }
            $process.WaitForExit(5000)
            Write-ColorOutput "Timeout after $TimeoutSeconds seconds, skipping..." "Warning"
            $script:LastExitCode = -1
            return $null
        }
    } finally {
        Remove-Item $tempIn, $tempOut, $tempErr -ErrorAction SilentlyContinue
    }
}

# ============================================
# Environment check
# ============================================

function Test-Environment {
    Write-ColorOutput "Checking environment..." "Stage"

    # Check Claude CLI
    try {
        $claudeVersion = claude --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-ColorOutput "Claude CLI installed: $claudeVersion" "Success"
        } else {
            Write-ColorOutput "Claude CLI not installed or not working" "Error"
            Write-ColorOutput "Visit https://github.com/anthropics/claude-code to install" "Info"
            exit 1
        }
    } catch {
        Write-ColorOutput "Claude CLI not installed: $_" "Error"
        exit 1
    }

    # Check git-bash dependency for Claude CLI on Windows
    $gitBashPath = $env:CLAUDE_CODE_GIT_BASH_PATH
    if (-not $gitBashPath) {
        # Locate git.exe and derive bash.exe path from it
        $gitCmd = Get-Command git.exe -ErrorAction SilentlyContinue
        if ($gitCmd) {
            $gitDir = Split-Path (Split-Path $gitCmd.Source -Parent) -Parent
            $candidates = @(
                (Join-Path $gitDir "bin\bash.exe"),
                (Join-Path $gitDir "usr\bin\bash.exe")
            )
            foreach ($c in $candidates) {
                if (Test-Path $c) {
                    $gitBashPath = $c
                    break
                }
            }
        }

        if ($gitBashPath) {
            $env:CLAUDE_CODE_GIT_BASH_PATH = $gitBashPath
            Write-ColorOutput "git-bash: $gitBashPath" "Success"
        } else {
            Write-ColorOutput "git-bash not found, required by Claude CLI on Windows" "Error"
            exit 1
        }
    } else {
        Write-ColorOutput "git-bash: $gitBashPath" "Success"
    }

    # Check project directory
    if (-not (Test-Path $script:PROJECT_DIR)) {
        Write-ColorOutput "Project directory not found: $script:PROJECT_DIR" "Error"
        exit 1
    }
    Write-ColorOutput "Project directory: $script:PROJECT_DIR" "Success"

    # Check if project is empty
    $fileCount = (Get-ChildItem -Path $script:PROJECT_DIR -File -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($fileCount -eq 0) {
        Write-ColorOutput "Project directory is empty" "Error"
        exit 1
    }
    Write-ColorOutput "Project files: $fileCount" "Info"

    # Set project name
    $script:PROJECT_NAME = Split-Path $script:PROJECT_DIR -Leaf
    Write-ColorOutput "Project name: $script:PROJECT_NAME" "Info"

    # Create output directories
    $script:ANALYSIS_DIR = Join-Path $script:PROJECT_DIR ".claude\analysis"
    $script:DOCS_DIR = Join-Path $script:PROJECT_DIR ".claude\docs"
    $script:DIAGRAMS_DIR = Join-Path $script:PROJECT_DIR ".claude\diagrams"

    @($script:ANALYSIS_DIR, $script:DOCS_DIR, $script:DIAGRAMS_DIR) | ForEach-Object {
        if (-not (Test-Path $_)) {
            New-Item -ItemType Directory -Path $_ -Force | Out-Null
            Write-ColorOutput "Created directory: $_" "Info"
        }
    }
}

# ============================================
# Project scanning
# ============================================

function Get-Languages {
    Write-ColorOutput "Detecting languages..." "Info"
    $langs = @()

    if ((Test-Path (Join-Path $script:PROJECT_DIR "package.json")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.js","*.ts","*.jsx","*.tsx" -ErrorAction SilentlyContinue)) {
        $langs += "JavaScript/TypeScript"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "requirements.txt")) -or
        (Test-Path (Join-Path $script:PROJECT_DIR "setup.py")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.py" -ErrorAction SilentlyContinue)) {
        $langs += "Python"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "pom.xml")) -or
        (Test-Path (Join-Path $script:PROJECT_DIR "build.gradle")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.java" -ErrorAction SilentlyContinue)) {
        $langs += "Java"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "go.mod")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.go" -ErrorAction SilentlyContinue)) {
        $langs += "Go"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.c","*.cpp","*.h","*.hpp" -ErrorAction SilentlyContinue) {
        $langs += "C/C++"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.cs" -ErrorAction SilentlyContinue) {
        $langs += "C#"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.rs" -ErrorAction SilentlyContinue) {
        $langs += "Rust"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.sol" -ErrorAction SilentlyContinue) {
        $langs += "Solidity"
    }

    $script:LANGUAGES = $langs
    Write-ColorOutput "Languages detected: $($langs -join ', ')" "Success"
}

function Get-Frameworks {
    Write-ColorOutput "Detecting frameworks..." "Info"
    $frameworks = @{ backend = @(); frontend = @(); other = @() }

    # Backend frameworks
    $packageJsonPath = Join-Path $script:PROJECT_DIR "package.json"
    if (Test-Path $packageJsonPath) {
        $packageJson = Get-Content $packageJsonPath -Raw -ErrorAction SilentlyContinue
        if ($packageJson -match '"express"') { $frameworks.backend += "Express" }
        if ($packageJson -match '"@nestjs/core"') { $frameworks.backend += "NestJS" }
    }

    $requirementsPath = Join-Path $script:PROJECT_DIR "requirements.txt"
    if (Test-Path $requirementsPath) {
        $requirements = Get-Content $requirementsPath -Raw -ErrorAction SilentlyContinue
        if ($requirements -match 'django') { $frameworks.backend += "Django" }
        if ($requirements -match 'flask') { $frameworks.backend += "Flask" }
        if ($requirements -match 'fastapi') { $frameworks.backend += "FastAPI" }
    }

    if (Test-Path (Join-Path $script:PROJECT_DIR "pom.xml")) {
        $pomContent = Get-Content (Join-Path $script:PROJECT_DIR "pom.xml") -Raw -ErrorAction SilentlyContinue
        if ($pomContent -match 'spring-boot') { $frameworks.backend += "Spring Boot" }
    }

    # Frontend frameworks
    if (Test-Path $packageJsonPath) {
        if ($packageJson -match '"react"') { $frameworks.frontend += "React" }
        if ($packageJson -match '"vue"') { $frameworks.frontend += "Vue" }
        if ($packageJson -match '"@angular/core"') { $frameworks.frontend += "Angular" }
    }

    # Other frameworks
    if (Test-Path (Join-Path $script:PROJECT_DIR "hardhat.config")) { $frameworks.other += "Hardhat" }
    if (Test-Path (Join-Path $script:PROJECT_DIR "truffle-config.js")) { $frameworks.other += "Truffle" }

    $script:FRAMEWORKS = $frameworks

    $allFrameworks = @()
    if ($frameworks.backend.Count -gt 0) { $allFrameworks += "Backend($($frameworks.backend -join ', '))" }
    if ($frameworks.frontend.Count -gt 0) { $allFrameworks += "Frontend($($frameworks.frontend -join ', '))" }
    if ($frameworks.other.Count -gt 0) { $allFrameworks += "Other($($frameworks.other -join ', '))" }

    if ($allFrameworks.Count -gt 0) {
        Write-ColorOutput "Frameworks detected: $($allFrameworks -join ', ')" "Success"
    } else {
        Write-ColorOutput "No frameworks detected" "Warning"
    }
}

function Get-ProjectScale {
    Write-ColorOutput "Calculating project scale..." "Info"

    $codeExtensions = @("*.js","*.ts","*.jsx","*.tsx","*.py","*.java","*.go","*.c","*.cpp","*.h","*.hpp","*.cs","*.rs","*.sol")
    $codeFiles = Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Include $codeExtensions -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch '(node_modules|\.git|dist|build|vendor|__pycache__)' }

    $totalLines = 0
    foreach ($file in $codeFiles) {
        try {
            $totalLines += (Get-Content $file.FullName -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
        } catch {}
    }

    # Determine analysis strategy
    $strategy = "full"
    if ($totalLines -gt 500000) { $strategy = "sampling" }
    elseif ($totalLines -gt 100000) { $strategy = "moderate" }

    $script:PROJECT_SCALE = @{
        code_files = $codeFiles.Count
        code_lines = $totalLines
        strategy = $strategy
    }

    Write-ColorOutput "Project scale: $($codeFiles.Count) code files, $totalLines lines, strategy: $strategy" "Success"
}

function Invoke-ProjectScan {
    Write-ColorOutput "Scanning project..." "Stage"
    Get-Languages
    Get-Frameworks
    Get-ProjectScale
}

# ============================================
# Skill management
# ============================================

function Find-Skill {
    param(
        [string]$SkillName,
        [string]$Category = ""
    )

    # Search order: project skills -> cx tool skills
    $searchPaths = @()

    if ($Category) {
        $searchPaths += Join-Path $script:PROJECT_DIR ".claude\skills\$Category\$SkillName.md"
        $searchPaths += Join-Path $script:CX_TOOL_DIR "skills\$Category\$SkillName.md"
    } else {
        $searchPaths += Join-Path $script:PROJECT_DIR ".claude\skills\$SkillName.md"
        $searchPaths += Join-Path $script:CX_TOOL_DIR "skills\$SkillName.md"
    }

    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            Write-ColorOutput "Found skill: $path" "Info"
            return $path
        }
    }

    return $null
}

# ============================================
# Deep analysis
# ============================================

function Test-AnalysisCache {
    if ($ForceAnalysis) { return $false }

    $cacheFile = Join-Path $script:ANALYSIS_DIR "project-info.json"
    if (Test-Path $cacheFile) {
        $cacheAge = (Get-Date) - (Get-Item $cacheFile).LastWriteTime
        if ($cacheAge.TotalHours -lt 24) {
            Write-ColorOutput "Using cached analysis ($('{0:N1}' -f $cacheAge.TotalHours) hours ago)" "Info"
            return $true
        }
    }
    return $false
}

function Invoke-DeepAnalysis {
    Write-ColorOutput "Deep analysis..." "Stage"

    if (Test-AnalysisCache) {
        return $true
    }

    $analysisSkills = @(
        @{ name = "analyze-project-info"; desc = "project-info" }
        @{ name = "analyze-architecture"; desc = "architecture" }
        @{ name = "analyze-apis"; desc = "APIs" }
        @{ name = "analyze-data-models"; desc = "data-models" }
        @{ name = "analyze-business-flows"; desc = "business-flows" }
        @{ name = "analyze-dependencies"; desc = "dependencies" }
        @{ name = "analyze-security"; desc = "security" }
        @{ name = "analyze-file-tree"; desc = "file-tree" }
    )

    $successCount = 0
    $failCount = 0

    for ($i = 0; $i -lt $analysisSkills.Count; $i++) {
        $skill = $analysisSkills[$i]
        $progress = "[$($i + 1)/$($analysisSkills.Count)]"

        Write-ColorOutput "$progress Analyzing: $($skill.desc)..." "Progress"

        $result = Invoke-SkillAnalysis -SkillName $skill.name

        if ($result) {
            $successCount++
            Write-ColorOutput "$progress $($skill.desc) done" "Success"
        } else {
            $failCount++
            Write-ColorOutput "$progress $($skill.desc) failed" "Error"

            if ($StopOnError -or -not $ContinueOnError) {
                Write-ColorOutput "Analysis failed, stopping" "Error"
                exit 1
            }
        }
    }

    Write-ColorOutput "Deep analysis complete: $successCount succeeded, $failCount failed" "Info"
    return ($successCount -gt 0)
}

function Invoke-SkillAnalysis {
    param([string]$SkillName)

    $skillPath = Find-Skill -SkillName $SkillName -Category "deep-analyzer"

    if (-not $skillPath) {
        Write-ColorOutput "Skill not found: $SkillName" "Error"
        return $false
    }

    # Build prompt
    $outputFile = Join-Path $script:ANALYSIS_DIR "$SkillName.json".Replace("analyze-", "")

    $prompt = @"
项目路径: $script:PROJECT_DIR
项目名称: $script:PROJECT_NAME
语言: $($script:LANGUAGES -join ', ')
框架: 后端($($script:FRAMEWORKS.backend -join ', ')), 前端($($script:FRAMEWORKS.frontend -join ', '))
规模: $($script:PROJECT_SCALE.code_files) 文件, $($script:PROJECT_SCALE.code_lines) 行
策略: $($script:PROJECT_SCALE.strategy)
输出文件: $outputFile

请分析项目并生成 JSON 文件。
"@

    try {
        # Read skill content as system prompt
        $skillContent = Get-Content $skillPath -Raw -Encoding UTF8

        # Call Claude CLI with timeout
        $output = Invoke-ClaudeWithTimeout -Prompt $prompt -SystemPrompt $skillContent

        if ($null -eq $output) {
            Write-ColorOutput "Skill timed out: $SkillName" "Error"
            return $false
        }

        if ($script:LastExitCode -eq 0 -and (Test-Path $outputFile)) {
            return $true
        } else {
            Write-ColorOutput "Skill execution failed: $output" "Error"
            return $false
        }
    } catch {
        Write-ColorOutput "Skill execution error: $_" "Error"
        return $false
    }
}

# ============================================
# Document generation
# ============================================

function Get-DocumentsToGenerate {
    # If any specific flag is set, disable All
    if ($ClaudeMd -or $Requirements -or $FileSpec -or $SystemOverview -or $ModuleDiagrams -or $FlowDiagrams) {
        $script:All = $false
    }

    $docs = @()

    if ($All -or $ClaudeMd) { $docs += @{ name = "gen-claude-md"; desc = "CLAUDE.md" } }
    if ($All -or $Requirements) { $docs += @{ name = "gen-requirements"; desc = "requirements" } }
    if ($All -or $FileSpec) { $docs += @{ name = "gen-file-spec"; desc = "file-specification" } }
    if ($All -or $SystemOverview) { $docs += @{ name = "gen-system-overview"; desc = "system-overview" } }
    if ($All -or $ModuleDiagrams) { $docs += @{ name = "gen-module-diagrams"; desc = "module-diagrams" } }
    if ($All -or $FlowDiagrams) { $docs += @{ name = "gen-flow-diagrams"; desc = "flow-diagrams" } }

    return $docs
}

function Invoke-DocumentGeneration {
    Write-ColorOutput "Generating documents..." "Stage"

    $docs = Get-DocumentsToGenerate

    if ($docs.Count -eq 0) {
        Write-ColorOutput "No documents to generate" "Warning"
        return
    }

    Write-ColorOutput "Will generate $($docs.Count) document(s)" "Info"

    for ($i = 0; $i -lt $docs.Count; $i++) {
        $doc = $docs[$i]
        $progress = "[$($i + 1)/$($docs.Count)]"

        Write-ColorOutput "$progress Generating: $($doc.desc)..." "Progress"

        $result = Invoke-SkillGeneration -SkillName $doc.name

        if ($result) {
            $script:GENERATED_DOCS += $doc.desc
            Write-ColorOutput "$progress $($doc.desc) done" "Success"
        } else {
            $script:FAILED_DOCS += $doc.desc
            Write-ColorOutput "$progress $($doc.desc) failed" "Error"

            if ($StopOnError -or -not $ContinueOnError) {
                Write-ColorOutput "Generation failed, stopping" "Error"
                exit 1
            }
        }
    }
}

function Invoke-SkillGeneration {
    param([string]$SkillName)

    $skillPath = Find-Skill -SkillName $SkillName

    if (-not $skillPath) {
        Write-ColorOutput "Skill not found: $SkillName" "Error"
        return $false
    }

    # Build prompt with analysis data paths
    $prompt = @"
项目路径: $script:PROJECT_DIR
项目名称: $script:PROJECT_NAME
分析数据目录: $script:ANALYSIS_DIR
文档输出目录: $script:DOCS_DIR
图表输出目录: $script:DIAGRAMS_DIR

请根据分析数据生成文档。
"@

    try {
        # Read skill content as system prompt
        $skillContent = Get-Content $skillPath -Raw -Encoding UTF8

        # Call Claude CLI with timeout
        $output = Invoke-ClaudeWithTimeout -Prompt $prompt -SystemPrompt $skillContent

        if ($null -eq $output) {
            Write-ColorOutput "Skill timed out: $SkillName" "Error"
            return $false
        }

        if ($script:LastExitCode -eq 0) {
            return $true
        } else {
            Write-ColorOutput "Skill execution failed: $output" "Error"
            return $false
        }
    } catch {
        Write-ColorOutput "Skill execution error: $_" "Error"
        return $false
    }
}

# ============================================
# Summary report
# ============================================

function Show-Summary {
    $elapsed = (Get-Date) - $script:START_TIME
    $elapsedStr = "{0:mm\:ss}" -f $elapsed

    Write-ColorOutput "Complete" "Stage"

    if ($script:GENERATED_DOCS.Count -gt 0) {
        Write-ColorOutput "Generated: $($script:GENERATED_DOCS -join ', ')" "Success"
    }
    if ($script:FAILED_DOCS.Count -gt 0) {
        Write-ColorOutput "Failed: $($script:FAILED_DOCS -join ', ')" "Error"
    }

    Write-ColorOutput "Elapsed: $elapsedStr" "Info"

    Write-Host "`nOutput directories:" -ForegroundColor Cyan
    Write-Host "  Analysis: $script:ANALYSIS_DIR" -ForegroundColor Cyan
    Write-Host "  Docs:     $script:DOCS_DIR" -ForegroundColor Cyan
    Write-Host "  Diagrams: $script:DIAGRAMS_DIR" -ForegroundColor Cyan

    if (Test-Path (Join-Path $script:PROJECT_DIR "CLAUDE.md")) {
        Write-ColorOutput "`nCLAUDE.md copied to project root" "Success"
    }
}

# ============================================
# Main flow
# ============================================

function Main {
    Write-ColorOutput "CX - Project Documentation Generator v2.0" "Stage"

    # 1. Environment check
    Test-Environment

    # 2. Project scan
    Invoke-ProjectScan

    # 3. Deep analysis
    $analysisSuccess = Invoke-DeepAnalysis

    if (-not $analysisSuccess) {
        Write-ColorOutput "Deep analysis failed, cannot generate documents" "Error"
        exit 1
    }

    # 4. Document generation
    Invoke-DocumentGeneration

    # 5. Summary
    Show-Summary
}

# Run
Main
