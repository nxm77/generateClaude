# CX - 自动化项目文档生成工具
# 版本: 2.0
# 说明: PowerShell 脚本 + Claude Code Skills，用于自动分析项目代码并生成结构化技术文档

param(
    [string]$Path = $PWD.Path,
    [switch]$ForceAnalysis,
    [switch]$ContinueOnError = $true,
    [switch]$StopOnError,
    [switch]$Verbose,
    [switch]$All = $true,
    [switch]$ClaudeMd,
    [switch]$Requirements,
    [switch]$FileSpec,
    [switch]$SystemOverview,
    [switch]$ModuleDiagrams,
    [switch]$FlowDiagrams
)

# UTF-8 BOM 编码设置
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

# 全局变量
$script:PROJECT_DIR = $Path
$script:CX_TOOL_DIR = $PSScriptRoot
$script:PROJECT_NAME = ""
$script:LANGUAGES = @()
$script:FRAMEWORKS = @{}
$script:PROJECT_SCALE = @{}
$script:ANALYSIS_DIR = ""
$script:DOCS_DIR = ""
$script:DIAGRAMS_DIR = ""
$script:GENERATED_DOCS = @()
$script:FAILED_DOCS = @()
$script:START_TIME = Get-Date

# ============================================
# 工具函数
# ============================================

# 颜色输出函数
function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Type = "Info"
    )

    $timestamp = Get-Date -Format "HH:mm:ss"

    switch ($Type) {
        "Info" { Write-Host "[$timestamp] [INFO] $Message" -ForegroundColor Blue }
        "Success" { Write-Host "[$timestamp] [SUCCESS] $Message" -ForegroundColor Green }
        "Warning" { Write-Host "[$timestamp] [WARNING] $Message" -ForegroundColor Yellow }
        "Error" { Write-Host "[$timestamp] [ERROR] $Message" -ForegroundColor Red }
        "Stage" {
            Write-Host "`n========================================" -ForegroundColor Cyan
            Write-Host "  $Message" -ForegroundColor Cyan
            Write-Host "========================================`n" -ForegroundColor Cyan
        }
        "Progress" { Write-Host "[$timestamp] $Message" -ForegroundColor Magenta }
    }
}

# ============================================
# 环境检查
# ============================================

function Test-Environment {
    Write-ColorOutput "检查运行环境..." "Stage"

    # 检查 Claude CLI
    try {
        $claudeVersion = claude --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-ColorOutput "Claude CLI 已安装: $claudeVersion" "Success"
        } else {
            Write-ColorOutput "Claude CLI 未安装或无法运行" "Error"
            Write-ColorOutput "请访问 https://github.com/anthropics/claude-code 安装 Claude CLI" "Info"
            exit 1
        }
    } catch {
        Write-ColorOutput "Claude CLI 未安装: $_" "Error"
        exit 1
    }

    # 检查项目目录
    if (-not (Test-Path $script:PROJECT_DIR)) {
        Write-ColorOutput "项目目录不存在: $script:PROJECT_DIR" "Error"
        exit 1
    }
    Write-ColorOutput "项目目录: $script:PROJECT_DIR" "Success"

    # 检查项目是否为空
    $fileCount = (Get-ChildItem -Path $script:PROJECT_DIR -File -Recurse -ErrorAction SilentlyContinue | Measure-Object).Count
    if ($fileCount -eq 0) {
        Write-ColorOutput "项目目录为空，无法分析" "Error"
        exit 1
    }
    Write-ColorOutput "项目文件数: $fileCount" "Info"

    # 设置项目名称
    $script:PROJECT_NAME = Split-Path $script:PROJECT_DIR -Leaf
    Write-ColorOutput "项目名称: $script:PROJECT_NAME" "Info"

    # 创建输出目录
    $script:ANALYSIS_DIR = Join-Path $script:PROJECT_DIR ".claude\analysis"
    $script:DOCS_DIR = Join-Path $script:PROJECT_DIR ".claude\docs"
    $script:DIAGRAMS_DIR = Join-Path $script:PROJECT_DIR ".claude\diagrams"

    @($script:ANALYSIS_DIR, $script:DOCS_DIR, $script:DIAGRAMS_DIR) | ForEach-Object {
        if (-not (Test-Path $_)) {
            New-Item -ItemType Directory -Path $_ -Force | Out-Null
            Write-ColorOutput "创建目录: $_" "Info"
        }
    }
}

# ============================================
# 项目扫描
# ============================================

function Get-Languages {
    Write-ColorOutput "正在分析编程语言..." "Info"
    $langs = @()

    if ((Test-Path (Join-Path $script:PROJECT_DIR "package.json")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.js","*.ts","*.jsx","*.tsx" -ErrorAction SilentlyContinue)) {
        $langs += "JavaScript/TypeScript"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "requirements.txt")) -or
        (Test-Path (Join-Path $script:PROJECT_DIR "setup.py")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.py" -ErrorAction SilentlyContinue)) {
        $langs += "Python"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "pom.xml")) -or
        (Test-Path (Join-Path $script:PROJECT_DIR "build.gradle")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.java" -ErrorAction SilentlyContinue)) {
        $langs += "Java"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "go.mod")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.go" -ErrorAction SilentlyContinue)) {
        $langs += "Go"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.c","*.cpp","*.h","*.hpp" -ErrorAction SilentlyContinue) {
        $langs += "C/C++"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.cs","*.csproj" -ErrorAction SilentlyContinue) {
        $langs += "C#"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.rs" -ErrorAction SilentlyContinue) {
        $langs += "Rust"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.sol" -ErrorAction SilentlyContinue) {
        $langs += "Solidity"
    }

    $script:LANGUAGES = if ($langs.Count -eq 0) { @("未检测到") } else { $langs }
    Write-ColorOutput "检测到的语言: $($script:LANGUAGES -join ', ')" "Success"
}

function Get-Frameworks {
    Write-ColorOutput "正在分析框架..." "Info"
    $script:FRAMEWORKS = @{
        backend = @()
        frontend = @()
        other = @()
    }

    # 检查 package.json
    $packageJsonPath = Join-Path $script:PROJECT_DIR "package.json"
    if (Test-Path $packageJsonPath) {
        $packageJson = Get-Content $packageJsonPath -Raw -Encoding UTF8
        if ($packageJson -match "react") { $script:FRAMEWORKS.frontend += "React" }
        if ($packageJson -match "vue") { $script:FRAMEWORKS.frontend += "Vue" }
        if ($packageJson -match "angular") { $script:FRAMEWORKS.frontend += "Angular" }
        if ($packageJson -match "express") { $script:FRAMEWORKS.backend += "Express" }
        if ($packageJson -match "nest") { $script:FRAMEWORKS.backend += "NestJS" }
        if ($packageJson -match "hardhat") { $script:FRAMEWORKS.other += "Hardhat" }
        if ($packageJson -match "truffle") { $script:FRAMEWORKS.other += "Truffle" }
    }

    # 检查 Python 框架
    $requirementsPath = Join-Path $script:PROJECT_DIR "requirements.txt"
    if (Test-Path $requirementsPath) {
        $requirements = Get-Content $requirementsPath -Raw -Encoding UTF8
        if ($requirements -match "django") { $script:FRAMEWORKS.backend += "Django" }
        if ($requirements -match "flask") { $script:FRAMEWORKS.backend += "Flask" }
        if ($requirements -match "fastapi") { $script:FRAMEWORKS.backend += "FastAPI" }
    }

    # 检查 Java 框架
    $pomPath = Join-Path $script:PROJECT_DIR "pom.xml"
    if (Test-Path $pomPath) {
        $pom = Get-Content $pomPath -Raw -Encoding UTF8
        if ($pom -match "spring-boot") { $script:FRAMEWORKS.backend += "Spring Boot" }
    }

    # 检查 .NET 框架
    $csprojFiles = Get-ChildItem -Path $script:PROJECT_DIR -Filter "*.csproj" -Recurse -Depth 2 -ErrorAction SilentlyContinue
    if ($csprojFiles) {
        $script:FRAMEWORKS.backend += "ASP.NET Core"
    }

    $totalFrameworks = $script:FRAMEWORKS.backend.Count + $script:FRAMEWORKS.frontend.Count + $script:FRAMEWORKS.other.Count
    if ($totalFrameworks -gt 0) {
        Write-ColorOutput "检测到的框架: 后端($($script:FRAMEWORKS.backend -join ', ')), 前端($($script:FRAMEWORKS.frontend -join ', ')), 其他($($script:FRAMEWORKS.other -join ', '))" "Success"
    } else {
        Write-ColorOutput "未检测到框架" "Warning"
    }
}

function Get-ProjectScale {
    Write-ColorOutput "正在统计项目规模..." "Info"

    $codeExtensions = @("*.js", "*.ts", "*.jsx", "*.tsx", "*.py", "*.java", "*.go", "*.c", "*.cpp", "*.cs", "*.rs", "*.sol")
    $codeFiles = Get-ChildItem -Path $script:PROJECT_DIR -Include $codeExtensions -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.FullName -notmatch "node_modules|__pycache__|\.git|dist|build|target|venv" }

    $totalLines = 0
    $fileCount = 0
    foreach ($file in $codeFiles) {
        $lines = (Get-Content $file.FullName -ErrorAction SilentlyContinue | Measure-Object -Line).Lines
        $totalLines += $lines
        $fileCount++
    }

    $script:PROJECT_SCALE = @{
        code_lines = $totalLines
        code_files = $fileCount
        strategy = if ($totalLines -lt 100000) { "full" } elseif ($totalLines -lt 500000) { "moderate" } else { "sampling" }
    }

    Write-ColorOutput "项目规模: $fileCount 个代码文件, $totalLines 行代码, 分析策略: $($script:PROJECT_SCALE.strategy)" "Success"
}

function Invoke-ProjectScan {
    Write-ColorOutput "扫描项目..." "Stage"

    Get-Languages
    Get-Frameworks
    Get-ProjectScale
}

# ============================================
# 深度分析
# ============================================

function Test-AnalysisCache {
    $projectInfoPath = Join-Path $script:ANALYSIS_DIR "project-info.json"

    if (-not (Test-Path $projectInfoPath)) {
        return $false
    }

    $fileInfo = Get-Item $projectInfoPath
    $age = (Get-Date) - $fileInfo.LastWriteTime

    if ($age.TotalHours -lt 24) {
        Write-ColorOutput "发现 24 小时内的分析结果 (生成于 $($fileInfo.LastWriteTime))" "Info"
        return $true
    }

    return $false
}

function Invoke-DeepAnalysis {
    Write-ColorOutput "深度分析项目..." "Stage"

    # 检查缓存
    if (-not $ForceAnalysis -and (Test-AnalysisCache)) {
        Write-ColorOutput "使用已有分析结果（使用 -ForceAnalysis 强制重新分析）" "Info"
        return $true
    }

    if ($ForceAnalysis) {
        Write-ColorOutput "强制重新分析..." "Warning"
    }

    # 8 个分析 skill
    $analysisSkills = @(
        @{ name = "analyze-project-info"; desc = "项目基本信息" }
        @{ name = "analyze-architecture"; desc = "架构分析" }
        @{ name = "analyze-apis"; desc = "API 端点" }
        @{ name = "analyze-data-models"; desc = "数据模型" }
        @{ name = "analyze-business-flows"; desc = "业务流程" }
        @{ name = "analyze-dependencies"; desc = "依赖关系" }
        @{ name = "analyze-security"; desc = "安全检查" }
        @{ name = "analyze-file-tree"; desc = "文件树" }
    )

    $successCount = 0
    $failCount = 0

    for ($i = 0; $i -lt $analysisSkills.Count; $i++) {
        $skill = $analysisSkills[$i]
        $progress = "[$($i + 1)/$($analysisSkills.Count)]"

        Write-ColorOutput "$progress 正在分析: $($skill.desc)..." "Progress"

        $result = Invoke-SkillAnalysis -SkillName $skill.name

        if ($result) {
            $successCount++
            Write-ColorOutput "$progress $($skill.desc) 分析完成" "Success"
        } else {
            $failCount++
            Write-ColorOutput "$progress $($skill.desc) 分析失败" "Error"

            if ($StopOnError -or -not $ContinueOnError) {
                Write-ColorOutput "分析失败，停止执行" "Error"
                exit 1
            }
        }
    }

    Write-ColorOutput "深度分析完成: 成功 $successCount, 失败 $failCount" "Info"
    return ($successCount -gt 0)
}

function Invoke-SkillAnalysis {
    param([string]$SkillName)

    $skillPath = Find-Skill -SkillName $SkillName -Category "deep-analyzer"

    if (-not $skillPath) {
        Write-ColorOutput "找不到 skill: $SkillName" "Error"
        return $false
    }

    # 构建 prompt
    $outputFile = Join-Path $script:ANALYSIS_DIR "$SkillName.json".Replace("analyze-", "")

    $prompt = @"
项目路径: $script:PROJECT_DIR
项目名称: $script:PROJECT_NAME
语言: $($script:LANGUAGES -join ', ')
框架: 后端($($script:FRAMEWORKS.backend -join ', ')), 前端($($script:FRAMEWORKS.frontend -join ', '))
规模: $($script:PROJECT_SCALE.code_files) 文件, $($script:PROJECT_SCALE.code_lines) 行
策略: $($script:PROJECT_SCALE.strategy)
输出文件: $outputFile

请分析项目并生成 JSON 文件。
"@

    try {
        # 调用 Claude CLI
        $output = claude -p $prompt --skill $skillPath 2>&1

        if ($LASTEXITCODE -eq 0 -and (Test-Path $outputFile)) {
            return $true
        } else {
            Write-ColorOutput "Skill 执行失败: $output" "Error"
            return $false
        }
    } catch {
        Write-ColorOutput "Skill 执行异常: $_" "Error"
        return $false
    }
}

# ============================================
# 文档生成
# ============================================

function Get-DocumentsToGenerate {
    # 如果指定了任何单独参数，All 自动变为 false
    if ($ClaudeMd -or $Requirements -or $FileSpec -or $SystemOverview -or $ModuleDiagrams -or $FlowDiagrams) {
        $script:All = $false
    }

    $docs = @()

    if ($All -or $ClaudeMd) { $docs += @{ name = "gen-claude-md"; desc = "CLAUDE.md" } }
    if ($All -or $Requirements) { $docs += @{ name = "gen-requirements"; desc = "需求说明书" } }
    if ($All -or $FileSpec) { $docs += @{ name = "gen-file-spec"; desc = "文件功能列表" } }
    if ($All -or $SystemOverview) { $docs += @{ name = "gen-system-overview"; desc = "系统总览图" } }
    if ($All -or $ModuleDiagrams) { $docs += @{ name = "gen-module-diagrams"; desc = "模块结构图" } }
    if ($All -or $FlowDiagrams) { $docs += @{ name = "gen-flow-diagrams"; desc = "流程时序图" } }

    return $docs
}

function Invoke-DocumentGeneration {
    Write-ColorOutput "生成文档..." "Stage"

    $docs = Get-DocumentsToGenerate

    if ($docs.Count -eq 0) {
        Write-ColorOutput "没有需要生成的文档" "Warning"
        return
    }

    Write-ColorOutput "将生成 $($docs.Count) 个文档" "Info"

    for ($i = 0; $i -lt $docs.Count; $i++) {
        $doc = $docs[$i]
        $progress = "[$($i + 1)/$($docs.Count)]"

        Write-ColorOutput "$progress 正在生成: $($doc.desc)..." "Progress"

        $result = Invoke-SkillGeneration -SkillName $doc.name

        if ($result) {
            $script:GENERATED_DOCS += $doc.desc
            Write-ColorOutput "$progress $($doc.desc) 生成完成" "Success"
        } else {
            $script:FAILED_DOCS += $doc.desc
            Write-ColorOutput "$progress $($doc.desc) 生成失败" "Error"

            if ($StopOnError -or -not $ContinueOnError) {
                Write-ColorOutput "文档生成失败，停止执行" "Error"
                exit 1
            }
        }
    }
}

function Invoke-SkillGeneration {
    param([string]$SkillName)

    $skillPath = Find-Skill -SkillName $SkillName

    if (-not $skillPath) {
        Write-ColorOutput "找不到 skill: $SkillName" "Error"
        return $false
    }

    # 构建 prompt，包含所有分析结果
    $analysisFiles = Get-ChildItem -Path $script:ANALYSIS_DIR -Filter "*.json" -ErrorAction SilentlyContinue
    $analysisData = @{}

    foreach ($file in $analysisFiles) {
        try {
            $content = Get-Content $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $analysisData[$file.BaseName] = $content
        } catch {
            Write-ColorOutput "无法读取分析文件: $($file.Name)" "Warning"
        }
    }

    $prompt = @"
项目路径: $script:PROJECT_DIR
项目名称: $script:PROJECT_NAME
输出目录: $script:DOCS_DIR
图表目录: $script:DIAGRAMS_DIR

分析结果已保存在: $script:ANALYSIS_DIR

请根据分析结果生成文档。
"@

    try {
        # 调用 Claude CLI
        $output = claude -p $prompt --skill $skillPath 2>&1

        if ($LASTEXITCODE -eq 0) {
            return $true
        } else {
            Write-ColorOutput "Skill 执行失败: $output" "Error"
            return $false
        }
    } catch {
        Write-ColorOutput "Skill 执行异常: $_" "Error"
        return $false
    }
}

# ============================================
# Skill 查找
# ============================================

function Find-Skill {
    param(
        [string]$SkillName,
        [string]$Category = ""
    )

    $skillFileName = "$SkillName.md"
    $searchPaths = @()

    # 优先查找项目的 .claude/skills/
    if ($Category) {
        $searchPaths += Join-Path $script:PROJECT_DIR ".claude\skills\$Category\$skillFileName"
    }
    $searchPaths += Join-Path $script:PROJECT_DIR ".claude\skills\$skillFileName"

    # 回退到 cx 工具的 skills/
    if ($Category) {
        $searchPaths += Join-Path $script:CX_TOOL_DIR "skills\$Category\$skillFileName"
    }
    $searchPaths += Join-Path $script:CX_TOOL_DIR "skills\$skillFileName"

    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            Write-ColorOutput "找到 skill: $path" "Info" -Verbose:$Verbose
            return $path
        }
    }

    return $null
}

# ============================================
# 总结报告
# ============================================

function Show-Summary {
    Write-ColorOutput "生成完成" "Stage"

    $duration = (Get-Date) - $script:START_TIME
    Write-ColorOutput "总耗时: $($duration.ToString('mm\:ss'))" "Info"

    if ($script:GENERATED_DOCS.Count -gt 0) {
        Write-ColorOutput "`n成功生成的文档:" "Success"
        $script:GENERATED_DOCS | ForEach-Object { Write-Host "  ✓ $_" -ForegroundColor Green }
    }

    if ($script:FAILED_DOCS.Count -gt 0) {
        Write-ColorOutput "`n失败的文档:" "Error"
        $script:FAILED_DOCS | ForEach-Object { Write-Host "  ✗ $_" -ForegroundColor Red }
    }

    Write-ColorOutput "`n输出目录:" "Info"
    Write-Host "  分析结果: $script:ANALYSIS_DIR" -ForegroundColor Cyan
    Write-Host "  文档: $script:DOCS_DIR" -ForegroundColor Cyan
    Write-Host "  图表: $script:DIAGRAMS_DIR" -ForegroundColor Cyan

    if (Test-Path (Join-Path $script:PROJECT_DIR "CLAUDE.md")) {
        Write-ColorOutput "`nCLAUDE.md 已复制到项目根目录" "Success"
    }
}

# ============================================
# 主流程
# ============================================

function Main {
    Write-ColorOutput "CX - 自动化项目文档生成工具 v2.0" "Stage"

    # 1. 环境检查
    Test-Environment

    # 2. 项目扫描
    Invoke-ProjectScan

    # 3. 深度分析
    $analysisSuccess = Invoke-DeepAnalysis

    if (-not $analysisSuccess) {
        Write-ColorOutput "深度分析失败，无法生成文档" "Error"
        exit 1
    }

    # 4. 文档生成
    Invoke-DocumentGeneration

    # 5. 总结报告
    Show-Summary
}

# 执行主流程
Main

