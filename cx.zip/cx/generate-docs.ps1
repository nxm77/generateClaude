# CX - Automated Project Documentation Generator
# Version: 2.0
# Description: PowerShell script + Claude Code Skills for analyzing project code and generating structured technical docs

param(
    [string]$Path = $PWD.Path,
    [switch]$UseCache,
    [switch]$ContinueOnError = $true,
    [switch]$StopOnError,
    [switch]$Verbose,
    [int]$Timeout = 600,
    [switch]$All = $true,
    [switch]$ClaudeMd,
    [switch]$Requirements,
    [switch]$FileSpec,
    [switch]$SystemOverview,
    [switch]$ModuleDiagrams,
    [switch]$FlowDiagrams
)

# UTF-8 encoding setup (compatible with GBK environments)
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch {
    # Ensure PowerShell pipeline uses UTF-8 even when Console is unavailable
    $OutputEncoding = [System.Text.Encoding]::UTF8
}

# Global variables
$script:PROJECT_DIR = $Path
$script:CX_TOOL_DIR = $PSScriptRoot
$script:PROJECT_NAME = ""
$script:LANGUAGES = @()
$script:FRAMEWORKS = @{}
$script:PROJECT_SCALE = @{}
$script:ANALYSIS_DIR = ""
$script:DOCS_DIR = ""
$script:DIAGRAMS_DIR = ""
$script:GENERATED_DOCS = @()
$script:FAILED_DOCS = @()
$script:START_TIME = Get-Date

# ============================================
# Utility functions
# ============================================

function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Type = "Info"
    )

    $timestamp = Get-Date -Format "HH:mm:ss"

    switch ($Type) {
        "Info" { Write-Host "[$timestamp] [INFO] $Message" -ForegroundColor Blue }
        "Success" { Write-Host "[$timestamp] [SUCCESS] $Message" -ForegroundColor Green }
        "Warning" { Write-Host "[$timestamp] [WARNING] $Message" -ForegroundColor Yellow }
        "Error" { Write-Host "[$timestamp] [ERROR] $Message" -ForegroundColor Red }
        "Stage" {
            Write-Host "`n========================================" -ForegroundColor Cyan
            Write-Host "  $Message" -ForegroundColor Cyan
            Write-Host "========================================`n" -ForegroundColor Cyan
        }
        "Progress" { Write-Host "[$timestamp] $Message" -ForegroundColor Magenta }
    }
}

# Run claude CLI with timeout, returns output string or $null on timeout
function Invoke-ClaudeWithTimeout {
    param(
        [string]$Prompt,
        [string]$SystemPrompt,
        [int]$TimeoutSeconds = $script:Timeout
    )

    # Pass prompt and system prompt via temp files to avoid Windows command line length limit (~8191 chars)
    $tempPrompt = [System.IO.Path]::GetTempFileName()
    $tempSystem = [System.IO.Path]::GetTempFileName()

    try {
        [System.IO.File]::WriteAllText($tempPrompt, $Prompt, [System.Text.Encoding]::UTF8)
        [System.IO.File]::WriteAllText($tempSystem, $SystemPrompt, [System.Text.Encoding]::UTF8)

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "claude"
        $psi.Arguments = "-p `"$tempPrompt`" --append-system-prompt `"$tempSystem`" --allowedTools Write Edit Read Bash Glob Grep"
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true

        $process = [System.Diagnostics.Process]::Start($psi)

        # Read stdout asynchronously to prevent buffer-full deadlock while preserving timeout capability
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $exited = $process.WaitForExit($TimeoutSeconds * 1000)

        if ($exited) {
            $output = $stdoutTask.GetAwaiter().GetResult()
            $script:LastExitCode = $process.ExitCode
            return $output
        } else {
            # Timeout: kill process tree (compatible with PS 5.1 / .NET Framework 4.x)
            try {
                $null = cmd /c "taskkill /PID $($process.Id) /T /F" 2>&1
            } catch {
                try { $process.Kill() } catch {}
            }
            $process.WaitForExit(5000)
            Write-ColorOutput "Timeout after $TimeoutSeconds seconds, skipping..." "Warning"
            $script:LastExitCode = -1
            return $null
        }
    } finally {
        Remove-Item $tempPrompt, $tempSystem -ErrorAction SilentlyContinue
    }
}

# ============================================
# Environment check
# ============================================

function Test-Environment {
    Write-ColorOutput "Checking environment..." "Stage"

    # Check Claude CLI
    try {
        $claudeVersion = claude --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-ColorOutput "Claude CLI installed: $claudeVersion" "Success"
        } else {
            Write-ColorOutput "Claude CLI not installed or not working" "Error"
            Write-ColorOutput "Visit https://github.com/anthropics/claude-code to install" "Info"
            exit 1
        }
    } catch {
        Write-ColorOutput "Claude CLI not installed: $_" "Error"
        exit 1
    }

    # Check git-bash dependency for Claude CLI on Windows
    $gitBashPath = $env:CLAUDE_CODE_GIT_BASH_PATH
    if (-not $gitBashPath) {
        # Locate bash.exe by checking multiple candidate paths
        $candidates = @(
            "D:\Git\bin\bash.exe",
            "D:\Git\usr\bin\bash.exe",
            "C:\Program Files\Git\bin\bash.exe",
            "C:\Program Files\Git\usr\bin\bash.exe"
        )

        # Also try to derive from git.exe location
        $gitCmd = Get-Command git.exe -ErrorAction SilentlyContinue
        if ($gitCmd) {
            $gitRoot = Split-Path (Split-Path $gitCmd.Source -Parent) -Parent
            $candidates += @(
                (Join-Path $gitRoot "bin\bash.exe"),
                (Join-Path $gitRoot "usr\bin\bash.exe"),
                (Join-Path $gitRoot "mingw64\bin\bash.exe")
            )
        }

        foreach ($c in $candidates) {
            if (Test-Path $c) {
                $gitBashPath = $c
                break
            }
        }

        if ($gitBashPath) {
            $env:CLAUDE_CODE_GIT_BASH_PATH = $gitBashPath
            Write-ColorOutput "git-bash: $gitBashPath" "Success"
        } else {
            Write-ColorOutput "git-bash not found, required by Claude CLI on Windows" "Error"
            Write-ColorOutput "Set CLAUDE_CODE_GIT_BASH_PATH environment variable" "Info"
            exit 1
        }
    } else {
        Write-ColorOutput "git-bash: $gitBashPath" "Success"
    }

    # Check project directory
    if (-not (Test-Path $script:PROJECT_DIR)) {
        Write-ColorOutput "Project directory not found: $script:PROJECT_DIR" "Error"
        exit 1
    }
    Write-ColorOutput "Project directory: $script:PROJECT_DIR" "Success"

    # Check if project has code files (exclude vendor dirs, short-circuit for faster VM scans)
    $fileCount = (Get-ChildItem -Path $script:PROJECT_DIR -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch '[\\/](node_modules|\.git|dist|build|vendor|__pycache__)[\\/]' } |
        Select-Object -First 1 | Measure-Object).Count
    if ($fileCount -eq 0) {
        Write-ColorOutput "Project directory is empty" "Error"
        exit 1
    }
    Write-ColorOutput "Project files: $fileCount" "Info"

    # Set project name
    $script:PROJECT_NAME = Split-Path $script:PROJECT_DIR -Leaf
    Write-ColorOutput "Project name: $script:PROJECT_NAME" "Info"

    # Create output directories
    $script:ANALYSIS_DIR = Join-Path $script:PROJECT_DIR ".claude\analysis"
    $script:DOCS_DIR = Join-Path $script:PROJECT_DIR ".claude\docs"
    $script:DIAGRAMS_DIR = Join-Path $script:PROJECT_DIR ".claude\diagrams"

    @($script:ANALYSIS_DIR, $script:DOCS_DIR, $script:DIAGRAMS_DIR) | ForEach-Object {
        if (-not (Test-Path $_)) {
            New-Item -ItemType Directory -Path $_ -Force | Out-Null
            Write-ColorOutput "Created directory: $_" "Info"
        }
    }
}

# ============================================
# Project scanning
# ============================================

function Get-Languages {
    Write-ColorOutput "Detecting languages..." "Info"
    $langs = @()

    if ((Test-Path (Join-Path $script:PROJECT_DIR "package.json")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.js","*.ts","*.jsx","*.tsx" -ErrorAction SilentlyContinue)) {
        $langs += "JavaScript/TypeScript"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "requirements.txt")) -or
        (Test-Path (Join-Path $script:PROJECT_DIR "setup.py")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.py" -ErrorAction SilentlyContinue)) {
        $langs += "Python"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "pom.xml")) -or
        (Test-Path (Join-Path $script:PROJECT_DIR "build.gradle")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.java" -ErrorAction SilentlyContinue)) {
        $langs += "Java"
    }
    if ((Test-Path (Join-Path $script:PROJECT_DIR "go.mod")) -or
        (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.go" -ErrorAction SilentlyContinue)) {
        $langs += "Go"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.c","*.cpp","*.h","*.hpp" -ErrorAction SilentlyContinue) {
        $langs += "C/C++"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.cs" -ErrorAction SilentlyContinue) {
        $langs += "C#"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.rs" -ErrorAction SilentlyContinue) {
        $langs += "Rust"
    }
    if (Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Depth 3 -Include "*.sol" -ErrorAction SilentlyContinue) {
        $langs += "Solidity"
    }

    $script:LANGUAGES = $langs
    Write-ColorOutput "Languages detected: $($langs -join ', ')" "Success"
}

function Get-Frameworks {
    Write-ColorOutput "Detecting frameworks..." "Info"
    $frameworks = @{ backend = @(); frontend = @(); other = @() }

    # Backend frameworks
    $packageJsonPath = Join-Path $script:PROJECT_DIR "package.json"
    if (Test-Path $packageJsonPath) {
        $packageJson = Get-Content $packageJsonPath -Raw -ErrorAction SilentlyContinue
        if ($packageJson -match '"express"') { $frameworks.backend += "Express" }
        if ($packageJson -match '"@nestjs/core"') { $frameworks.backend += "NestJS" }
    }

    $requirementsPath = Join-Path $script:PROJECT_DIR "requirements.txt"
    if (Test-Path $requirementsPath) {
        $requirements = Get-Content $requirementsPath -Raw -ErrorAction SilentlyContinue
        if ($requirements -match 'django') { $frameworks.backend += "Django" }
        if ($requirements -match 'flask') { $frameworks.backend += "Flask" }
        if ($requirements -match 'fastapi') { $frameworks.backend += "FastAPI" }
    }

    if (Test-Path (Join-Path $script:PROJECT_DIR "pom.xml")) {
        $pomContent = Get-Content (Join-Path $script:PROJECT_DIR "pom.xml") -Raw -ErrorAction SilentlyContinue
        if ($pomContent -match 'spring-boot') { $frameworks.backend += "Spring Boot" }
    }

    # Frontend frameworks
    if (Test-Path $packageJsonPath) {
        if ($packageJson -match '"react"') { $frameworks.frontend += "React" }
        if ($packageJson -match '"vue"') { $frameworks.frontend += "Vue" }
        if ($packageJson -match '"@angular/core"') { $frameworks.frontend += "Angular" }
    }

    # Other frameworks
    if (Test-Path (Join-Path $script:PROJECT_DIR "hardhat.config")) { $frameworks.other += "Hardhat" }
    if (Test-Path (Join-Path $script:PROJECT_DIR "truffle-config.js")) { $frameworks.other += "Truffle" }

    $script:FRAMEWORKS = $frameworks

    $allFrameworks = @()
    if ($frameworks.backend.Count -gt 0) { $allFrameworks += "Backend($($frameworks.backend -join ', '))" }
    if ($frameworks.frontend.Count -gt 0) { $allFrameworks += "Frontend($($frameworks.frontend -join ', '))" }
    if ($frameworks.other.Count -gt 0) { $allFrameworks += "Other($($frameworks.other -join ', '))" }

    if ($allFrameworks.Count -gt 0) {
        Write-ColorOutput "Frameworks detected: $($allFrameworks -join ', ')" "Success"
    } else {
        Write-ColorOutput "No frameworks detected" "Warning"
    }
}

function Get-ProjectScale {
    Write-ColorOutput "Calculating project scale..." "Info"

    $codeExtensions = @("*.js","*.ts","*.jsx","*.tsx","*.py","*.java","*.go","*.c","*.cpp","*.h","*.hpp","*.cs","*.rs","*.sol")
    $codeFiles = Get-ChildItem -Path $script:PROJECT_DIR -Recurse -Include $codeExtensions -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch '(node_modules|\.git|dist|build|vendor|__pycache__)' }

    $totalLines = 0
    foreach ($file in $codeFiles) {
        try {
            # Stream-based line counting to avoid loading entire files into memory
            $lineCount = 0
            $reader = [System.IO.File]::OpenText($file.FullName)
            try { while ($null -ne $reader.ReadLine()) { $lineCount++ } } finally { $reader.Close() }
            $totalLines += $lineCount
        } catch {}
    }

    # Determine analysis strategy
    $strategy = "full"
    if ($totalLines -gt 500000) { $strategy = "sampling" }
    elseif ($totalLines -gt 100000) { $strategy = "moderate" }

    $script:PROJECT_SCALE = @{
        code_files = $codeFiles.Count
        code_lines = $totalLines
        strategy = $strategy
    }

    Write-ColorOutput "Project scale: $($codeFiles.Count) code files, $totalLines lines, strategy: $strategy" "Success"
}

function Invoke-ProjectScan {
    Write-ColorOutput "Scanning project..." "Stage"
    Get-Languages
    Get-Frameworks
    Get-ProjectScale
}

# ============================================
# Skill management
# ============================================

function Find-Skill {
    param(
        [string]$SkillName,
        [string]$Category = ""
    )

    # Search order: project skills -> cx tool skills
    $searchPaths = @()

    if ($Category) {
        $searchPaths += Join-Path $script:PROJECT_DIR ".claude\skills\$Category\$SkillName.md"
        $searchPaths += Join-Path $script:CX_TOOL_DIR "skills\$Category\$SkillName.md"
    } else {
        $searchPaths += Join-Path $script:PROJECT_DIR ".claude\skills\$SkillName.md"
        $searchPaths += Join-Path $script:CX_TOOL_DIR "skills\$SkillName.md"
    }

    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            Write-ColorOutput "Found skill: $path" "Info"
            return $path
        }
    }

    return $null
}

# ============================================
# Skill execution (unified)
# ============================================

function Get-ProjectContext {
    return @"
项目路径: $script:PROJECT_DIR
项目名称: $script:PROJECT_NAME
语言: $($script:LANGUAGES -join ', ')
框架: 后端($($script:FRAMEWORKS.backend -join ', ')), 前端($($script:FRAMEWORKS.frontend -join ', '))
规模: $($script:PROJECT_SCALE.code_files) 文件, $($script:PROJECT_SCALE.code_lines) 行
策略: $($script:PROJECT_SCALE.strategy)
分析数据目录: $script:ANALYSIS_DIR
文档输出目录: $script:DOCS_DIR
图表输出目录: $script:DIAGRAMS_DIR
"@
}

function Invoke-Skill {
    param(
        [string]$SkillName,
        [string]$Category,
        [string]$Prompt,
        [string]$ExpectedOutputFile = $null
    )

    $skillPath = Find-Skill -SkillName $SkillName -Category $Category
    if (-not $skillPath) {
        Write-ColorOutput "Skill not found: $SkillName" "Error"
        return $false
    }

    try {
        $skillContent = Get-Content $skillPath -Raw -Encoding UTF8
        # Combine skill instructions with context into a single prompt
        $combinedPrompt = @"
# Skill 模板指令

$skillContent

---

# 上下文信息

$Prompt

---

# 执行要求

请严格按照上面的 Skill 模板指令执行任务。如果模板要求使用 Write 工具创建文件，必须使用 Write 工具完成文件写入。
"@
        $output = Invoke-ClaudeWithTimeout -Prompt $combinedPrompt -SystemPrompt ""

        if ($null -eq $output) {
            Write-ColorOutput "Skill timed out: $SkillName" "Error"
            return $false
        }

        if ($script:LastExitCode -eq 0 -and
            (-not $ExpectedOutputFile -or (Test-Path $ExpectedOutputFile))) {
            return $true
        } else {
            Write-ColorOutput "Skill execution failed: $output" "Error"
            return $false
        }
    } catch {
        Write-ColorOutput "Skill execution error: $_" "Error"
        return $false
    }
}

function Test-AnalysisCache {
    if (-not $UseCache) { return $false }

    $cacheFile = Join-Path $script:ANALYSIS_DIR "project-info.json"
    if (Test-Path $cacheFile) {
        $cacheAge = (Get-Date) - (Get-Item $cacheFile).LastWriteTime
        if ($cacheAge.TotalHours -lt 24) {
            Write-ColorOutput "Using cached analysis ($('{0:N1}' -f $cacheAge.TotalHours) hours ago)" "Info"
            return $true
        }
    }
    return $false
}

# ============================================
# Step definitions (14 steps total)
# ============================================

$script:ANALYSIS_STEPS = @(
    @{ step = 1; phase = "1"; name = "analyze-project-info"; desc = "project-info"; output = "project-info.json"; category = "deep-analyzer" }
    @{ step = 2; phase = "1"; name = "analyze-architecture"; desc = "architecture"; output = "architecture.json"; category = "deep-analyzer" }
    @{ step = 3; phase = "1"; name = "analyze-apis"; desc = "APIs"; output = "apis.json"; category = "deep-analyzer" }
    @{ step = 4; phase = "1"; name = "analyze-data-models"; desc = "data-models"; output = "data-models.json"; category = "deep-analyzer" }
    @{ step = 5; phase = "1"; name = "analyze-business-flows"; desc = "business-flows"; output = "business-flows.json"; category = "deep-analyzer" }
    @{ step = 6; phase = "1"; name = "analyze-dependencies"; desc = "dependencies"; output = "dependencies.json"; category = "deep-analyzer" }
    @{ step = 7; phase = "1"; name = "analyze-security"; desc = "security"; output = "security.json"; category = "deep-analyzer" }
    @{ step = 8; phase = "1"; name = "analyze-file-tree"; desc = "file-tree"; output = "file-tree.json"; category = "deep-analyzer" }
)

$script:GENERATION_STEPS = @(
    @{ step = 9; phase = "2"; name = "gen-claude-md"; desc = "CLAUDE.md"; output = ""; category = "doc-generator" }
    @{ step = 10; phase = "2"; name = "gen-requirements"; desc = "requirements.md"; output = "requirements.md"; category = "doc-generator" }
    @{ step = 11; phase = "2"; name = "gen-file-spec"; desc = "file-specification"; output = "file-specification.md"; category = "doc-generator" }
    @{ step = 12; phase = "2"; name = "gen-system-overview"; desc = "system-overview"; output = "system-overview.puml"; category = "doc-generator" }
    @{ step = 13; phase = "2"; name = "gen-module-diagrams"; desc = "module-diagrams"; output = ""; category = "doc-generator" }
    @{ step = 14; phase = "2"; name = "gen-flow-diagrams"; desc = "flow-diagrams"; output = ""; category = "doc-generator" }
)

# ============================================
# Step execution with progress
# ============================================

function Invoke-AnalysisStep {
    param(
        [hashtable]$StepDef,
        [string]$Context
    )

    $stepNum = $StepDef.step
    $phase = $StepDef.phase
    $name = $StepDef.name
    $desc = $StepDef.desc
    $output = $StepDef.output
    $category = $StepDef.category

    # Before step
    Write-Host "`n----------------------------------------" -ForegroundColor DarkCyan
    Write-Host "  Phase $phase - Step $stepNum/14: $desc" -ForegroundColor Cyan
    Write-Host "----------------------------------------" -ForegroundColor DarkCyan
    Write-Host "  Skill: $category/$name" -ForegroundColor Gray
    Write-Host "  Output: $output" -ForegroundColor Gray
    Write-Host "  Start: $(Get-Date -Format 'HH:mm:ss')" -ForegroundColor Gray
    Write-Host ""

    $outputFile = Join-Path $script:ANALYSIS_DIR $output
    $prompt = "$Context`n输出文件: $outputFile`n`n请按照 skill 模板的指令分析项目，然后使用 Write 工具将结果写入输出文件。必须完成文件写入才算成功。"

    $result = Invoke-Skill -SkillName $name -Category $category -Prompt $prompt -ExpectedOutputFile $outputFile

    # After step
    $elapsed = "{0:mm\:ss}" -f ((Get-Date) - $script:START_TIME)
    if ($result) {
        Write-Host "`n[$elapsed] Phase $phase - Step $stepNum/14: $desc completed" -ForegroundColor Green
        Write-Host "  Output: $outputFile" -ForegroundColor DarkGreen
    } else {
        Write-Host "`n[$elapsed] Phase $phase - Step $stepNum/14: $desc FAILED" -ForegroundColor Red
        if ($StopOnError -or -not $ContinueOnError) {
            Write-Host "  Stopping execution due to error..." -ForegroundColor Red
            exit 1
        } else {
            Write-Host "  Continuing to next step..." -ForegroundColor Yellow
        }
    }

    return $result
}

function Invoke-GenerationStep {
    param(
        [hashtable]$StepDef,
        [string]$Context
    )

    $stepNum = $StepDef.step
    $phase = $StepDef.phase
    $name = $StepDef.name
    $desc = $StepDef.desc
    $output = $StepDef.output
    $category = $StepDef.category

    # Before step
    Write-Host "`n========================================" -ForegroundColor DarkMagenta
    Write-Host "  Phase $phase - Step $stepNum/14: $desc" -ForegroundColor Magenta
    Write-Host "========================================" -ForegroundColor DarkMagenta
    Write-Host "  Skill: $category/$name" -ForegroundColor Gray
    if ($output) { Write-Host "  Output: $output" -ForegroundColor Gray }
    Write-Host "  Start: $(Get-Date -Format 'HH:mm:ss')" -ForegroundColor Gray
    Write-Host ""

    $prompt = "$Context`n`n请按照 skill 模板的指令生成文档，使用 Write 工具将结果写入输出目录。必须完成文件写入才算成功。"
    # Determine output directory based on file extension
    $outputDir = if ($output -match '\.puml$') { $script:DIAGRAMS_DIR } else { $script:DOCS_DIR }
    $expectedOutput = if ($output) { Join-Path $outputDir $output } else { $null }

    $result = Invoke-Skill -SkillName $name -Category $category -Prompt $prompt -ExpectedOutputFile $expectedOutput

    # After step
    $elapsed = "{0:mm\:ss}" -f ((Get-Date) - $script:START_TIME)
    if ($result) {
        Write-Host "`n[$elapsed] Phase $phase - Step $stepNum/14: $desc completed" -ForegroundColor Green
    } else {
        Write-Host "`n[$elapsed] Phase $phase - Step $stepNum/14: $desc FAILED" -ForegroundColor Red
        if ($StopOnError -or -not $ContinueOnError) {
            Write-Host "  Stopping execution due to error..." -ForegroundColor Red
            exit 1
        } else {
            Write-Host "  Continuing to next step..." -ForegroundColor Yellow
        }
    }

    return $result
}

# ============================================
# Phase 1: Deep Analysis (Steps 1-8)
# ============================================

function Invoke-DeepAnalysis {
    Write-ColorOutput "Phase 1: Deep Analysis (Steps 1-8)" "Stage"

    if (Test-AnalysisCache) {
        Write-ColorOutput "Skipping Phase 1 - using cached analysis" "Warning"
        return $true
    }

    Write-ColorOutput "Starting 8 analysis steps..." "Info"
    $context = Get-ProjectContext

    $successCount = 0
    $failCount = 0
    $succeeded = @()
    $failed = @()

    foreach ($stepDef in $script:ANALYSIS_STEPS) {
        if (Invoke-AnalysisStep -StepDef $stepDef -Context $context) {
            $successCount++
            $succeeded += $stepDef.desc
        } else {
            $failCount++
            $failed += $stepDef.desc
        }
    }

    # Phase summary
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "  Phase 1 Complete: Deep Analysis" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Succeeded: $successCount/$($script:ANALYSIS_STEPS.Count)" -ForegroundColor Green
    Write-Host "  Failed: $failCount/$($script:ANALYSIS_STEPS.Count)" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Green" })
    Write-Host "  Elapsed: $("{0:mm\:ss}" -f ((Get-Date) - $script:START_TIME))" -ForegroundColor Gray
    Write-Host ""

    $script:GENERATED_DOCS = $succeeded
    $script:FAILED_DOCS = $failed

    return ($successCount -gt 0)
}


# ============================================
# Document generation
# ============================================

function Get-DocumentsToGenerate {
    # If any specific flag is set, disable All
    if ($ClaudeMd -or $Requirements -or $FileSpec -or $SystemOverview -or $ModuleDiagrams -or $FlowDiagrams) {
        $script:All = $false
    }

    $steps = @()

    if ($All -or $ClaudeMd) { $steps += $script:GENERATION_STEPS[0] }  # gen-claude-md
    if ($All -or $Requirements) { $steps += $script:GENERATION_STEPS[1] }  # gen-requirements
    if ($All -or $FileSpec) { $steps += $script:GENERATION_STEPS[2] }  # gen-file-spec
    if ($All -or $SystemOverview) { $steps += $script:GENERATION_STEPS[3] }  # gen-system-overview
    if ($All -or $ModuleDiagrams) { $steps += $script:GENERATION_STEPS[4] }  # gen-module-diagrams
    if ($All -or $FlowDiagrams) { $steps += $script:GENERATION_STEPS[5] }  # gen-flow-diagrams

    return $steps
}

# ============================================
# Phase 2: Document Generation (Steps 9-14)
# ============================================

function Invoke-DocumentGeneration {
    Write-ColorOutput "Phase 2: Document Generation (Steps 9-14)" "Stage"

    $steps = Get-DocumentsToGenerate

    if ($steps.Count -eq 0) {
        Write-ColorOutput "No documents to generate" "Warning"
        return
    }

    Write-ColorOutput "Starting $($steps.Count) generation steps..." "Info"
    $context = Get-ProjectContext

    $successCount = 0
    $failCount = 0
    $succeeded = @()
    $failed = @()

    foreach ($stepDef in $steps) {
        if (Invoke-GenerationStep -StepDef $stepDef -Context $context) {
            $successCount++
            $succeeded += $stepDef.desc
        } else {
            $failCount++
            $failed += $stepDef.desc
        }
    }

    # Phase summary
    Write-Host "`n========================================" -ForegroundColor Magenta
    Write-Host "  Phase 2 Complete: Document Generation" -ForegroundColor Magenta
    Write-Host "========================================" -ForegroundColor Magenta
    Write-Host "  Succeeded: $successCount/$($steps.Count)" -ForegroundColor Green
    Write-Host "  Failed: $failCount/$($steps.Count)" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Green" })
    Write-Host "  Elapsed: $("{0:mm\:ss}" -f ((Get-Date) - $script:START_TIME))" -ForegroundColor Gray
    Write-Host ""

    $script:GENERATED_DOCS = $succeeded
    $script:FAILED_DOCS = $failed
}

# ============================================
# Summary report
# ============================================

function Show-Summary {
    $elapsed = (Get-Date) - $script:START_TIME
    $elapsedStr = "{0:mm\:ss}" -f $elapsed

    Write-ColorOutput "Complete" "Stage"

    if ($script:GENERATED_DOCS.Count -gt 0) {
        Write-ColorOutput "Generated: $($script:GENERATED_DOCS -join ', ')" "Success"
    }
    if ($script:FAILED_DOCS.Count -gt 0) {
        Write-ColorOutput "Failed: $($script:FAILED_DOCS -join ', ')" "Error"
    }

    Write-ColorOutput "Elapsed: $elapsedStr" "Info"

    Write-Host "`nOutput directories:" -ForegroundColor Cyan
    Write-Host "  Analysis: $script:ANALYSIS_DIR" -ForegroundColor Cyan
    Write-Host "  Docs:     $script:DOCS_DIR" -ForegroundColor Cyan
    Write-Host "  Diagrams: $script:DIAGRAMS_DIR" -ForegroundColor Cyan

    if (Test-Path (Join-Path $script:PROJECT_DIR "CLAUDE.md")) {
        Write-ColorOutput "`nCLAUDE.md copied to project root" "Success"
    }
}

# ============================================
# Main flow
# ============================================

function Main {
    Write-ColorOutput "CX - Project Documentation Generator v2.0" "Stage"

    # 1. Environment check
    Test-Environment

    # 2. Project scan
    Invoke-ProjectScan

    # 3. Deep analysis
    $analysisSuccess = Invoke-DeepAnalysis

    if (-not $analysisSuccess) {
        Write-ColorOutput "Deep analysis failed, cannot generate documents" "Error"
        exit 1
    }

    # 4. Document generation
    Invoke-DocumentGeneration

    # 5. Summary
    Show-Summary
}

# Run
Main
